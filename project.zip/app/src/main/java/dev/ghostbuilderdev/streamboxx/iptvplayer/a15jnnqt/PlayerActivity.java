package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import android.app.PictureInPictureParams;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.mediarouter.app.MediaRouteButton;

import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.common.images.WebImage;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@UnstableApi
public final class PlayerActivity extends FragmentActivity {
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_POSTER = "poster";
    public static final String EXTRA_HEADERS = "headers";
    public static final String EXTRA_START_POSITION = "startPosition";
    public static final String EXTRA_AUTOPLAY = "autoplay";
    public static final String EXTRA_REQUEST_CAST = "requestCast";

    private PlayerView playerView;
    private ExoPlayer player;
    private CastContext castContext;
    private MediaRouteButton castButton;
    private String mediaUrl = "";
    private String mediaTitle = "";
    private String posterUrl = "";
    private String contentType = "video/mp4";
    private long startPositionMs = 0L;
    private boolean requestCast;

    private final SessionManagerListener<CastSession> castListener = new SessionManagerListener<CastSession>() {
        @Override public void onSessionStarted(@NonNull CastSession session, @NonNull String sessionId) { loadOnCast(session); }
        @Override public void onSessionResumed(@NonNull CastSession session, boolean wasSuspended) { loadOnCast(session); }
        @Override public void onSessionStarting(@NonNull CastSession session) {}
        @Override public void onSessionStartFailed(@NonNull CastSession session, int error) { toast("Connexion Cast impossible (" + error + ")"); }
        @Override public void onSessionEnding(@NonNull CastSession session) {}
        @Override public void onSessionEnded(@NonNull CastSession session, int error) { resumeLocal(); }
        @Override public void onSessionResuming(@NonNull CastSession session, @NonNull String sessionId) {}
        @Override public void onSessionResumeFailed(@NonNull CastSession session, int error) { toast("Reconnexion Cast impossible"); }
        @Override public void onSessionSuspended(@NonNull CastSession session, int reason) {}
    };

    @Override protected void onCreate(@Nullable Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        readIntent();
        buildUi();
        createLocalPlayer();
        initCastSafely();
    }

    private void readIntent() {
        Intent i = getIntent();
        mediaUrl = safe(i.getStringExtra(EXTRA_URL));
        mediaTitle = safe(i.getStringExtra(EXTRA_TITLE));
        posterUrl = safe(i.getStringExtra(EXTRA_POSTER));
        startPositionMs = Math.max(0L, i.getLongExtra(EXTRA_START_POSITION, 0L));
        requestCast = i.getBooleanExtra(EXTRA_REQUEST_CAST, false);
        contentType = mimeFor(mediaUrl);
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);
        playerView.setKeepScreenOn(true);
        root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        actions.setPadding(12, 12, 12, 12);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        actions.setLayoutParams(params);

        castButton = new MediaRouteButton(this);
        castButton.setVisibility(android.view.View.GONE);
        LinearLayout.LayoutParams castParams = new LinearLayout.LayoutParams(64, 64);
        castParams.setMargins(6, 0, 0, 0);
        actions.addView(castButton, castParams);

        Button pip = action("PiP");
        pip.setOnClickListener(v -> enterPip());
        actions.addView(pip);
        Button external = action("Externe");
        external.setOnClickListener(v -> openExternal());
        actions.addView(external);
        Button close = action("Fermer");
        close.setOnClickListener(v -> finish());
        actions.addView(close);
        root.addView(actions);
        setContentView(root);
    }

    private Button action(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(0x99000000);
        b.setPadding(18, 8, 18, 8);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(6, 0, 0, 0);
        b.setLayoutParams(p);
        return b;
    }

    private void createLocalPlayer() {
        if (mediaUrl.isEmpty()) { toast("Adresse du film absente"); finish(); return; }
        Map<String,String> headers = parseHeaders(safe(getIntent().getStringExtra(EXTRA_HEADERS)));
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(20000)
                .setReadTimeoutMs(30000)
                .setUserAgent(headers.getOrDefault("User-Agent", "Prime-IPTV-Player/3.3 Android"));
        headers.remove("User-Agent");
        if (!headers.isEmpty()) http.setDefaultRequestProperties(headers);
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(http))
                .build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(@NonNull PlaybackException error) {
                toast("Lecture impossible : " + readable(error));
            }
        });
        MediaMetadata.Builder md = new MediaMetadata.Builder().setTitle(mediaTitle);
        if (!posterUrl.isEmpty()) md.setArtworkUri(Uri.parse(posterUrl));
        MediaItem item = new MediaItem.Builder().setUri(mediaUrl).setMediaMetadata(md.build()).build();
        player.setMediaItem(item, startPositionMs);
        player.prepare();
        player.setPlayWhenReady(getIntent().getBooleanExtra(EXTRA_AUTOPLAY, true));
    }

    private void initCastSafely() {
        try {
            castContext = CastContext.getSharedInstance(this);
            CastButtonFactory.setUpMediaRouteButton(this, castButton);
            castButton.setVisibility(android.view.View.VISIBLE);
            castContext.getSessionManager().addSessionManagerListener(castListener, CastSession.class);
            CastSession current = castContext.getSessionManager().getCurrentCastSession();
            if (current != null && current.isConnected()) loadOnCast(current);
            if (requestCast) castButton.postDelayed(() -> {
                try { castButton.performClick(); } catch (Throwable e) { toast("Sélecteur Cast indisponible"); }
            }, 700L);
        } catch (Throwable error) {
            castButton.setVisibility(android.view.View.GONE);
            if (requestCast) toast("Cast indisponible sur cet appareil. Lecture locale active.");
        }
    }

    private void loadOnCast(CastSession session) {
        try {
            if (session == null || !session.isConnected() || session.getRemoteMediaClient() == null) return;
            long position = player != null ? Math.max(0L, player.getCurrentPosition()) : startPositionMs;
            com.google.android.gms.cast.MediaMetadata metadata = new com.google.android.gms.cast.MediaMetadata(com.google.android.gms.cast.MediaMetadata.MEDIA_TYPE_MOVIE);
            metadata.putString(com.google.android.gms.cast.MediaMetadata.KEY_TITLE, mediaTitle);
            if (!posterUrl.isEmpty()) metadata.addImage(new WebImage(Uri.parse(posterUrl)));
            MediaInfo info = new MediaInfo.Builder(mediaUrl)
                    .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
                    .setContentType(contentType)
                    .setMetadata(metadata)
                    .build();
            MediaLoadRequestData request = new MediaLoadRequestData.Builder()
                    .setMediaInfo(info)
                    .setAutoplay(true)
                    .setCurrentTime(position)
                    .build();
            session.getRemoteMediaClient().load(request);
            if (player != null) player.pause();
            toast("Lecture envoyée au téléviseur");
        } catch (Throwable error) {
            toast("Téléviseur connecté, mais flux refusé : " + readable(error));
            resumeLocal();
        }
    }

    private void resumeLocal() {
        if (player != null) { player.prepare(); player.play(); }
    }

    private void openExternal() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(mediaUrl));
            i.setDataAndType(Uri.parse(mediaUrl), "video/*");
            startActivity(Intent.createChooser(i, "Choisir un lecteur"));
        } catch (Throwable e) { toast("Aucun lecteur externe disponible"); }
    }

    private void enterPip() {
        if (Build.VERSION.SDK_INT < 26) return;
        try { enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(new Rational(16,9)).build()); }
        catch (Throwable e) { toast("PiP indisponible"); }
    }

    @Override protected void onStart() {
        super.onStart();
        if (castContext != null) {
            try { castContext.getSessionManager().addSessionManagerListener(castListener, CastSession.class); } catch (Throwable ignored) {}
        }
    }

    @Override protected void onStop() {
        if (castContext != null) {
            try { castContext.getSessionManager().removeSessionManagerListener(castListener, CastSession.class); } catch (Throwable ignored) {}
        }
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (playerView != null) playerView.setPlayer(null);
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }

    @Override public void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (Build.VERSION.SDK_INT >= 26 && player != null && player.isPlaying()) enterPip();
    }

    @Override public void onPictureInPictureModeChanged(boolean inPip, @NonNull Configuration config) {
        super.onPictureInPictureModeChanged(inPip, config);
        if (playerView != null) playerView.setUseController(!inPip);
    }

    private static Map<String,String> parseHeaders(String json) {
        Map<String,String> out = new HashMap<>();
        try {
            JSONObject object = new JSONObject(json);
            Iterator<String> keys = object.keys();
            while (keys.hasNext()) { String k = keys.next(); String v = object.optString(k, ""); if (!k.isEmpty() && !v.isEmpty()) out.put(k, v); }
        } catch (Throwable ignored) {}
        return out;
    }

    private static String mimeFor(String url) {
        String u = safe(url).toLowerCase();
        if (u.contains(".m3u8")) return "application/x-mpegURL";
        if (u.contains(".mpd")) return "application/dash+xml";
        if (u.contains(".mkv")) return "video/x-matroska";
        if (u.contains(".ts")) return "video/mp2t";
        return "video/mp4";
    }

    private static String readable(Throwable error) {
        String m = error == null ? "erreur inconnue" : error.getMessage();
        return m == null || m.trim().isEmpty() ? error.getClass().getSimpleName() : m;
    }
    private void toast(String text) { runOnUiThread(() -> Toast.makeText(this, text, Toast.LENGTH_LONG).show()); }
    private static String safe(String value) { return value == null ? "" : value.trim(); }
}
