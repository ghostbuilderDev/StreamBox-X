package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import android.Manifest;
import android.app.PictureInPictureParams;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.mediarouter.app.MediaRouteButton;

import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.images.WebImage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Lecteur IPTV V5 affiché au-dessus de la WebView principale.
 *
 * Le lecteur ne démarre plus une Activity secondaire : l'écran HTML reste vivant
 * et une erreur Media3 ou Cast ne peut plus terminer toute l'application.
 * Google Cast n'est chargé qu'après une action explicite de l'utilisateur.
 */
@UnstableApi
public final class NativePlayerOverlay extends FrameLayout {
    public static final int REQUEST_CAST_PERMISSION = 7042;
    private static final long CAST_VERIFY_DELAY_MS = 10_000L;

    private final MainActivity activity;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService castExecutor = Executors.newSingleThreadExecutor();
    private final List<PlaybackCandidate> candidates = new ArrayList<>();

    private final PlayerView playerView;
    private final TextView titleView;
    private final TextView statusView;
    private final TextView detailView;
    private final ProgressBar progress;
    private final Button castAction;
    private final Button retryAction;
    private final Button nextAction;
    private final MediaRouteButton mediaRouteButton;

    private ExoPlayer player;
    private int candidateIndex;
    private int generation;
    private String title = "Lecture";
    private String poster = "";
    private String mediaType = "video";
    private long requestedPositionMs;
    private boolean autoplay = true;
    private boolean pendingCastRequest;

    private boolean castInitStarted;
    private boolean castReady;
    private CastContext castContext;
    private CastProxyServer castProxy;
    private int castCandidateIndex = -1;

    private final SessionManagerListener<CastSession> castSessionListener = new SessionManagerListener<CastSession>() {
        @Override public void onSessionStarting(@NonNull CastSession session) {
            showStatus("Connexion au téléviseur…", true);
        }

        @Override public void onSessionStarted(@NonNull CastSession session, @NonNull String sessionId) {
            startCast(session);
        }

        @Override public void onSessionStartFailed(@NonNull CastSession session, int error) {
            showStatus("Connexion Chromecast impossible (code " + error + "). La lecture locale reste active.", false);
        }

        @Override public void onSessionEnding(@NonNull CastSession session) { }

        @Override public void onSessionEnded(@NonNull CastSession session, int error) {
            stopProxy();
            showStatus("Cast terminé — lecture sur le téléphone", false);
            if (player != null) player.play();
        }

        @Override public void onSessionResuming(@NonNull CastSession session, @NonNull String sessionId) { }

        @Override public void onSessionResumed(@NonNull CastSession session, boolean wasSuspended) {
            startCast(session);
        }

        @Override public void onSessionResumeFailed(@NonNull CastSession session, int error) {
            showStatus("Reconnexion Chromecast impossible (code " + error + ").", false);
        }

        @Override public void onSessionSuspended(@NonNull CastSession session, int reason) {
            showStatus("Connexion Chromecast suspendue.", false);
        }
    };

    public NativePlayerOverlay(@NonNull MainActivity activity) {
        super(activity);
        this.activity = activity;
        setVisibility(GONE);
        setBackgroundColor(Color.BLACK);
        setFocusable(true);
        setFocusableInTouchMode(true);

        playerView = new PlayerView(activity);
        playerView.setUseController(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);
        playerView.setKeepScreenOn(true);
        addView(playerView, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18), dp(12), dp(18), dp(12));
        header.setBackgroundColor(0xB0000000);
        LayoutParams headerParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP);
        addView(header, headerParams);

        titleView = new TextView(activity);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(18f);
        titleView.setMaxLines(1);
        header.addView(titleView);

        statusView = new TextView(activity);
        statusView.setTextColor(0xFFE0E5EE);
        statusView.setTextSize(13f);
        header.addView(statusView);

        detailView = new TextView(activity);
        detailView.setTextColor(0xFFB1B8C4);
        detailView.setTextSize(11f);
        detailView.setMaxLines(5);
        detailView.setVisibility(GONE);
        header.addView(detailView);

        progress = new ProgressBar(activity);
        LayoutParams progressParams = new LayoutParams(dp(48), dp(48), Gravity.CENTER);
        addView(progress, progressParams);

        LinearLayout actions = new LinearLayout(activity);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        actions.setPadding(dp(8), dp(8), dp(8), dp(8));
        actions.setBackgroundColor(0xA8000000);
        LayoutParams actionsParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        addView(actions, actionsParams);

        mediaRouteButton = new MediaRouteButton(activity);
        mediaRouteButton.setVisibility(INVISIBLE);
        actions.addView(mediaRouteButton, new LinearLayout.LayoutParams(dp(1), dp(1)));

        castAction = action("Caster", view -> requestCast());
        retryAction = action("Réessayer", view -> playCandidate(candidateIndex, currentPosition()));
        nextAction = action("Autre flux", view -> playCandidate(candidateIndex + 1, 0L));
        Button pipAction = action("PiP", view -> enterPip());
        Button detailAction = action("Détails", view -> detailView.setVisibility(detailView.getVisibility() == VISIBLE ? GONE : VISIBLE));
        Button closeAction = action("Fermer", view -> close());

        actions.addView(castAction);
        actions.addView(retryAction);
        actions.addView(nextAction);
        actions.addView(pipAction);
        actions.addView(detailAction);
        actions.addView(closeAction);
    }

    public void open(String payloadJson, boolean forceCast) {
        try {
            parsePayload(payloadJson, forceCast);
            if (candidates.isEmpty()) {
                activity.showNativePlayerMessage("Aucun flux n'a été construit pour ce contenu. Essayez un épisode précis ou rechargez le catalogue.");
                return;
            }
            setVisibility(VISIBLE);
            bringToFront();
            requestFocus();
            titleView.setText(title);
            retryAction.setVisibility(GONE);
            nextAction.setVisibility(candidates.size() > 1 ? VISIBLE : GONE);
            playCandidate(0, requestedPositionMs);
            if (pendingCastRequest) mainHandler.postDelayed(this::requestCast, 700L);
        } catch (Throwable error) {
            activity.showNativePlayerMessage("Le lecteur intégré n'a pas pu préparer le contenu : " + readable(error));
            close();
        }
    }

    private void parsePayload(String payloadJson, boolean forceCast) throws Exception {
        candidates.clear();
        candidateIndex = 0;
        JSONObject payload = new JSONObject(payloadJson == null ? "{}" : payloadJson);
        title = payload.optString("title", "Lecture");
        poster = payload.optString("poster", "");
        mediaType = payload.optString("type", "video");
        requestedPositionMs = Math.max(0L, payload.optLong("startPositionMs", 0L));
        autoplay = payload.optBoolean("autoplay", true);
        pendingCastRequest = forceCast || payload.optBoolean("requestCast", false);

        JSONArray values = payload.optJSONArray("candidates");
        if (values == null) return;
        for (int index = 0; index < values.length(); index++) {
            Object raw = values.opt(index);
            PlaybackCandidate candidate = raw instanceof JSONObject
                    ? PlaybackCandidate.fromJson((JSONObject) raw)
                    : new PlaybackCandidate(String.valueOf(raw), "", "Flux " + (index + 1), Collections.emptyMap());
            if (candidate.isValid() && !containsUrl(candidate.url)) candidates.add(candidate);
        }
    }

    private boolean containsUrl(String url) {
        for (PlaybackCandidate candidate : candidates) if (candidate.url.equals(url)) return true;
        return false;
    }

    private void playCandidate(int requestedIndex, long startPositionMs) {
        if (candidates.isEmpty()) return;
        candidateIndex = Math.floorMod(requestedIndex, candidates.size());
        PlaybackCandidate candidate = candidates.get(candidateIndex);
        int currentGeneration = ++generation;
        releasePlayer();
        showStatus("Ouverture du flux " + (candidateIndex + 1) + "/" + candidates.size() + " — " + candidate.label, true);
        detailView.setText(candidate.describe());

        try {
            Map<String, String> headers = new HashMap<>(candidate.headers);
            String userAgent = removeHeaderIgnoreCase(headers, "User-Agent");
            if (userAgent == null || userAgent.trim().isEmpty()) {
                userAgent = System.getProperty("http.agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36");
            }
            removeBlankHeaders(headers);

            DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                    .setAllowCrossProtocolRedirects(true)
                    .setConnectTimeoutMs(25_000)
                    .setReadTimeoutMs(60_000)
                    .setUserAgent(userAgent);
            if (!headers.isEmpty()) http.setDefaultRequestProperties(headers);

            DefaultRenderersFactory renderers = new DefaultRenderersFactory(activity)
                    .setEnableDecoderFallback(true);
            DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                    .setBufferDurationsMs(12_000, 55_000, 1_000, 2_500)
                    .build();

            player = new ExoPlayer.Builder(activity, renderers)
                    .setLoadControl(loadControl)
                    .setMediaSourceFactory(new DefaultMediaSourceFactory(http))
                    .build();
            playerView.setPlayer(player);
            player.addListener(new Player.Listener() {
                @Override public void onPlaybackStateChanged(int state) {
                    if (currentGeneration != generation) return;
                    if (state == Player.STATE_BUFFERING) {
                        showStatus("Chargement du flux " + (candidateIndex + 1) + "/" + candidates.size() + "…", true);
                    } else if (state == Player.STATE_READY) {
                        showStatus("Lecture prête — " + candidate.label, false);
                        retryAction.setVisibility(GONE);
                    } else if (state == Player.STATE_ENDED) {
                        showStatus("Lecture terminée", false);
                    }
                }

                @Override public void onPlayerError(@NonNull PlaybackException error) {
                    if (currentGeneration != generation) return;
                    candidate.lastError = error.errorCodeName + " — " + readable(error);
                    detailView.setText(candidate.describe());
                    if (candidateIndex + 1 < candidates.size()) {
                        showStatus("Ce format a échoué. Essai automatique du suivant…", true);
                        mainHandler.postDelayed(() -> playCandidate(candidateIndex + 1, 0L), 350L);
                    } else {
                        showStatus("Aucun flux n'a pu être décodé. Ouvrez Détails pour voir les erreurs.", false);
                        retryAction.setVisibility(VISIBLE);
                    }
                }
            });

            MediaMetadata.Builder metadata = new MediaMetadata.Builder().setTitle(title);
            if (!poster.isEmpty()) metadata.setArtworkUri(Uri.parse(poster));
            MediaItem.Builder media = new MediaItem.Builder().setUri(candidate.url).setMediaMetadata(metadata.build());
            if (!candidate.mime.isEmpty()) media.setMimeType(candidate.mime);
            player.setMediaItem(media.build(), Math.max(0L, startPositionMs));
            player.prepare();
            player.setPlayWhenReady(autoplay);
        } catch (Throwable error) {
            candidate.lastError = readable(error);
            detailView.setText(candidate.describe());
            if (candidateIndex + 1 < candidates.size()) {
                mainHandler.postDelayed(() -> playCandidate(candidateIndex + 1, 0L), 100L);
            } else {
                showStatus("Le moteur vidéo n'a pu ouvrir aucun flux : " + readable(error), false);
                retryAction.setVisibility(VISIBLE);
            }
        }
    }

    public void requestCast() {
        pendingCastRequest = true;
        if (!hasCastPermission()) {
            requestCastPermission();
            return;
        }
        if (castReady && castContext != null) {
            CastSession session = castContext.getSessionManager().getCurrentCastSession();
            if (session != null && session.isConnected()) startCast(session);
            else openRouteChooser();
            return;
        }
        if (castInitStarted) {
            showStatus("Chargement du module Chromecast…", true);
            return;
        }
        castInitStarted = true;
        castAction.setEnabled(false);
        showStatus("Initialisation sécurisée de Chromecast…", true);
        try {
            CastContext.getSharedInstance(activity.getApplicationContext(), castExecutor)
                    .addOnSuccessListener(context -> activity.runOnUiThread(() -> onCastReady(context)))
                    .addOnFailureListener(error -> activity.runOnUiThread(() -> {
                        castInitStarted = false;
                        castAction.setEnabled(true);
                        showStatus("Module Chromecast indisponible : " + readable(error) + ". La lecture locale continue.", false);
                    }));
        } catch (Throwable error) {
            castInitStarted = false;
            castAction.setEnabled(true);
            showStatus("Google Cast n'a pas pu être chargé : " + readable(error), false);
        }
    }

    private void onCastReady(CastContext context) {
        try {
            castContext = context;
            castContext.getSessionManager().addSessionManagerListener(castSessionListener, CastSession.class);
            // Le SDK Cast récent peut charger son module dynamiquement. La version
            // asynchrone évite qu'un module Play Services absent bloque le thread UI.
            CastButtonFactory.setUpMediaRouteButton(activity, castExecutor, mediaRouteButton)
                    .addOnSuccessListener(ignored -> activity.runOnUiThread(() -> {
                        castReady = true;
                        castAction.setEnabled(true);
                        CastSession session = castContext.getSessionManager().getCurrentCastSession();
                        if (session != null && session.isConnected()) startCast(session);
                        else openRouteChooser();
                    }))
                    .addOnFailureListener(error -> activity.runOnUiThread(() -> {
                        castInitStarted = false;
                        castReady = false;
                        castAction.setEnabled(true);
                        showStatus("Sélecteur Chromecast indisponible : " + readable(error), false);
                    }));
        } catch (Throwable error) {
            castInitStarted = false;
            castReady = false;
            castAction.setEnabled(true);
            showStatus("Sélecteur Chromecast indisponible : " + readable(error), false);
        }
    }

    private void openRouteChooser() {
        try {
            mediaRouteButton.setVisibility(VISIBLE);
            mediaRouteButton.performClick();
            mainHandler.postDelayed(() -> mediaRouteButton.setVisibility(INVISIBLE), 300L);
        } catch (Throwable error) {
            showStatus("Impossible d'ouvrir la liste des téléviseurs : " + readable(error), false);
        }
    }

    private void startCast(CastSession session) {
        if (session == null || !session.isConnected()) return;
        List<Integer> compatible = castCandidateOrder();
        if (compatible.isEmpty()) {
            showStatus("Aucun format compatible Chromecast n'est disponible. Un fichier MKV seul ne peut pas être envoyé au récepteur Google standard.", false);
            return;
        }
        castCandidateIndex = compatible.get(0);
        loadCastCandidate(session, castCandidateIndex, true);
    }

    private List<Integer> castCandidateOrder() {
        List<Integer> indexes = new ArrayList<>();
        for (int index = 0; index < candidates.size(); index++) {
            String mime = candidates.get(index).castMime();
            if (!mime.isEmpty() && !mime.contains("matroska")) indexes.add(index);
        }
        indexes.sort(Comparator.comparingInt(index -> castPriority(candidates.get(index))));
        return indexes;
    }

    private int castPriority(PlaybackCandidate candidate) {
        String mime = candidate.castMime().toLowerCase(Locale.ROOT);
        if (mime.contains("mpegurl")) return 0;
        if (mime.contains("mp4")) return 1;
        if (mime.contains("mp2t")) return 2;
        if (mime.contains("webm")) return 3;
        return 9;
    }

    private void loadCastCandidate(CastSession session, int index, boolean proxy) {
        if (session == null || !session.isConnected() || session.getRemoteMediaClient() == null) return;
        if (index < 0 || index >= candidates.size()) return;
        PlaybackCandidate candidate = candidates.get(index);
        String url = candidate.url;
        if (proxy) {
            try {
                stopProxy();
                castProxy = new CastProxyServer(activity, candidate.headers);
                castProxy.startServer();
                url = castProxy.publicUrl(candidate.url);
            } catch (Throwable error) {
                showStatus("Relais Wi-Fi impossible : " + readable(error), false);
                tryNextCastCandidate(session, index);
                return;
            }
        }

        try {
            com.google.android.gms.cast.MediaMetadata metadata = new com.google.android.gms.cast.MediaMetadata(
                    "live".equals(mediaType)
                            ? com.google.android.gms.cast.MediaMetadata.MEDIA_TYPE_GENERIC
                            : com.google.android.gms.cast.MediaMetadata.MEDIA_TYPE_MOVIE
            );
            metadata.putString(com.google.android.gms.cast.MediaMetadata.KEY_TITLE, title);
            if (!poster.isEmpty()) metadata.addImage(new WebImage(Uri.parse(poster)));

            MediaInfo mediaInfo = new MediaInfo.Builder(url)
                    .setStreamType("live".equals(mediaType) ? MediaInfo.STREAM_TYPE_LIVE : MediaInfo.STREAM_TYPE_BUFFERED)
                    .setContentType(candidate.castMime())
                    .setMetadata(metadata)
                    .build();
            MediaLoadRequestData request = new MediaLoadRequestData.Builder()
                    .setMediaInfo(mediaInfo)
                    .setAutoplay(true)
                    .setCurrentTime(currentPosition())
                    .build();

            String route = proxy ? "via le relais du téléphone" : "directement";
            showStatus("Envoi du flux au téléviseur " + route + "…", true);
            session.getRemoteMediaClient().load(request).setResultCallback(result -> {
                Status status = result.getStatus();
                if (!status.isSuccess()) {
                    handleCastFailure(session, index, proxy, "commande refusée " + status.getStatusCode());
                    return;
                }
                mainHandler.postDelayed(() -> verifyCast(session, index, proxy), CAST_VERIFY_DELAY_MS);
            });
        } catch (Throwable error) {
            handleCastFailure(session, index, proxy, readable(error));
        }
    }

    private void verifyCast(CastSession session, int index, boolean usedProxy) {
        if (session == null || !session.isConnected() || session.getRemoteMediaClient() == null) return;
        MediaStatus status = session.getRemoteMediaClient().getMediaStatus();
        int playerState = status == null ? MediaStatus.PLAYER_STATE_UNKNOWN : status.getPlayerState();
        if (playerState == MediaStatus.PLAYER_STATE_PLAYING
                || playerState == MediaStatus.PLAYER_STATE_BUFFERING
                || playerState == MediaStatus.PLAYER_STATE_PAUSED) {
            if (player != null) player.pause();
            showStatus("Lecture active sur le téléviseur", false);
            return;
        }
        int reason = status == null ? 0 : status.getIdleReason();
        handleCastFailure(session, index, usedProxy, "état " + playerState + ", raison " + reason);
    }

    private void handleCastFailure(CastSession session, int index, boolean usedProxy, String reason) {
        if (usedProxy) {
            showStatus("Le relais Wi-Fi n'a pas été accepté. Essai direct du même flux…", true);
            loadCastCandidate(session, index, false);
        } else {
            showStatus("Format refusé par le téléviseur (" + reason + "). Essai du suivant…", true);
            tryNextCastCandidate(session, index);
        }
    }

    private void tryNextCastCandidate(CastSession session, int current) {
        List<Integer> ordered = castCandidateOrder();
        int position = ordered.indexOf(current);
        if (position >= 0 && position + 1 < ordered.size()) {
            castCandidateIndex = ordered.get(position + 1);
            loadCastCandidate(session, castCandidateIndex, true);
        } else {
            showStatus("Aucun flux n'a été accepté par le téléviseur. Désactivez temporairement le VPN et vérifiez que téléphone et téléviseur utilisent le même Wi-Fi.", false);
        }
    }

    public void onCastPermissionResult(boolean granted) {
        if (granted) requestCast();
        else showStatus("Autorisez les appareils à proximité pour rechercher Chromecast.", false);
    }

    private boolean hasCastPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            return activity.checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED;
        }
        return activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestCastPermission() {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                activity.requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES}, REQUEST_CAST_PERMISSION);
            } else {
                activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CAST_PERMISSION);
            }
        } catch (Throwable error) {
            showStatus("Autorisation Chromecast impossible : " + readable(error), false);
        }
    }

    public boolean isOpen() {
        return getVisibility() == VISIBLE;
    }

    public void close() {
        pendingCastRequest = false;
        releasePlayer();
        stopProxy();
        setVisibility(GONE);
        activity.onNativePlayerClosed();
    }

    public void release() {
        close();
        if (castContext != null) {
            try { castContext.getSessionManager().removeSessionManagerListener(castSessionListener, CastSession.class); }
            catch (Throwable ignored) { }
        }
        castExecutor.shutdownNow();
    }

    private void releasePlayer() {
        if (playerView != null) playerView.setPlayer(null);
        if (player != null) {
            try { player.release(); } catch (Throwable ignored) { }
            player = null;
        }
    }

    private void stopProxy() {
        if (castProxy != null) {
            try { castProxy.stop(); } catch (Throwable ignored) { }
            castProxy = null;
        }
    }

    private long currentPosition() {
        return player == null ? requestedPositionMs : Math.max(0L, player.getCurrentPosition());
    }

    private void enterPip() {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            activity.enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(new Rational(16, 9)).build());
        } catch (Throwable error) {
            showStatus("Picture-in-Picture indisponible", false);
        }
    }

    public void onPictureInPictureModeChanged(boolean inPip) {
        playerView.setUseController(!inPip);
    }

    private void showStatus(String message, boolean loading) {
        mainHandler.post(() -> {
            statusView.setText(message == null ? "" : message);
            progress.setVisibility(loading ? VISIBLE : GONE);
        });
    }

    private Button action(String label, OnClickListener listener) {
        Button button = new Button(activity);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(12f);
        button.setAllCaps(false);
        button.setBackgroundColor(0xCC20232B);
        button.setPadding(dp(12), 0, dp(12), 0);
        button.setOnClickListener(listener);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, dp(48));
        params.setMargins(dp(4), 0, 0, 0);
        button.setLayoutParams(params);
        return button;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static String removeHeaderIgnoreCase(Map<String, String> headers, String target) {
        String found = null;
        String remove = null;
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            if (target.equalsIgnoreCase(entry.getKey())) {
                found = entry.getValue();
                remove = entry.getKey();
                break;
            }
        }
        if (remove != null) headers.remove(remove);
        return found;
    }

    private static void removeBlankHeaders(Map<String, String> headers) {
        Iterator<Map.Entry<String, String>> iterator = headers.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            if (entry.getKey() == null || entry.getKey().trim().isEmpty()
                    || entry.getValue() == null || entry.getValue().trim().isEmpty()) iterator.remove();
        }
    }

    private static String readable(Throwable error) {
        if (error == null) return "erreur inconnue";
        String message = error.getMessage();
        return error.getClass().getSimpleName() + (message == null || message.trim().isEmpty() ? "" : " : " + message);
    }

    private static final class PlaybackCandidate {
        final String url;
        final String mime;
        final String label;
        final Map<String, String> headers;
        String lastError = "";

        PlaybackCandidate(String url, String mime, String label, Map<String, String> headers) {
            this.url = url == null ? "" : url.trim();
            this.mime = normalizeMime(mime, this.url);
            this.label = label == null || label.trim().isEmpty() ? labelFor(this.url) : label;
            this.headers = new HashMap<>(headers == null ? Collections.emptyMap() : headers);
        }

        static PlaybackCandidate fromJson(JSONObject object) {
            Map<String, String> headers = new HashMap<>();
            JSONObject rawHeaders = object.optJSONObject("headers");
            if (rawHeaders != null) {
                Iterator<String> keys = rawHeaders.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    String value = rawHeaders.optString(key, "");
                    if (!key.trim().isEmpty() && !value.trim().isEmpty()) headers.put(key, value);
                }
            }
            return new PlaybackCandidate(
                    object.optString("url", ""),
                    object.optString("mime", ""),
                    object.optString("label", ""),
                    headers
            );
        }

        boolean isValid() {
            return url.startsWith("http://") || url.startsWith("https://");
        }

        String castMime() {
            String lower = mime.toLowerCase(Locale.ROOT);
            if (lower.contains("mpegurl")) return "application/x-mpegURL";
            if (lower.contains("dash")) return "application/dash+xml";
            if (lower.contains("mp2t")) return "video/mp2t";
            if (lower.contains("webm")) return "video/webm";
            if (lower.contains("matroska")) return "video/x-matroska";
            return "video/mp4";
        }

        String describe() {
            return label + "\n" + mime + "\n" + safeUrl(url)
                    + (lastError.isEmpty() ? "" : "\nDernière erreur : " + lastError);
        }

        private static String normalizeMime(String input, String url) {
            String value = input == null ? "" : input.trim();
            if (!value.isEmpty() && !"application/octet-stream".equalsIgnoreCase(value)) return value;
            String lower = url.toLowerCase(Locale.ROOT);
            if (lower.contains(".m3u8")) return "application/x-mpegURL";
            if (lower.contains(".mpd")) return "application/dash+xml";
            if (lower.contains(".ts")) return "video/mp2t";
            if (lower.contains(".webm")) return "video/webm";
            if (lower.contains(".mkv")) return "video/x-matroska";
            return "video/mp4";
        }

        private static String labelFor(String url) {
            String lower = url.toLowerCase(Locale.ROOT);
            if (lower.contains(".m3u8")) return "HLS";
            if (lower.contains(".mp4")) return "MP4";
            if (lower.contains(".mkv")) return "MKV";
            if (lower.contains(".ts")) return "MPEG-TS";
            return "Flux serveur";
        }

        private static String safeUrl(String url) {
            try {
                Uri uri = Uri.parse(url);
                List<String> segments = uri.getPathSegments();
                if (segments.size() >= 4 && (segments.contains("movie") || segments.contains("series") || segments.contains("live"))) {
                    StringBuilder path = new StringBuilder();
                    for (int i = 0; i < segments.size(); i++) {
                        if (i == 1 || i == 2) path.append("/***");
                        else path.append('/').append(segments.get(i));
                    }
                    return uri.getScheme() + "://" + uri.getAuthority() + path;
                }
            } catch (Throwable ignored) { }
            return url.length() > 180 ? url.substring(0, 180) + "…" : url;
        }
    }
}
