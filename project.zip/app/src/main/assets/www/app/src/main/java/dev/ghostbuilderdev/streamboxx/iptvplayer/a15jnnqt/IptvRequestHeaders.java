package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import androidx.media3.datasource.DefaultHttpDataSource;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class IptvRequestHeaders {
    private static final DefaultHttpDataSource.Factory FACTORY =
            new DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true);

    private IptvRequestHeaders() {}

    public static synchronized DefaultHttpDataSource.Factory factory(String userAgent) {
        FACTORY.setUserAgent(userAgent == null || userAgent.trim().isEmpty() ? "HTMLtoAPK/Android" : userAgent);
        return FACTORY;
    }

    public static synchronized void setHeaders(String json) {
        Map<String, String> values = new HashMap<>();
        try {
            JSONObject object = new JSONObject(json == null || json.trim().isEmpty() ? "{}" : json);
            Iterator<String> names = object.keys();
            while (names.hasNext()) {
                String name = names.next();
                String value = object.optString(name, "");
                if (!name.trim().isEmpty() && !value.isEmpty()) values.put(name, value);
            }
        } catch (Exception ignored) {
        }
        FACTORY.setDefaultRequestProperties(values);
    }
}
