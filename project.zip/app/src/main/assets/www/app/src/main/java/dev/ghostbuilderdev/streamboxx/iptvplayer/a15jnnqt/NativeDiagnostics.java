package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import android.app.UiModeManager;
import android.content.Context;
import android.content.res.Configuration;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

public final class NativeDiagnostics {
    private NativeDiagnostics() {}

    public static String report(Context context) {
        try {
            JSONObject root = new JSONObject();
            root.put("sdk", Build.VERSION.SDK_INT);
            root.put("release", Build.VERSION.RELEASE);
            root.put("manufacturer", Build.MANUFACTURER);
            root.put("model", Build.MODEL);
            root.put("device", Build.DEVICE);
            root.put("abis", new JSONArray(Build.SUPPORTED_ABIS));
            UiModeManager uiMode = (UiModeManager) context.getSystemService(Context.UI_MODE_SERVICE);
            root.put("television", uiMode != null && uiMode.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION);
            root.put("network", network(context));
            root.put("codecs", codecs());
            root.put("package", context.getPackageName());
            return root.toString();
        } catch (Exception error) {
            return "{}";
        }
    }

    private static JSONObject network(Context context) throws Exception {
        JSONObject result = new JSONObject();
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) return result.put("connected", false);
        Network active = manager.getActiveNetwork();
        NetworkCapabilities capabilities = active == null ? null : manager.getNetworkCapabilities(active);
        result.put("connected", capabilities != null);
        if (capabilities != null) {
            result.put("internet", capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET));
            result.put("validated", capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED));
            result.put("wifi", capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI));
            result.put("cellular", capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
            result.put("ethernet", capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
            result.put("vpn", capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN));
            result.put("downKbps", capabilities.getLinkDownstreamBandwidthKbps());
            result.put("upKbps", capabilities.getLinkUpstreamBandwidthKbps());
        }
        return result;
    }

    private static JSONArray codecs() {
        JSONArray output = new JSONArray();
        try {
            MediaCodecInfo[] infos = new MediaCodecList(MediaCodecList.ALL_CODECS).getCodecInfos();
            int emitted = 0;
            for (MediaCodecInfo info : infos) {
                if (info.isEncoder()) continue;
                JSONObject codec = new JSONObject();
                codec.put("name", info.getName());
                JSONArray types = new JSONArray();
                for (String type : info.getSupportedTypes()) {
                    if (type.startsWith("video/") || type.startsWith("audio/")) types.put(type);
                }
                if (types.length() == 0) continue;
                codec.put("types", types);
                codec.put("hardware", Build.VERSION.SDK_INT >= 29 && info.isHardwareAccelerated());
                output.put(codec);
                emitted++;
                if (emitted >= 80) break;
            }
        } catch (Exception ignored) {
        }
        return output;
    }
}
