package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class IptvSyncWorker extends Worker {
    public static final String KEY_NAME = "name";
    public static final String KEY_URL = "url";

    public IptvSyncWorker(@NonNull Context context, @NonNull WorkerParameters parameters) {
        super(context, parameters);
    }

    @NonNull
    @Override
    public Result doWork() {
        String name = clean(getInputData().getString(KEY_NAME));
        String url = getInputData().getString(KEY_URL);
        if (url == null || url.trim().isEmpty()) return Result.failure();
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", "iPTV player/Android-Sync");
            int code = connection.getResponseCode();
            if (code == 429 || code >= 500) return Result.retry();
            if (code < 200 || code >= 300) return Result.failure(new Data.Builder().putInt("httpCode", code).build());
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[16384];
            int count;
            long total = 0L;
            try (java.io.InputStream input = connection.getInputStream()) {
                while ((count = input.read(buffer)) >= 0) {
                    total += count;
                    if (total > 25L * 1024L * 1024L) return Result.failure();
                    output.write(buffer, 0, count);
                }
            }
            File directory = new File(getApplicationContext().getFilesDir(), "iptv-sync");
            if (!directory.exists() && !directory.mkdirs()) return Result.failure();
            File target = new File(directory, name + ".cache");
            try (FileOutputStream file = new FileOutputStream(target)) {
                output.writeTo(file);
            }
            Data result = new Data.Builder()
                    .putInt("httpCode", code)
                    .putLong("bytes", total)
                    .putString("path", target.getAbsolutePath())
                    .build();
            return Result.success(result);
        } catch (Exception error) {
            return getRunAttemptCount() < 3 ? Result.retry() : Result.failure();
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static String clean(String value) {
        String name = value == null ? "default" : value.replaceAll("[^a-zA-Z0-9._-]", "_");
        return name.isEmpty() ? "default" : name;
    }

    public static String read(Context context, String name) {
        File file = new File(new File(context.getFilesDir(), "iptv-sync"), clean(name) + ".cache");
        if (!file.exists() || file.length() > 25L * 1024L * 1024L) return "";
        try (FileInputStream input = new FileInputStream(file); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16384];
            int count;
            while ((count = input.read(buffer)) >= 0) output.write(buffer, 0, count);
            return output.toString(StandardCharsets.UTF_8.name());
        } catch (Exception error) {
            return "";
        }
    }
}
