package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;

import fi.iki.elonen.NanoHTTPD;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Relais HTTP local utilisé seulement lorsque le récepteur Cast ne peut pas
 * joindre directement le serveur IPTV. Il conserve les en-têtes nécessaires,
 * prend en charge Range et réécrit les playlists HLS.
 */
public final class CastProxyServer extends NanoHTTPD {
    private static final int MAX_REDIRECTS = 6;
    private static final Pattern HLS_URI = Pattern.compile("URI=\\\"([^\\\"]+)\\\"");

    private final Context context;
    private final Map<String, String> upstreamHeaders;
    private final Map<String, String> sources = new ConcurrentHashMap<>();

    public CastProxyServer(Context context, Map<String, String> upstreamHeaders) {
        super(0);
        this.context = context.getApplicationContext();
        this.upstreamHeaders = new HashMap<>();
        if (upstreamHeaders != null) this.upstreamHeaders.putAll(upstreamHeaders);
        if (!containsHeader(this.upstreamHeaders, "User-Agent")) {
            this.upstreamHeaders.put(
                    "User-Agent",
                    System.getProperty("http.agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36")
            );
        }
        this.upstreamHeaders.putIfAbsent("Accept", "*/*");
    }

    public void startServer() throws IOException {
        start(SOCKET_READ_TIMEOUT, false);
        if (getListeningPort() <= 0) throw new IOException("Port du relais indisponible");
        if (findWifiIpv4().isEmpty()) throw new IOException("Adresse Wi-Fi introuvable");
    }

    public String publicUrl(String upstream) throws IOException {
        String host = findWifiIpv4();
        if (host.isEmpty()) throw new IOException("Le téléphone n'est pas relié à un Wi-Fi local");
        String token = UUID.randomUUID().toString().replace("-", "");
        sources.put(token, upstream);
        return "http://" + host + ":" + getListeningPort() + "/stream/" + token;
    }

    @Override
    public Response serve(IHTTPSession session) {
        if (session.getMethod() == Method.OPTIONS) {
            return withCors(newFixedLengthResponse(Response.Status.NO_CONTENT, MIME_PLAINTEXT, ""));
        }
        String uri = session.getUri() == null ? "" : session.getUri();
        if (!uri.startsWith("/stream/")) {
            return withCors(newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Flux inconnu"));
        }
        String token = uri.substring("/stream/".length());
        String source = sources.get(token);
        if (source == null || source.trim().isEmpty()) {
            return withCors(newFixedLengthResponse(Response.Status.GONE, MIME_PLAINTEXT, "Lien expiré"));
        }
        return proxy(session, source);
    }

    private Response proxy(IHTTPSession session, String initialSource) {
        HttpURLConnection connection = null;
        try {
            OpenedConnection opened = openFollowingRedirects(initialSource, session);
            connection = opened.connection;
            String finalSource = opened.finalUrl;
            int code = connection.getResponseCode();
            String contentType = cleanContentType(connection.getContentType(), finalSource);
            InputStream input = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
            if (input == null) input = new ByteArrayInputStream(new byte[0]);

            if (session.getMethod() == Method.HEAD) {
                Response response = newFixedLengthResponse(status(code), contentType, "");
                copyHeaders(connection, response);
                connection.disconnect();
                return withCors(response);
            }

            if (isPlaylist(finalSource, contentType)) {
                String body = readText(input);
                String rewritten = rewritePlaylist(body, finalSource);
                byte[] bytes = rewritten.getBytes(StandardCharsets.UTF_8);
                Response response = newFixedLengthResponse(
                        status(code),
                        "application/vnd.apple.mpegurl",
                        new ByteArrayInputStream(bytes),
                        bytes.length
                );
                response.addHeader("Cache-Control", "no-store");
                connection.disconnect();
                return withCors(response);
            }

            final HttpURLConnection heldConnection = connection;
            InputStream wrapped = new FilterInputStream(input) {
                @Override public void close() throws IOException {
                    try { super.close(); }
                    finally { heldConnection.disconnect(); }
                }
            };
            long length = connection.getContentLengthLong();
            Response response = length >= 0
                    ? newFixedLengthResponse(status(code), contentType, wrapped, length)
                    : newChunkedResponse(status(code), contentType, wrapped);
            copyHeaders(connection, response);
            return withCors(response);
        } catch (Throwable error) {
            if (connection != null) connection.disconnect();
            return withCors(newFixedLengthResponse(
                    Response.Status.INTERNAL_ERROR,
                    MIME_PLAINTEXT,
                    "Relais IPTV : " + (error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage())
            ));
        }
    }

    private OpenedConnection openFollowingRedirects(String initialSource, IHTTPSession session) throws IOException {
        String source = initialSource;
        for (int redirect = 0; redirect <= MAX_REDIRECTS; redirect++) {
            HttpURLConnection connection = (HttpURLConnection) new URL(source).openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(20_000);
            connection.setReadTimeout(60_000);
            connection.setUseCaches(false);
            connection.setRequestMethod(session.getMethod() == Method.HEAD ? "HEAD" : "GET");
            for (Map.Entry<String, String> header : upstreamHeaders.entrySet()) {
                if (header.getKey() != null && header.getValue() != null && !header.getValue().trim().isEmpty()) {
                    connection.setRequestProperty(header.getKey(), header.getValue());
                }
            }
            String range = headerIgnoreCase(session.getHeaders(), "range");
            if (range != null && !range.trim().isEmpty()) connection.setRequestProperty("Range", range);
            connection.connect();
            int code = connection.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String location = connection.getHeaderField("Location");
                if (location == null || location.trim().isEmpty()) return new OpenedConnection(connection, source);
                String resolved = URI.create(source).resolve(location).toString();
                connection.disconnect();
                source = resolved;
                continue;
            }
            return new OpenedConnection(connection, source);
        }
        throw new IOException("Trop de redirections HTTP");
    }

    private String rewritePlaylist(String playlist, String baseUrl) throws IOException {
        StringBuilder output = new StringBuilder();
        String[] lines = playlist.replace("\r", "").split("\n", -1);
        for (String raw : lines) {
            String line = raw;
            if (line.startsWith("#")) {
                Matcher matcher = HLS_URI.matcher(line);
                StringBuffer buffer = new StringBuffer();
                while (matcher.find()) {
                    String replacement = publicUrl(resolve(baseUrl, matcher.group(1)));
                    matcher.appendReplacement(buffer, "URI=\"" + Matcher.quoteReplacement(replacement) + "\"");
                }
                matcher.appendTail(buffer);
                line = buffer.toString();
            } else if (!line.trim().isEmpty()) {
                line = publicUrl(resolve(baseUrl, line.trim()));
            }
            output.append(line).append('\n');
        }
        return output.toString();
    }

    private String findWifiIpv4() {
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) return "";
        try {
            for (Network network : manager.getAllNetworks()) {
                NetworkCapabilities capabilities = manager.getNetworkCapabilities(network);
                if (capabilities == null || !capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue;
                LinkProperties properties = manager.getLinkProperties(network);
                if (properties == null) continue;
                for (LinkAddress linkAddress : properties.getLinkAddresses()) {
                    InetAddress address = linkAddress.getAddress();
                    if (address instanceof Inet4Address && !address.isLoopbackAddress() && !address.isLinkLocalAddress()) {
                        return address.getHostAddress();
                    }
                }
            }
        } catch (Throwable ignored) { }
        return "";
    }

    private static boolean isPlaylist(String url, String contentType) {
        String lowerUrl = url.toLowerCase(Locale.ROOT);
        String lowerType = contentType.toLowerCase(Locale.ROOT);
        return lowerUrl.contains(".m3u8") || lowerType.contains("mpegurl");
    }

    private static String cleanContentType(String input, String source) {
        String type = input == null ? "" : input.split(";", 2)[0].trim();
        if (!type.isEmpty() && !"application/octet-stream".equalsIgnoreCase(type)) return type;
        String lower = source.toLowerCase(Locale.ROOT);
        if (lower.contains(".m3u8")) return "application/vnd.apple.mpegurl";
        if (lower.contains(".mpd")) return "application/dash+xml";
        if (lower.contains(".ts")) return "video/mp2t";
        if (lower.contains(".webm")) return "video/webm";
        if (lower.contains(".mkv")) return "video/x-matroska";
        return "video/mp4";
    }

    private static String resolve(String base, String value) {
        try { return URI.create(base).resolve(value).toString(); }
        catch (Throwable ignored) { return value; }
    }

    private static String readText(InputStream input) throws IOException {
        try (InputStream source = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16_384];
            int count;
            while ((count = source.read(buffer)) >= 0) output.write(buffer, 0, count);
            return output.toString(StandardCharsets.UTF_8.name());
        }
    }

    private static Response.Status status(int code) {
        for (Response.Status value : Response.Status.values()) {
            if (value.getRequestStatus() == code) return value;
        }
        return code >= 200 && code < 300 ? Response.Status.OK : Response.Status.INTERNAL_ERROR;
    }

    private static void copyHeaders(HttpURLConnection connection, Response response) {
        copyHeader(connection, response, "Accept-Ranges");
        copyHeader(connection, response, "Content-Range");
        copyHeader(connection, response, "Content-Length");
        copyHeader(connection, response, "Cache-Control");
        copyHeader(connection, response, "ETag");
        copyHeader(connection, response, "Last-Modified");
    }

    private static void copyHeader(HttpURLConnection connection, Response response, String name) {
        String value = connection.getHeaderField(name);
        if (value != null && !value.trim().isEmpty()) response.addHeader(name, value);
    }

    private static Response withCors(Response response) {
        response.addHeader("Access-Control-Allow-Origin", "*");
        response.addHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
        response.addHeader("Access-Control-Allow-Headers", "Range, Content-Type, Authorization, Origin, Accept");
        response.addHeader("Access-Control-Expose-Headers", "Content-Length, Content-Range, Accept-Ranges, Content-Type");
        response.addHeader("Connection", "close");
        return response;
    }

    private static boolean containsHeader(Map<String, String> headers, String wanted) {
        for (String key : headers.keySet()) if (wanted.equalsIgnoreCase(key)) return true;
        return false;
    }

    private static String headerIgnoreCase(Map<String, String> headers, String wanted) {
        if (headers == null) return null;
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            if (wanted.equalsIgnoreCase(entry.getKey())) return entry.getValue();
        }
        return null;
    }

    private static final class OpenedConnection {
        final HttpURLConnection connection;
        final String finalUrl;

        OpenedConnection(HttpURLConnection connection, String finalUrl) {
            this.connection = connection;
            this.finalUrl = finalUrl;
        }
    }
}
