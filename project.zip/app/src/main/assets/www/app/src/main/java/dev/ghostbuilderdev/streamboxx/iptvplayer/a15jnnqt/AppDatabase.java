package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {FavoriteEntity.class, HistoryEntity.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    private static volatile AppDatabase instance;
    public abstract IptvDao iptvDao();

    public static AppDatabase get(Context context) {
        AppDatabase local = instance;
        if (local == null) {
            synchronized (AppDatabase.class) {
                local = instance;
                if (local == null) {
                    local = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "iptv-native.db"
                    ).fallbackToDestructiveMigration().build();
                    instance = local;
                }
            }
        }
        return local;
    }
}
