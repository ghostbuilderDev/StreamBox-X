package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "history")
public class HistoryEntity {
    @PrimaryKey @NonNull public String itemId = "";
    @NonNull public String payloadJson = "{}";
    public long positionMs;
    public long durationMs;
    public boolean completed;
    public long updatedAt;
}
