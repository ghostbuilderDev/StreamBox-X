package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface IptvDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void upsertFavorite(FavoriteEntity favorite);

    @Query("DELETE FROM favorites WHERE type = :type AND itemId = :itemId")
    void deleteFavorite(String type, String itemId);

    @Query("SELECT * FROM favorites WHERE (:type = '' OR type = :type) ORDER BY updatedAt DESC")
    List<FavoriteEntity> favorites(String type);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void upsertHistory(HistoryEntity history);

    @Query("SELECT * FROM history ORDER BY updatedAt DESC LIMIT :limit")
    List<HistoryEntity> history(int limit);

    @Query("DELETE FROM history WHERE itemId = :itemId")
    void deleteHistory(String itemId);

    @Query("DELETE FROM history")
    void clearHistory();
}
