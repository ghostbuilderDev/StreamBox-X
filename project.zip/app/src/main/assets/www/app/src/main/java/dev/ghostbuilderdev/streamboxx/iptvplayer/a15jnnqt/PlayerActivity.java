package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import android.app.PictureInPictureParams;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.ui.PlayerView;
import androidx.media3.cast.MediaRouteButtonViewProvider;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.MoreExecutors;

@UnstableApi
public final class PlayerActivity extends FragmentActivity {
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_POSTER = "poster";
    public static final String EXTRA_HEADERS = "headers";
    public static final String EXTRA_START_POSITION = "startPosition";
    public static final String EXTRA_AUTOPLAY = "autoplay";
    public static final String EXTRA_AUDIO_LANGUAGE = "audioLanguage";
    public static final String EXTRA_TEXT_LANGUAGE = "textLanguage";
    public static final String EXTRA_MAX_VIDEO_HEIGHT = "maxVideoHeight";

    private PlayerView playerView;
    private LinearLayout actionBar;
    private ListenableFuture<MediaController> controllerFuture;
    private MediaController controller;
    private String mediaUrl = "";
    private String mediaTitle = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildInterface();
        connectController();
    }

    private void buildInterface() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerView.setKeepScreenOn(true);
        playerView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        playerView.setMediaRouteButtonViewProvider(new MediaRouteButtonViewProvider());
        root.addView(playerView);

        actionBar = new LinearLayout(this);
        actionBar.setOrientation(LinearLayout.HORIZONTAL);
        actionBar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        actionBar.setPadding(12, 12, 12, 12);
        FrameLayout.LayoutParams barParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END
        );
        actionBar.setLayoutParams(barParams);

        Button pipButton = actionButton("PiP");
        pipButton.setOnClickListener(v -> enterPip());
        actionBar.addView(pipButton);

        Button externalButton = actionButton("Externe");
        externalButton.setOnClickListener(v -> openExternalPlayer());
        actionBar.addView(externalButton);

        Button closeButton = actionButton("Fermer");
        closeButton.setOnClickListener(v -> stopAndClose());
        actionBar.addView(closeButton);
        root.addView(actionBar);
        setContentView(root);
    }

    private Button actionButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(0x99000000);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setPadding(18, 8, 18, 8);
        button.setFocusable(true);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(6, 0, 0, 0);
        button.setLayoutParams(params);
        return button;
    }

    private void connectController() {
        SessionToken token = new SessionToken(
                this,
                new ComponentName(this, IptvPlaybackService.class)
        );
        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        controllerFuture.addListener(() -> {
            try {
                controller = controllerFuture.get();
                playerView.setPlayer(controller);
                prepareRequestedMedia();
            } catch (Exception error) {
                Toast.makeText(this, "Lecteur natif indisponible : " + error.getMessage(), Toast.LENGTH_LONG).show();
                finish();
            }
        }, MoreExecutors.directExecutor());
    }

    private void prepareRequestedMedia() {
        Intent intent = getIntent();
        mediaUrl = safe(intent.getStringExtra(EXTRA_URL));
        mediaTitle = safe(intent.getStringExtra(EXTRA_TITLE));
        String poster = safe(intent.getStringExtra(EXTRA_POSTER));
        String headersJson = safe(intent.getStringExtra(EXTRA_HEADERS));
        IptvRequestHeaders.setHeaders(headersJson);
        long startPosition = intent.getLongExtra(EXTRA_START_POSITION, -1L);
        boolean autoplay = intent.getBooleanExtra(EXTRA_AUTOPLAY, true);
        String audioLanguage = safe(intent.getStringExtra(EXTRA_AUDIO_LANGUAGE));
        String textLanguage = safe(intent.getStringExtra(EXTRA_TEXT_LANGUAGE));
        int maxHeight = intent.getIntExtra(EXTRA_MAX_VIDEO_HEIGHT, 0);

        if (mediaUrl.isEmpty()) {
            Toast.makeText(this, "Adresse du flux absente", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        String mediaId = Integer.toHexString(mediaUrl.hashCode());
        if (startPosition < 0L) {
            startPosition = getSharedPreferences("playback_state", MODE_PRIVATE)
                    .getLong("position_" + mediaId, 0L);
        }

        MediaMetadata.Builder metadata = new MediaMetadata.Builder().setTitle(mediaTitle);
        if (!poster.isEmpty()) metadata.setArtworkUri(Uri.parse(poster));
        MediaItem mediaItem = new MediaItem.Builder()
                .setMediaId(mediaId)
                .setUri(Uri.parse(mediaUrl))
                .setMediaMetadata(metadata.build())
                .build();

        TrackSelectionParameters.Builder parameters = controller
                .getTrackSelectionParameters()
                .buildUpon();
        if (!audioLanguage.isEmpty()) parameters.setPreferredAudioLanguage(audioLanguage);
        if (!textLanguage.isEmpty()) parameters.setPreferredTextLanguage(textLanguage);
        if (maxHeight > 0) parameters.setMaxVideoSize(Integer.MAX_VALUE, maxHeight);
        controller.setTrackSelectionParameters(parameters.build());
        controller.setMediaItem(mediaItem, Math.max(0L, startPosition));
        controller.prepare();
        if (autoplay) controller.play();
        setTitle(mediaTitle);
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private void stopAndClose() {
        if (controller != null) {
            controller.stop();
            controller.clearMediaItems();
        }
        finish();
    }

    private void openExternalPlayer() {
        if (mediaUrl.isEmpty()) return;
        if (controller != null) controller.pause();
        try {
            Intent external = new Intent(Intent.ACTION_VIEW);
            external.setDataAndType(Uri.parse(mediaUrl), "video/*");
            external.putExtra("title", mediaTitle);
            external.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(external, "Choisir un lecteur vidéo"));
        } catch (Exception error) {
            Toast.makeText(this, "Aucun lecteur externe compatible", Toast.LENGTH_LONG).show();
        }
    }

    private void enterPip() {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(16, 9));
            if (Build.VERSION.SDK_INT >= 31) builder.setAutoEnterEnabled(true);
            enterPictureInPictureMode(builder.build());
        } catch (Exception error) {
            Toast.makeText(this, "Mode PiP indisponible", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (controller != null && controller.isPlaying()) enterPip();
    }

    @Override
    public void onPictureInPictureModeChanged(boolean inPictureInPictureMode, Configuration newConfig) {
        super.onPictureInPictureModeChanged(inPictureInPictureMode, newConfig);
        playerView.setUseController(!inPictureInPictureMode);
        actionBar.setVisibility(inPictureInPictureMode ? View.GONE : View.VISIBLE);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (controller != null) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                controller.seekTo(Math.max(0L, controller.getCurrentPosition() - 10000L));
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                controller.seekTo(controller.getCurrentPosition() + 10000L);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
                if (controller.isPlaying()) controller.pause(); else controller.play();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        playerView.setPlayer(null);
        if (controllerFuture != null) {
            MediaController.releaseFuture(controllerFuture);
            controllerFuture = null;
            controller = null;
        }
        super.onDestroy();
    }
}
