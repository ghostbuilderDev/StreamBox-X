package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import android.app.Activity;
import android.app.PictureInPictureParams;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.util.Rational;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class IptvNativeBridge {
    protected final Activity activity;

    public IptvNativeBridge(Activity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public String getNativeCapabilities() {
        try {
            JSONObject value = new JSONObject();
            value.put("native", true);
            value.put("media3", true);
            value.put("mediaSession", true);
            value.put("cast", true);
            value.put("pip", true);
            value.put("room", true);
            value.put("workManager", true);
            value.put("notifications", true);
            value.put("androidTv", true);
            value.put("secureStore", true);
            value.put("diagnostics", true);
            value.put("files", true);
            value.put("sdk", Build.VERSION.SDK_INT);
            return value.toString();
        } catch (Exception error) {
            return "{}";
        }
    }

    private boolean launchNativePlayer(String url, String title, String poster, String headersJson, long startPositionMs, boolean autoplay, boolean requestCast) {
        if (url == null || url.trim().isEmpty()) return false;
        try {
            final Intent intent = new Intent(activity, PlayerActivity.class);
            intent.putExtra(PlayerActivity.EXTRA_URL, url.trim());
            intent.putExtra(PlayerActivity.EXTRA_TITLE, title == null ? "" : title);
            intent.putExtra(PlayerActivity.EXTRA_POSTER, poster == null ? "" : poster);
            intent.putExtra(PlayerActivity.EXTRA_HEADERS, headersJson == null ? "{}" : headersJson);
            intent.putExtra(PlayerActivity.EXTRA_START_POSITION, startPositionMs);
            intent.putExtra(PlayerActivity.EXTRA_AUTOPLAY, autoplay);
            intent.putExtra(PlayerActivity.EXTRA_REQUEST_CAST, requestCast);
            activity.runOnUiThread(() -> activity.startActivity(intent));
            return true;
        } catch (Throwable error) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean openNativePlayer(String url, String title, String poster, String headersJson, long startPositionMs, boolean autoplay) {
        return launchNativePlayer(url, title, poster, headersJson, startPositionMs, autoplay, false);
    }

    @JavascriptInterface
    public boolean openNativePlayerForCast(String url, String title, String poster, String headersJson, long startPositionMs, boolean autoplay) {
        return launchNativePlayer(url, title, poster, headersJson, startPositionMs, autoplay, true);
    }

    @JavascriptInterface
    public boolean playNative(String url, String title) {
        return openNativePlayer(url, title, "", "{}", -1L, true);
    }

    @JavascriptInterface
    public boolean openExternalPlayer(String url, String title) {
        try {
            Intent external = new Intent(Intent.ACTION_VIEW);
            external.setDataAndType(Uri.parse(url), "video/*");
            external.putExtra("title", title == null ? "" : title);
            activity.runOnUiThread(() -> activity.startActivity(Intent.createChooser(external, "Choisir un lecteur vidéo")));
            return true;
        } catch (Throwable error) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean enterPictureInPicture() {
        if (Build.VERSION.SDK_INT < 26) return false;
        try {
            activity.enterPictureInPictureMode(new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(16, 9))
                    .build());
            return true;
        } catch (Exception error) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean isTelevision() {
        UiModeManager manager = (UiModeManager) activity.getSystemService(Context.UI_MODE_SERVICE);
        return manager != null && manager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION;
    }

    @JavascriptInterface
    public boolean secureSet(String name, String value) {
        return SecureStore.put(activity, name, value);
    }

    @JavascriptInterface
    public String secureGet(String name, String fallback) {
        return SecureStore.get(activity, name, fallback == null ? "" : fallback);
    }

    @JavascriptInterface
    public boolean secureRemove(String name) {
        return SecureStore.remove(activity, name);
    }

    @JavascriptInterface
    public boolean saveFavorite(String type, String itemId, String payloadJson) {
        try {
            FavoriteEntity item = new FavoriteEntity();
            item.type = type == null ? "" : type;
            item.itemId = itemId == null ? "" : itemId;
            item.payloadJson = payloadJson == null ? "{}" : payloadJson;
            item.updatedAt = System.currentTimeMillis();
            AppDatabase.get(activity).iptvDao().upsertFavorite(item);
            return true;
        } catch (Exception error) { return false; }
    }

    @JavascriptInterface
    public boolean removeFavorite(String type, String itemId) {
        try {
            AppDatabase.get(activity).iptvDao().deleteFavorite(type == null ? "" : type, itemId == null ? "" : itemId);
            return true;
        } catch (Exception error) { return false; }
    }

    @JavascriptInterface
    public String getFavorites(String type) {
        try {
            List<FavoriteEntity> items = AppDatabase.get(activity).iptvDao().favorites(type == null ? "" : type);
            JSONArray array = new JSONArray();
            for (FavoriteEntity item : items) {
                JSONObject row = new JSONObject();
                row.put("type", item.type);
                row.put("itemId", item.itemId);
                row.put("payload", new JSONObject(item.payloadJson));
                row.put("updatedAt", item.updatedAt);
                array.put(row);
            }
            return array.toString();
        } catch (Exception error) { return "[]"; }
    }

    @JavascriptInterface
    public boolean saveHistory(String itemId, String payloadJson, long positionMs, long durationMs, boolean completed) {
        try {
            HistoryEntity item = new HistoryEntity();
            item.itemId = itemId == null ? "" : itemId;
            item.payloadJson = payloadJson == null ? "{}" : payloadJson;
            item.positionMs = Math.max(0L, positionMs);
            item.durationMs = Math.max(0L, durationMs);
            item.completed = completed;
            item.updatedAt = System.currentTimeMillis();
            AppDatabase.get(activity).iptvDao().upsertHistory(item);
            return true;
        } catch (Exception error) { return false; }
    }

    @JavascriptInterface
    public String getHistory(int limit) {
        try {
            List<HistoryEntity> items = AppDatabase.get(activity).iptvDao().history(Math.max(1, Math.min(limit, 1000)));
            JSONArray array = new JSONArray();
            for (HistoryEntity item : items) {
                JSONObject row = new JSONObject();
                row.put("itemId", item.itemId);
                row.put("payload", new JSONObject(item.payloadJson));
                row.put("positionMs", item.positionMs);
                row.put("durationMs", item.durationMs);
                row.put("completed", item.completed);
                row.put("updatedAt", item.updatedAt);
                array.put(row);
            }
            return array.toString();
        } catch (Exception error) { return "[]"; }
    }

    @JavascriptInterface
    public boolean deleteHistory(String itemId) {
        try { AppDatabase.get(activity).iptvDao().deleteHistory(itemId == null ? "" : itemId); return true; }
        catch (Exception error) { return false; }
    }

    @JavascriptInterface
    public boolean clearHistory() {
        try { AppDatabase.get(activity).iptvDao().clearHistory(); return true; }
        catch (Exception error) { return false; }
    }

    @JavascriptInterface
    public boolean schedulePeriodicSync(String name, String url, int intervalMinutes) {
        try {
            String safeName = name == null || name.trim().isEmpty() ? "default" : name.trim();
            Data data = new Data.Builder().putString(IptvSyncWorker.KEY_NAME, safeName).putString(IptvSyncWorker.KEY_URL, url).build();
            Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
            PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                    IptvSyncWorker.class,
                    Math.max(15, intervalMinutes),
                    TimeUnit.MINUTES
            ).setInputData(data).setConstraints(constraints).build();
            WorkManager.getInstance(activity).enqueueUniquePeriodicWork(
                    "iptv-sync-" + safeName,
                    ExistingPeriodicWorkPolicy.UPDATE,
                    request
            );
            return true;
        } catch (Exception error) { return false; }
    }

    @JavascriptInterface
    public boolean syncNow(String name, String url) {
        try {
            String safeName = name == null || name.trim().isEmpty() ? "default" : name.trim();
            Data data = new Data.Builder().putString(IptvSyncWorker.KEY_NAME, safeName).putString(IptvSyncWorker.KEY_URL, url).build();
            Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
            OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(IptvSyncWorker.class)
                    .setInputData(data).setConstraints(constraints).build();
            WorkManager.getInstance(activity).enqueueUniqueWork("iptv-sync-now-" + safeName, ExistingWorkPolicy.REPLACE, request);
            return true;
        } catch (Exception error) { return false; }
    }

    @JavascriptInterface
    public String readSyncCache(String name) {
        return IptvSyncWorker.read(activity, name);
    }

    @JavascriptInterface
    public boolean cancelSync(String name) {
        try {
            String safeName = name == null || name.trim().isEmpty() ? "default" : name.trim();
            WorkManager.getInstance(activity).cancelUniqueWork("iptv-sync-" + safeName);
            WorkManager.getInstance(activity).cancelUniqueWork("iptv-sync-now-" + safeName);
            return true;
        } catch (Exception error) { return false; }
    }

    @JavascriptInterface
    public boolean showLocalNotification(int id, String title, String message) {
        return NotificationHelper.show(activity, id, title, message);
    }

    @JavascriptInterface
    public String getNetworkDiagnostics() {
        return NativeDiagnostics.report(activity);
    }
}
