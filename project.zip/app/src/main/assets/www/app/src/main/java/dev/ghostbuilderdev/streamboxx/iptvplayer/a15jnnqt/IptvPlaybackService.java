package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.cast.Cast;
import androidx.media3.cast.CastPlayer;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

@UnstableApi
public final class IptvPlaybackService extends MediaSessionService {
    private ExoPlayer localPlayer;
    private Player sessionPlayer;
    private MediaSession mediaSession;
    private Handler persistenceHandler;

    private final Runnable persistenceTask = new Runnable() {
        @Override
        public void run() {
            persistPosition();
            if (persistenceHandler != null) persistenceHandler.postDelayed(this, 10000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        DefaultTrackSelector trackSelector = new DefaultTrackSelector(this);
        DefaultHttpDataSource.Factory httpFactory = IptvRequestHeaders.factory("iPTV player/Android");
        DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(httpFactory);
        localPlayer = new ExoPlayer.Builder(this)
                .setTrackSelector(trackSelector)
                .setMediaSourceFactory(mediaSourceFactory)
                .build();
        sessionPlayer = localPlayer;
        try {
            Cast cast = Cast.getSingletonInstance(this);
            if (cast.needsInitialization()) cast.initialize();
            sessionPlayer = new CastPlayer.Builder(this)
                    .setLocalPlayer(localPlayer)
                    .build();
        } catch (Throwable castError) {
            // Google Cast ne doit jamais empêcher la lecture locale.
            sessionPlayer = localPlayer;
        }
        mediaSession = new MediaSession.Builder(this, sessionPlayer)
                .setId("htmltoapk-iptv-session")
                .build();
        sessionPlayer.addListener(new Player.Listener() {
            @Override
            public void onMediaItemTransition(@Nullable MediaItem mediaItem, int reason) {
                persistPosition();
            }

            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_ENDED) persistPosition();
            }
        });
        persistenceHandler = new Handler(Looper.getMainLooper());
        persistenceHandler.postDelayed(persistenceTask, 10000L);
    }

    private void persistPosition() {
        if (sessionPlayer == null) return;
        MediaItem item = sessionPlayer.getCurrentMediaItem();
        if (item == null || item.mediaId == null || item.mediaId.isEmpty()) return;
        SharedPreferences preferences = getSharedPreferences("playback_state", MODE_PRIVATE);
        preferences.edit()
                .putLong("position_" + item.mediaId, Math.max(0L, sessionPlayer.getCurrentPosition()))
                .putLong("duration_" + item.mediaId, Math.max(0L, sessionPlayer.getDuration()))
                .putLong("updated_" + item.mediaId, System.currentTimeMillis())
                .apply();
    }

    @Nullable
    @Override
    public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    @Override
    public void onTaskRemoved(@Nullable Intent rootIntent) {
        persistPosition();
        if (sessionPlayer == null || !sessionPlayer.getPlayWhenReady()) stopSelf();
    }

    @Override
    public void onDestroy() {
        persistPosition();
        if (persistenceHandler != null) persistenceHandler.removeCallbacksAndMessages(null);
        if (mediaSession != null) mediaSession.release();
        if (sessionPlayer != null) sessionPlayer.release();
        if (localPlayer != null && localPlayer != sessionPlayer) localPlayer.release();
        mediaSession = null;
        sessionPlayer = null;
        localPlayer = null;
        super.onDestroy();
    }
}
