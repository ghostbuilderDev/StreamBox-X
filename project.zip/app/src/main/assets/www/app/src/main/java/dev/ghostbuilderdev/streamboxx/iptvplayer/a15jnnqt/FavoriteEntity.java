package dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt;

import androidx.annotation.NonNull;
import androidx.room.Entity;

@Entity(tableName = "favorites", primaryKeys = {"type", "itemId"})
public class FavoriteEntity {
    @NonNull public String type = "";
    @NonNull public String itemId = "";
    @NonNull public String payloadJson = "{}";
    public long updatedAt;
}
