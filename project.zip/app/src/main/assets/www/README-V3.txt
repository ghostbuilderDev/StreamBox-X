PRIME IPTV PLAYER 3.3 — CORRECTIF LECTURE / CAST

- Lecture Media3 locale prioritaire.
- Cast isolé : une panne du module Google Cast ne ferme plus le lecteur.
- Transfert Cast via le sélecteur de sortie de la notification Android MediaSession.
- Le lecteur externe reste disponible comme secours.
- À construire avec HTMLtoAPK V16.3 IPTV Lecture/Cast Stable.

PRIME IPTV PLAYER 3 — HTMLTOAPK V16 NATIVE

1. Ouvrir HTMLtoAPK V16 IPTV Native Complete.
2. Importer le ZIP complet de Prime IPTV Player 3.
3. Sélectionner le profil « IPTV / vidéo + Cast ».
4. Vérifier que les modules Media3, Cast, PiP, Room, WorkManager, Notifications, Android TV, Diagnostic et Sécurité sont cochés.
5. Conserver le package com.yoann.primeiptvplayer3 pour les futures mises à jour.
6. Compiler l’APK avec GitHub.

La V3 ne fournit aucun contenu IPTV. Elle lit uniquement les accès autorisés saisis par l’utilisateur.
