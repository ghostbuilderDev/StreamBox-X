(function(){
  const DB_NAME='PrimeIPTVDatabase';
  const STORE='keyvalue';
  const VERSION=1;
  const LS_PREFIX='primeiptv:';
  let promise;
  function open(){
    if(!('indexedDB' in window)) return Promise.resolve(null);
    if(promise) return promise;
    promise=new Promise((resolve,reject)=>{
      const req=indexedDB.open(DB_NAME,VERSION);
      req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE)};
      req.onsuccess=()=>resolve(req.result);
      req.onerror=()=>reject(req.error);
    }).catch(()=>null);
    return promise;
  }
  async function get(key,fallback=null){
    try{
      const db=await open();
      if(db){const value=await new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});if(value!==undefined)return value}
    }catch{}
    try{const raw=localStorage.getItem(LS_PREFIX+key);return raw===null?fallback:JSON.parse(raw)}catch{return fallback}
  }
  async function set(key,value){
    try{localStorage.setItem(LS_PREFIX+key,JSON.stringify(value))}catch{}
    try{const db=await open();if(db)await new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readwrite').objectStore(STORE).put(value,key);r.onsuccess=()=>resolve();r.onerror=()=>reject(r.error)})}catch{}
    return value;
  }
  async function del(key){
    try{localStorage.removeItem(LS_PREFIX+key)}catch{}
    try{const db=await open();if(db)await new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readwrite').objectStore(STORE).delete(key);r.onsuccess=()=>resolve();r.onerror=()=>reject(r.error)})}catch{}
  }
  window.PrimeDB={get,set,del,open};
})();
