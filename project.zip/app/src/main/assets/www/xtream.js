(function () {
  'use strict';

  const FETCH_TIMEOUT_MS = 25000;

  async function timeoutFetch(url, ms = FETCH_TIMEOUT_MS) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), ms);
    try {
      const response = await fetch(url, {
        signal: controller.signal,
        cache: 'no-store',
        redirect: 'follow'
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const text = await response.text();
      try {
        return JSON.parse(text);
      } catch {
        throw new Error('Réponse serveur invalide');
      }
    } finally {
      clearTimeout(timer);
    }
  }

  function normalizeServer(value) {
    let server = String(value || '').trim().replace(/\/+$/, '');
    if (!/^https?:\/\//i.test(server)) server = `http://${server}`;
    return server;
  }

  function queryValue(value) {
    return encodeURIComponent(String(value ?? ''));
  }

  function firstValue(...values) {
    for (const value of values) {
      if (value !== undefined && value !== null && String(value).trim() !== '') {
        return value;
      }
    }
    return '';
  }

  function streamId(value) {
    return String(firstValue(
      value?.stream_id,
      value?.id,
      value?.episode_id,
      value?.vod_id,
      value?.movie_id,
      value?.info?.stream_id,
      value?.info?.id,
      value?.movie_data?.stream_id,
      value?.movie_data?.id
    )).trim();
  }

  function cleanExtension(value, fallback = '') {
    const extension = String(value || fallback || '')
      .trim()
      .toLowerCase()
      .replace(/^\./, '')
      .split(/[?#]/)[0]
      .replace(/[^a-z0-9]/g, '');
    return extension;
  }

  function directUrls(value) {
    return [
      value?.direct_source,
      value?.stream_url,
      value?.play_url,
      value?.url,
      value?.link,
      value?.info?.direct_source,
      value?.info?.stream_url,
      value?.movie_data?.direct_source,
      value?.movie_data?.stream_url
    ];
  }

  function mimeFor(url, extension = '') {
    const source = `${String(url || '').toLowerCase()} ${String(extension || '').toLowerCase()}`;
    if (source.includes('.m3u8') || source.includes('m3u8')) return 'application/x-mpegURL';
    if (source.includes('.mpd') || source.includes('dash')) return 'application/dash+xml';
    if (source.includes('.mp4') || source.includes('mp4')) return 'video/mp4';
    if (source.includes('.mkv') || source.includes('mkv') || source.includes('matroska')) return 'video/x-matroska';
    if (source.includes('.webm') || source.includes('webm')) return 'video/webm';
    if (source.includes('.ts') || source.includes('mpegts')) return 'video/mp2t';
    return '';
  }

  function makeCandidate(url, options = {}) {
    const value = String(url || '').trim();
    if (!/^https?:\/\//i.test(value)) return null;
    return {
      url: value,
      mime: options.mime || mimeFor(value, options.extension),
      label: options.label || 'Flux serveur',
      source: options.source || 'generated',
      headers: options.headers || {}
    };
  }

  function uniqueCandidates(values) {
    const output = [];
    const seen = new Set();
    for (const raw of values) {
      const candidate = typeof raw === 'string' ? makeCandidate(raw) : raw;
      if (!candidate?.url) continue;
      const key = candidate.url.trim();
      if (seen.has(key)) continue;
      seen.add(key);
      output.push(candidate);
    }
    return output;
  }

  function orderedExtensions(original, kind) {
    const base = cleanExtension(original);
    const preferred = kind === 'live'
      ? [base, 'm3u8', 'ts']
      : [base, 'mp4', 'm3u8', 'mkv', 'ts'];
    return [...new Set(preferred.filter(Boolean))];
  }

  class XtreamClient {
    constructor(account) {
      this.account = { ...account, server: normalizeServer(account.server) };
    }

    apiUrl(action = '', extra = {}) {
      const { server, username, password } = this.account;
      const params = new URLSearchParams({ username, password });
      if (action) params.set('action', action);
      Object.entries(extra).forEach(([key, value]) => params.set(key, value));
      return `${server}/player_api.php?${params}`;
    }

    async request(action = '', extra = {}) {
      return timeoutFetch(this.apiUrl(action, extra));
    }

    async authenticate() {
      const data = await this.request();
      if (!data?.user_info) throw new Error('Compte Xtream non reconnu');
      if (String(data.user_info.auth ?? '1') !== '1') {
        throw new Error('Identifiants refusés par le serveur');
      }
      return data;
    }

    async loadCatalog() {
      const calls = {
        liveCategories: 'get_live_categories',
        movieCategories: 'get_vod_categories',
        seriesCategories: 'get_series_categories',
        live: 'get_live_streams',
        movies: 'get_vod_streams',
        series: 'get_series'
      };
      const entries = await Promise.all(Object.entries(calls).map(async ([key, action]) => {
        try {
          return [key, await this.request(action)];
        } catch {
          return [key, []];
        }
      }));
      return Object.fromEntries(entries.map(([key, value]) => [key, Array.isArray(value) ? value : []]));
    }

    getVodInfo(id) {
      return this.request('get_vod_info', { vod_id: id });
    }

    getSeriesInfo(id) {
      return this.request('get_series_info', { series_id: id });
    }

    getShortEpg(id, limit = 6) {
      return this.request('get_short_epg', { stream_id: id, limit });
    }

    pathCredentials(encoded = true) {
      const { username, password } = this.account;
      return {
        username: encoded ? queryValue(username) : String(username),
        password: encoded ? queryValue(password) : String(password)
      };
    }

    absoluteStreamUrl(value) {
      const raw = String(value || '').trim();
      if (!raw) return '';
      if (/^https?:\/\//i.test(raw)) return raw;
      try {
        return new URL(raw, `${this.account.server}/`).toString();
      } catch {
        return '';
      }
    }

    directCandidates(values, options = {}) {
      return values
        .map(value => this.absoluteStreamUrl(value))
        .map(url => makeCandidate(url, options));
    }

    generatedPaths(kind, id, extensions) {
      if (!id) return [];
      const { server } = this.account;
      const values = [];
      for (const encoded of [true, false]) {
        const credentials = this.pathCredentials(encoded);
        for (const extension of extensions) {
          values.push(`${server}/${kind}/${credentials.username}/${credentials.password}/${queryValue(id)}.${extension}`);
        }
      }
      return values;
    }

    liveCandidates(item, format = 'm3u8') {
      const id = streamId(item);
      const extension = cleanExtension(item?.container_extension, format || 'm3u8');
      const direct = this.directCandidates(directUrls(item), {
        label: 'Flux direct fourni',
        source: 'direct',
        extension
      });
      const generated = this.generatedPaths('live', id, orderedExtensions(format || extension, 'live'))
        .map(url => makeCandidate(url, { label: 'Flux direct', source: 'xtream' }));
      return uniqueCandidates([...direct, ...generated]);
    }

    movieCandidates(item, info = {}) {
      const movieData = info?.movie_data || {};
      const merged = { ...item, ...movieData, info: info?.info || {} };
      const id = streamId(merged) || streamId(item);
      const extension = cleanExtension(firstValue(
        movieData.container_extension,
        item?.container_extension,
        info?.info?.container_extension
      ), 'mp4');
      const direct = this.directCandidates(
        [...directUrls(movieData), ...directUrls(info?.info || {}), ...directUrls(item)],
        { label: 'Flux direct fourni', source: 'direct', extension }
      );
      const generated = this.generatedPaths('movie', id, orderedExtensions(extension, 'vod'))
        .map(url => makeCandidate(url, { label: 'Film Xtream', source: 'xtream' }));
      return uniqueCandidates([...direct, ...generated]);
    }

    episodeCandidates(episode) {
      const id = streamId(episode);
      const extension = cleanExtension(firstValue(
        episode?.container_extension,
        episode?.info?.container_extension,
        episode?.movie_data?.container_extension
      ), 'mp4');
      const direct = this.directCandidates(
        directUrls(episode),
        { label: 'Épisode direct fourni', source: 'direct', extension }
      );
      const generated = this.generatedPaths('series', id, orderedExtensions(extension, 'series'))
        .map(url => makeCandidate(url, { label: 'Épisode Xtream', source: 'xtream' }));
      return uniqueCandidates([...direct, ...generated]);
    }

    playbackDebug(value) {
      return {
        id: streamId(value),
        extension: cleanExtension(firstValue(
          value?.container_extension,
          value?.info?.container_extension,
          value?.movie_data?.container_extension
        )),
        keys: value && typeof value === 'object' ? Object.keys(value).sort() : []
      };
    }
  }

  function expiryInfo(userInfo = {}) {
    const raw = userInfo.exp_date;
    let date = null;
    if (raw && raw !== 'null' && raw !== '0') {
      const numeric = Number(raw);
      date = Number.isFinite(numeric) ? new Date(numeric * 1000) : new Date(raw);
      if (Number.isNaN(date.getTime())) date = null;
    }
    if (!date) {
      return {
        date: null,
        label: 'Sans date communiquée',
        remaining: 'Non communiqué',
        days: null,
        expired: false
      };
    }
    const difference = date.getTime() - Date.now();
    const days = Math.ceil(difference / 86400000);
    const expired = difference <= 0;
    return {
      date,
      label: date.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }),
      remaining: expired ? 'Expiré' : days === 0 ? 'Moins de 24 h' : `${days} jour${days > 1 ? 's' : ''}`,
      days,
      expired
    };
  }

  window.Xtream = {
    XtreamClient,
    normalizeServer,
    expiryInfo,
    mimeFor,
    streamId,
    uniqueCandidates
  };
})();
