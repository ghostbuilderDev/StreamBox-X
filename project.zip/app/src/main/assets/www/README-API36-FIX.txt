iPTV player V3 — correctif compilation API 36

- androidx.core:core verrouillé en 1.17.0
- androidx.core:core-ktx verrouillé en 1.17.0
- compileSdk et targetSdk restent à 36
- correction de l’échec checkDebugAarMetadata du run #53
