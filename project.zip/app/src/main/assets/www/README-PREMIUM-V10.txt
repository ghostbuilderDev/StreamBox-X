PRIME IPTV PLAYER PREMIUM 10.0

Base: V2.5 Stable dont la lecture Web fonctionne.

Fonctions principales:
- Lecture multi-source Web/HLS stable
- Détection audio et bascule de source
- Volume, vitesse, ratio, sélection source
- Pistes audio quand exposées par Android WebView
- Sous-titres SRT/VTT locaux
- Minuteur d’arrêt
- Google Cast natif via HTMLtoAPK V15.3 Premium Cast
- Favoris, historique, reprise
- Contrôle parental et mode enfant
- Masquage des catégories adultes
- Sauvegarde/restauration JSON
- Thèmes Premium/AMOLED/Cinéma
- Sélections personnalisées et contenus les mieux notés
- Diagnostic complet

IMPORTANT SON:
Le lecteur Web ne peut pas décoder certains codecs propriétaires (AC3/E-AC3/DTS) si Android WebView ne les fournit pas. La V10 détecte l’absence de décodage et essaie automatiquement les autres URL proposées par le serveur. Si toutes les sources utilisent un codec non pris en charge, utiliser une source AAC ou le lecteur externe.
