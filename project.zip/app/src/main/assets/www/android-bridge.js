window.NativeAndroid = {
  available: function () { return typeof window.AndroidApp !== "undefined"; },
  toast: function (message) {
    if (this.available()) window.AndroidApp.showToast(String(message));
    else console.log(message);
  },
  share: async function (text) {
    if (this.available()) return window.AndroidApp.share(String(text));
    if (navigator.share) return navigator.share({text:String(text)});
  },
  copy: async function (text) {
    if (this.available()) return window.AndroidApp.copyText(String(text));
    return navigator.clipboard.writeText(String(text));
  },
  vibrate: function (milliseconds) {
    if (this.available()) return window.AndroidApp.vibrate(Number(milliseconds) || 100);
    if (navigator.vibrate) navigator.vibrate(Number(milliseconds) || 100);
  },
  openUrl: function (url) {
    if (this.available()) return window.AndroidApp.openUrl(String(url));
    window.open(String(url), "_blank", "noopener");
  },
  startBackgroundTask: function (title, message) {
    if (this.available() && window.AndroidApp.startBackgroundTask) {
      return window.AndroidApp.startBackgroundTask(String(title),String(message));
    }
  },
  updateBackgroundTask: function (message) {
    if (this.available() && window.AndroidApp.updateBackgroundTask) {
      return window.AndroidApp.updateBackgroundTask(String(message));
    }
  },
  finishBackgroundTask: function (message, success) {
    if (this.available() && window.AndroidApp.finishBackgroundTask) {
      return window.AndroidApp.finishBackgroundTask(String(message),!!success);
    }
  },
  capabilities: function () {
    try { return this.available() && window.AndroidApp.getNativeCapabilities ? JSON.parse(window.AndroidApp.getNativeCapabilities()) : {native:false}; }
    catch (error) { return {native:false,error:String(error)}; }
  },
  playNative: function (url, title, options) {
    options=options || {};
    if (this.available() && window.AndroidApp.openNativePlayer) {
      const method=options.requestCast && window.AndroidApp.openNativePlayerForCast ? "openNativePlayerForCast" : "openNativePlayer";
      return window.AndroidApp[method](String(url),String(title||""),String(options.poster||""),JSON.stringify(options.headers||{}),Number(options.startPositionMs == null ? -1 : options.startPositionMs),options.autoplay !== false);
    }
    return false;
  },
  openExternalPlayer: function (url, title) {
    return !!(this.available() && window.AndroidApp.openExternalPlayer && window.AndroidApp.openExternalPlayer(String(url),String(title||"")));
  },
  enterPiP: function () {
    return !!(this.available() && window.AndroidApp.enterPictureInPicture && window.AndroidApp.enterPictureInPicture());
  },
  secureSet: function (name, value) {
    return !!(this.available() && window.AndroidApp.secureSet && window.AndroidApp.secureSet(String(name),String(value)));
  },
  secureGet: function (name, fallback) {
    return this.available() && window.AndroidApp.secureGet ? window.AndroidApp.secureGet(String(name),String(fallback||"")) : String(fallback||"");
  },
  favorites: {
    save: function(type,id,payload){ return !!(typeof window.AndroidApp!=="undefined" && window.AndroidApp.saveFavorite && window.AndroidApp.saveFavorite(String(type),String(id),JSON.stringify(payload||{}))); },
    remove: function(type,id){ return !!(typeof window.AndroidApp!=="undefined" && window.AndroidApp.removeFavorite && window.AndroidApp.removeFavorite(String(type),String(id))); },
    list: function(type){ try{return typeof window.AndroidApp!=="undefined" && window.AndroidApp.getFavorites ? JSON.parse(window.AndroidApp.getFavorites(String(type||""))||"[]") : [];}catch(e){return [];} }
  },
  history: {
    save: function(id,payload,position,duration,completed){ return !!(typeof window.AndroidApp!=="undefined" && window.AndroidApp.saveHistory && window.AndroidApp.saveHistory(String(id),JSON.stringify(payload||{}),Number(position||0),Number(duration||0),!!completed)); },
    list: function(limit){ try{return typeof window.AndroidApp!=="undefined" && window.AndroidApp.getHistory ? JSON.parse(window.AndroidApp.getHistory(Number(limit||100))||"[]") : [];}catch(e){return [];} },
    remove: function(id){ return !!(typeof window.AndroidApp!=="undefined" && window.AndroidApp.deleteHistory && window.AndroidApp.deleteHistory(String(id))); },
    clear: function(){ return !!(typeof window.AndroidApp!=="undefined" && window.AndroidApp.clearHistory && window.AndroidApp.clearHistory()); }
  },
  syncNow: function(name,url){ return !!(this.available() && window.AndroidApp.syncNow && window.AndroidApp.syncNow(String(name),String(url))); },
  scheduleSync: function(name,url,minutes){ return !!(this.available() && window.AndroidApp.schedulePeriodicSync && window.AndroidApp.schedulePeriodicSync(String(name),String(url),Number(minutes||60))); },
  readSyncCache: function(name){ return this.available() && window.AndroidApp.readSyncCache ? window.AndroidApp.readSyncCache(String(name)) : ""; },
  diagnostics: function(){ try{return this.available() && window.AndroidApp.getNetworkDiagnostics ? JSON.parse(window.AndroidApp.getNetworkDiagnostics()) : {native:false};}catch(e){return {error:String(e)};} }
};
