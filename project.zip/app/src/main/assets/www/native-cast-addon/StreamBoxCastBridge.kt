package fr.yoann.streamboxvision.cast

import android.app.Activity
import android.content.Intent
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import org.json.JSONObject

/**
 * Pont JavaScript attendu par app.js sous le nom window.StreamBoxCast.
 *
 * La MediaRouteButton doit être initialisée par CastButtonFactory dans l'Activity.
 * requestSession() ouvre le sélecteur d'appareils puis charge le média dès que la
 * session Cast est disponible.
 */
class StreamBoxCastBridge(
    private val activity: Activity,
    private val webView: WebView,
    private val mediaRouteButton: MediaRouteButton,
    private val castContext: CastContext
) {
    private var pendingPayload: JSONObject? = null

    private val listener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(session: CastSession, sessionId: String) {
            notifyState(true, false, session.castDevice?.friendlyName.orEmpty())
            pendingPayload?.let { loadMedia(session, it) }
            pendingPayload = null
        }

        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            notifyState(true, false, session.castDevice?.friendlyName.orEmpty())
            pendingPayload?.let { loadMedia(session, it) }
            pendingPayload = null
        }

        override fun onSessionEnded(session: CastSession, error: Int) {
            notifyState(false, false, "")
        }

        override fun onSessionStarting(session: CastSession) = notifyState(false, true, "")
        override fun onSessionResuming(session: CastSession, sessionId: String) = notifyState(false, true, "")
        override fun onSessionStartFailed(session: CastSession, error: Int) = notifyState(false, false, "")
        override fun onSessionResumeFailed(session: CastSession, error: Int) = notifyState(false, false, "")
        override fun onSessionSuspended(session: CastSession, reason: Int) = notifyState(false, true, "")
        override fun onSessionEnding(session: CastSession) = Unit
    }

    init {
        castContext.sessionManager.addSessionManagerListener(listener, CastSession::class.java)
    }

    @JavascriptInterface
    fun requestSession(payloadJson: String): String {
        val payload = JSONObject(payloadJson)
        activity.runOnUiThread {
            val current = castContext.sessionManager.currentCastSession
            if (current?.isConnected == true) {
                loadMedia(current, payload)
                notifyState(true, false, current.castDevice?.friendlyName.orEmpty())
            } else {
                pendingPayload = payload
                mediaRouteButton.performClick()
            }
        }
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun stop() {
        activity.runOnUiThread {
            castContext.sessionManager.endCurrentSession(true)
        }
    }

    @JavascriptInterface
    fun openCastSettings() {
        activity.runOnUiThread {
            val intents = listOf(
                Intent(Settings.ACTION_CAST_SETTINGS),
                Intent(Settings.ACTION_WIRELESS_SETTINGS)
            )
            val intent = intents.firstOrNull { it.resolveActivity(activity.packageManager) != null }
            if (intent != null) activity.startActivity(intent)
        }
    }

    private fun loadMedia(session: CastSession, payload: JSONObject) {
        val url = payload.getString("url")
        val title = payload.optString("title", "Lecture")
        val subtitle = payload.optString("subtitle", "StreamBox Vision")
        val mime = payload.optString("mime", "video/mp4")
        val isLive = payload.optBoolean("isLive", false)
        val currentTimeMs = (payload.optDouble("currentTime", 0.0) * 1000).toLong()

        val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(MediaMetadata.KEY_TITLE, title)
            putString(MediaMetadata.KEY_SUBTITLE, subtitle)
        }

        val mediaInfo = MediaInfo.Builder(url)
            .setContentType(mime)
            .setStreamType(if (isLive) MediaInfo.STREAM_TYPE_LIVE else MediaInfo.STREAM_TYPE_BUFFERED)
            .setMetadata(metadata)
            .build()

        val request = MediaLoadRequestData.Builder()
            .setMediaInfo(mediaInfo)
            .setAutoplay(true)
            .setCurrentTime(if (isLive) 0 else currentTimeMs)
            .build()

        session.remoteMediaClient?.load(request)
    }

    private fun notifyState(connected: Boolean, connecting: Boolean, deviceName: String) {
        val payload = JSONObject()
            .put("connected", connected)
            .put("connecting", connecting)
            .put("deviceName", deviceName)
            .toString()
            .replace("\\", "\\\\")
            .replace("'", "\\'")

        activity.runOnUiThread {
            webView.evaluateJavascript("window.onStreamBoxCastState('$payload')", null)
        }
    }
}
