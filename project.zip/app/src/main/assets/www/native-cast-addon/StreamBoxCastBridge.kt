package fr.yoann.streamboxvision.cast

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import org.json.JSONObject

/**
 * Pont natif utilisé par StreamBox Vision Cast v6.
 *
 * Toutes les actions pouvant échouer dans une WebView (sélecteur Cast,
 * réglages Android, partage, lecteur externe) passent ici afin d'éviter
 * les erreurs « Impossible d'ouvrir ce lien ».
 */
class StreamBoxCastBridge(
    private val activity: Activity,
    private val webView: WebView,
    private val mediaRouteButton: MediaRouteButton,
    private val castContext: CastContext
) {
    private var pendingPayload: JSONObject? = null

    private val listener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(session: CastSession, sessionId: String) {
            notifyState(true, false, session.castDevice?.friendlyName.orEmpty())
            pendingPayload?.let { loadMedia(session, it) }
            pendingPayload = null
        }

        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            notifyState(true, false, session.castDevice?.friendlyName.orEmpty())
            pendingPayload?.let { loadMedia(session, it) }
            pendingPayload = null
        }

        override fun onSessionEnded(session: CastSession, error: Int) = notifyState(false, false, "")
        override fun onSessionStarting(session: CastSession) = notifyState(false, true, "")
        override fun onSessionResuming(session: CastSession, sessionId: String) = notifyState(false, true, "")
        override fun onSessionStartFailed(session: CastSession, error: Int) {
            pendingPayload = null
            notifyState(false, false, "")
            notifyError("Le sélecteur Cast n'a pas pu démarrer (code $error).")
        }
        override fun onSessionResumeFailed(session: CastSession, error: Int) = notifyState(false, false, "")
        override fun onSessionSuspended(session: CastSession, reason: Int) = notifyState(false, true, "")
        override fun onSessionEnding(session: CastSession) = Unit
    }

    init {
        castContext.sessionManager.addSessionManagerListener(listener, CastSession::class.java)
    }

    @JavascriptInterface
    fun getCapabilities(): String = JSONObject()
        .put("native", true)
        .put("cast", true)
        .put("settings", true)
        .put("share", true)
        .put("external", true)
        .toString()

    @JavascriptInterface
    fun requestSession(payloadJson: String): String {
        return try {
            val payload = JSONObject(payloadJson)
            activity.runOnUiThread {
                val current = castContext.sessionManager.currentCastSession
                if (current?.isConnected == true) {
                    loadMedia(current, payload)
                    notifyState(true, false, current.castDevice?.friendlyName.orEmpty())
                } else {
                    pendingPayload = payload
                    mediaRouteButton.performClick()
                }
            }
            ok()
        } catch (error: Exception) {
            fail(error.message ?: "Impossible de préparer la diffusion.")
        }
    }

    @JavascriptInterface
    fun stop(): String {
        activity.runOnUiThread { castContext.sessionManager.endCurrentSession(true) }
        return ok()
    }

    @JavascriptInterface
    fun openCastSettings(): String {
        val candidates = listOf(
            Intent(Settings.ACTION_CAST_SETTINGS),
            Intent(Settings.ACTION_WIFI_SETTINGS),
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        )
        val intent = candidates.firstOrNull { it.resolveActivity(activity.packageManager) != null }
            ?: return fail("Aucun écran de réglages Cast disponible.")
        activity.runOnUiThread { activity.startActivity(intent) }
        return ok()
    }

    @JavascriptInterface
    fun shareMedia(payloadJson: String): String {
        return try {
            val payload = JSONObject(payloadJson)
            val url = payload.getString("url")
            val title = payload.optString("title", "Lecture StreamBox")
            activity.runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, title)
                    putExtra(Intent.EXTRA_TEXT, url)
                }
                activity.startActivity(Intent.createChooser(send, "Envoyer le flux vers…"))
            }
            ok()
        } catch (error: Exception) {
            fail(error.message ?: "Partage indisponible.")
        }
    }

    @JavascriptInterface
    fun openExternal(payloadJson: String): String {
        return try {
            val payload = JSONObject(payloadJson)
            val url = payload.getString("url")
            val mime = payload.optString("mime", "video/*")
            val view = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(url), mime)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (view.resolveActivity(activity.packageManager) == null) {
                return fail("Aucun lecteur vidéo compatible installé.")
            }
            val chooser = Intent.createChooser(view, "Ouvrir avec un lecteur vidéo")
            activity.runOnUiThread { activity.startActivity(chooser) }
            ok()
        } catch (error: Exception) {
            fail(error.message ?: "Aucun lecteur compatible.")
        }
    }

    private fun loadMedia(session: CastSession, payload: JSONObject) {
        val url = payload.getString("url")
        val title = payload.optString("title", "Lecture")
        val subtitle = payload.optString("subtitle", "StreamBox Vision")
        val mime = payload.optString("mime", "video/mp4")
        val isLive = payload.optBoolean("isLive", false)
        val currentTimeMs = (payload.optDouble("currentTime", 0.0) * 1000).toLong()

        val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(MediaMetadata.KEY_TITLE, title)
            putString(MediaMetadata.KEY_SUBTITLE, subtitle)
            payload.optString("image").takeIf { it.isNotBlank() }?.let {
                addImage(com.google.android.gms.common.images.WebImage(Uri.parse(it)))
            }
        }

        val mediaInfo = MediaInfo.Builder(url)
            .setContentType(mime)
            .setStreamType(if (isLive) MediaInfo.STREAM_TYPE_LIVE else MediaInfo.STREAM_TYPE_BUFFERED)
            .setMetadata(metadata)
            .build()

        val request = MediaLoadRequestData.Builder()
            .setMediaInfo(mediaInfo)
            .setAutoplay(true)
            .setCurrentTime(if (isLive) 0 else currentTimeMs)
            .build()

        session.remoteMediaClient?.load(request)?.setResultCallback { status ->
            if (!status.isSuccess) notifyError("Le téléviseur a refusé le flux (${status.statusCode}).")
        }
    }

    private fun notifyState(connected: Boolean, connecting: Boolean, deviceName: String) {
        val payload = JSONObject()
            .put("connected", connected)
            .put("connecting", connecting)
            .put("deviceName", deviceName)
            .toString()
            .replace("\\", "\\\\")
            .replace("'", "\\'")

        activity.runOnUiThread {
            webView.evaluateJavascript("window.onStreamBoxCastState('$payload')", null)
        }
    }

    private fun notifyError(message: String) {
        val safe = JSONObject.quote(message)
        activity.runOnUiThread {
            webView.evaluateJavascript("window.onStreamBoxCastError($safe)", null)
        }
    }

    private fun ok(): String = JSONObject().put("ok", true).toString()
    private fun fail(message: String): String = JSONObject().put("ok", false).put("error", message).toString()
}
