# Intégration Google Cast native — StreamBox Vision

Le HTML de la version 5 essaie automatiquement, dans cet ordre :

1. le pont Android `window.StreamBoxCast` ;
2. le SDK Google Cast Web Sender si le navigateur l'expose ;
3. l'API Remote Playback ;
4. les réglages Android de duplication d'écran ;
5. le partage du lien vers VLC, BubbleUPnP ou une autre application compatible.

## Pourquoi ce dossier existe

Une WebView Android classique ne fournit pas toujours le sélecteur Chromecast. Pour garantir un vrai bouton Cast dans l'APK, le générateur HTMLtoAPK doit intégrer le SDK Android Sender de Google Cast et exposer le pont JavaScript fourni ici.

## Étapes

1. Ajouter les dépendances de `build.gradle.kts.snippet`.
2. Ajouter les éléments du manifeste.
3. Copier les deux classes Kotlin dans le package indiqué, ou modifier le package.
4. Adapter l'extrait `MainActivity.integration.kt.snippet` au nom réel de la WebView.
5. Appeler `configureStreamBoxCast()` après l'initialisation de la WebView.
6. Conserver JavaScript, DOM Storage et l'accès Internet activés.

La version utilisée dans le snippet est `play-services-cast-framework:22.3.1`, publiée par Google en avril 2026.

## Limite importante

Le téléviseur doit pouvoir télécharger directement l'URL du flux. Les flux protégés par cookies, jetons liés au téléphone, certificats non reconnus ou formats non pris en charge peuvent ne pas fonctionner sur Chromecast. HLS et DASH sont généralement les formats les plus adaptés.
