package fr.yoann.streamboxvision.cast

import android.content.Context
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider

class StreamBoxCastOptionsProvider : OptionsProvider {
    override fun getCastOptions(context: Context): CastOptions =
        CastOptions.Builder()
            .setReceiverApplicationId(
                CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID
            )
            .setStopReceiverApplicationWhenEndingSession(true)
            .setShowSystemOutputSwitcherOnCastIconClick(true)
            .build()

    override fun getAdditionalSessionProviders(
        context: Context
    ): List<SessionProvider>? = null
}
