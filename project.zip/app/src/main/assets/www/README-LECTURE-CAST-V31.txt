Prime IPTV Player 3.1 — correctif lecture et Cast

Package conservé : dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt
Version : 1.0.7 / 207905001

Correctifs :
- CastPlayer protégé par un repli automatique sur ExoPlayer.
- Le chargement du module Cast ne peut plus fermer l’application.
- Suppression du bouton Cast injecté de façon non protégée dans PlayerView.
- Cast via le sélecteur de sortie de la notification MediaSession.
- Lancement du lecteur depuis le pont JavaScript sur le thread UI Android.
- HTTP autorisé pour les serveurs Xtream qui n’utilisent pas HTTPS.
