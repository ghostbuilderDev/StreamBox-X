STREAMBOX VISION NATIVE 10 — DIAGNOSTIC AUTOMATIQUE

IMPORTANT
- Le vrai lecteur Media3 et le vrai Google Cast nécessitent le projet android-native-project.
- Le ZIP HTMLtoAPK seul garde un lecteur WebView et ne peut pas garantir les codecs ni la découverte Chromecast.

DIAGNOSTICS
À chaque erreur Media3, WebView JavaScript, vidéo ou Google Cast, un fichier TXT est généré automatiquement.
Android 10+ : Téléchargements/StreamBoxDiagnostics/
Android 6 à 9 : dossier Documents privé de l’application, partageable depuis la fenêtre d’erreur.
Les identifiants présents dans les URL sont masqués.

Le rapport contient le code d’erreur, la chaîne des causes, le format, l’état du buffer, les pistes détectées, l’appareil, Android, le réseau et la disponibilité des ponts natifs.
