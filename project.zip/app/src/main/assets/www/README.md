# Prime IPTV Player 6.0

Projet Android natif hybride : interface WebView + lecteur Media3 intégré dans la MainActivity.

## Changements majeurs
- Correction des erreurs de compilation Media3 et NanoHTTPD.
- Lecture dans un overlay natif intégré à la MainActivity : aucune PlayerActivity secondaire.
- Aucun Intent vidéo externe automatique.
- Plusieurs URL Xtream essayées automatiquement.
- Cast initialisé uniquement à la demande et isolé de la lecture locale.
- Relais HTTP local pour HLS/MP4 avec en-têtes, Range et CORS.
- Version 6.0.0, versionCode 208006001.

## Compilation
Utiliser le compilateur GitHub V6 fourni avec ce projet.
