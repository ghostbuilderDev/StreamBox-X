const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const db = {
  get(key, fallback) {
    try {
      const value = JSON.parse(localStorage.getItem('sbi_' + key));
      return value ?? fallback;
    } catch {
      return fallback;
    }
  },
  set(key, value) {
    localStorage.setItem('sbi_' + key, JSON.stringify(value));
  },
  del(key) {
    localStorage.removeItem('sbi_' + key);
  }
};

const demo = {
  live: [
    { stream_id: 1, name: 'Infinity Live', stream_icon: '', category_id: '1', stream_type: 'live' },
    { stream_id: 2, name: 'Demo Sport Arena', stream_icon: '', category_id: '1', stream_type: 'live' },
    { stream_id: 3, name: 'Ciné Night', stream_icon: '', category_id: '1', stream_type: 'live' }
  ],
  movies: [
    {
      stream_id: 101,
      name: 'Big Buck Bunny',
      stream_icon: 'https://storage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg',
      category_id: '10',
      rating: '8.2',
      container_extension: 'mp4',
      plot: 'Un film de démonstration pour découvrir l’interface StreamBox Infinity.',
      genre: 'Animation',
      releaseDate: '2008'
    },
    {
      stream_id: 102,
      name: 'Elephant Dream',
      stream_icon: 'https://storage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg',
      category_id: '10',
      rating: '7.5',
      container_extension: 'mp4',
      plot: 'Une expérience visuelle pour mettre en valeur la qualité d’affichage de l’application.',
      genre: 'Sci-Fi',
      releaseDate: '2006'
    }
  ],
  series: [
    {
      series_id: 201,
      name: 'For Bigger Blazes',
      cover: 'https://storage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerBlazes.jpg',
      category_id: '20',
      rating: '7.9',
      plot: 'Une série de démonstration pour illustrer les fiches détaillées et les épisodes.',
      genre: 'Demo Series'
    },
    {
      series_id: 202,
      name: 'For Bigger Escapes',
      cover: 'https://storage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerEscapes.jpg',
      category_id: '20',
      rating: '8.1',
      plot: 'Exemple de série avec une direction artistique premium.',
      genre: 'Adventure'
    }
  ],
  liveCats: [{ category_id: '1', category_name: 'Général' }],
  movieCats: [{ category_id: '10', category_name: 'Films' }],
  seriesCats: [{ category_id: '20', category_name: 'Séries' }]
};

let profile = db.get('profile', null);
let profiles = db.get('profiles', []);
let data = db.get('catalog', { live: [], movies: [], series: [], liveCats: [], movieCats: [], seriesCats: [] });
let favorites = db.get('favorites', []);
let history = db.get('history', []);
let positions = db.get('positions', {});
let settings = db.get('settings', { autoplay: true, resume: true, external: false, liveFormat: 'm3u8' });

let currentView = 'home';
let currentType = 'home';
let currentItem = null;
let currentEpisode = null;
let catalog = [];
let visible = 60;
let hls = null;
let dash = null;
let heroTimer = null;
let lastUrl = '';
let loading = false;

const esc = s => (s ?? '').toString().replace(/[&<>'"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const normServer = s => (s || '').trim().replace(/\/+$/, '');
const titleOf = x => x?.name || x?.title || 'Sans titre';
const idOf = (type, item) => String(type === 'series' ? item.series_id : item.stream_id);
const itemKey = (type, item, episode) => `${type}:${idOf(type, item)}${episode ? ':' + episode.id : ''}`;
const countAll = () => data.live.length + data.movies.length + data.series.length;

function toast(message) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 2600);
}

function show(el, state = true) {
  if (!el) return;
  el.classList.toggle('hidden', !state);
}

function imageOf(item, type) {
  return type === 'series'
    ? (item.cover || item.backdrop_path?.[0] || item.stream_icon || '')
    : (item.stream_icon || item.cover || item.movie_image || item.backdrop_path?.[0] || '');
}

function empty(message) {
  return `<div class="emptyCatalog">${esc(message)}</div>`;
}

function api(action, extra = {}) {
  const url = new URL(profile.server + '/player_api.php');
  url.searchParams.set('username', profile.username);
  url.searchParams.set('password', profile.password);
  if (action) url.searchParams.set('action', action);
  Object.entries(extra).forEach(([key, value]) => url.searchParams.set(key, value));
  return fetch(url, { cache: 'no-store' }).then(r => {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  });
}

function setLoginStatus(text, isError = true) {
  const el = $('#loginStatus');
  el.textContent = text || '';
  el.style.color = isError ? '#ffc0cf' : '#befbe5';
}

function setLoading(state, message) {
  loading = state;
  $('#connectBtn').disabled = state;
  $('#refreshBtn').disabled = state;
  $('#refreshTopBtn').disabled = state;
  if (message) toast(message);
}

function saveCurrentProfile() {
  const index = profiles.findIndex(p => p.server === profile.server && p.username === profile.username);
  const record = { ...profile, demo: !!profile.demo };
  if (index >= 0) profiles[index] = record;
  else profiles.unshift(record);
  profiles = profiles.slice(0, 8);
  db.set('profiles', profiles);
}

function renderSavedProfiles() {
  const targetLogin = $('#savedProfiles');
  const targetManager = $('#profilesManager');
  const wrap = $('#savedProfilesWrap');
  if (!profiles.length) {
    show(wrap, false);
    if (targetManager) targetManager.innerHTML = empty('Aucun profil enregistré.');
    return;
  }
  show(wrap, true);
  const html = profiles.map((p, index) => `
    <div class="savedProfileItem" data-index="${index}">
      <div class="avatarBtn">${esc((p.name || 'P')[0].toUpperCase())}</div>
      <div class="savedMeta">
        <b>${esc(p.name || 'Profil')}</b>
        <small>${esc(p.server)}</small>
      </div>
      <div class="savedActions">
        <button data-action="fill">Charger</button>
        <button data-action="use">Connexion</button>
        <button data-action="delete" class="dangerMini">Suppr.</button>
      </div>
    </div>
  `).join('');
  targetLogin.innerHTML = html;
  targetManager.innerHTML = html;
}

function fillProfile(p) {
  $('#profileName').value = p.name || '';
  $('#server').value = p.server || '';
  $('#username').value = p.username || '';
  $('#password').value = p.password || '';
}

async function connect(existingProfile = null) {
  const candidate = existingProfile || {
    name: $('#profileName').value.trim() || 'Mon profil',
    server: normServer($('#server').value),
    username: $('#username').value.trim(),
    password: $('#password').value,
    demo: false
  };
  if (!candidate.server || !candidate.username || !candidate.password) {
    setLoginStatus('Complète les informations de connexion.');
    return;
  }
  setLoading(true);
  setLoginStatus('Connexion au serveur…', false);
  try {
    profile = candidate;
    const info = await api('');
    if (!info.user_info || String(info.user_info.auth) !== '1') {
      throw new Error('Identifiants refusés');
    }
    db.set('profile', profile);
    saveCurrentProfile();
    await loadAll();
    showApp();
    setLoginStatus('Connexion réussie.', false);
  } catch (error) {
    profile = null;
    db.del('profile');
    setLoginStatus('Connexion impossible : ' + (error.message || 'vérifie le serveur et les codes.'));
  } finally {
    setLoading(false);
  }
}

async function loadAll() {
  const sources = await Promise.allSettled([
    api('get_live_categories'),
    api('get_live_streams'),
    api('get_vod_categories'),
    api('get_vod_streams'),
    api('get_series_categories'),
    api('get_series')
  ]);
  const take = i => sources[i].status === 'fulfilled' && Array.isArray(sources[i].value) ? sources[i].value : [];
  data = {
    liveCats: take(0),
    live: take(1),
    movieCats: take(2),
    movies: take(3),
    seriesCats: take(4),
    series: take(5)
  };
  db.set('catalog', data);
}

function card(item, type, opts = {}) {
  const img = imageOf(item, type);
  const id = idOf(type, item);
  const favorite = isFav(type, id);
  const title = titleOf(item);
  const progress = opts.progress ?? null;
  const badge = type === 'live'
    ? '<span class="liveTag">DIRECT</span>'
    : item.rating ? `<span class="rating">★ ${esc(item.rating)}</span>` : '';
  return `
    <article class="card" data-type="${type}" data-id="${id}">
      <div class="thumb" style="background-image:url('${esc(img)}')">
        ${badge}
        <button class="favBadge" data-fav="1">${favorite ? '♥' : '♡'}</button>
        ${typeof progress === 'number' ? `<span class="continueBadge">${Math.round(progress)}%</span>` : ''}
      </div>
      <h3>${esc(title)}</h3>
      <p>${type === 'live' ? 'Chaîne en direct' : type === 'movies' ? 'Film' : 'Série'}</p>
      ${typeof progress === 'number' ? `<div class="progress"><i style="width:${Math.max(4, progress)}%"></i></div>` : ''}
    </article>
  `;
}

function bindCards(root) {
  if (!root) return;
  root.onclick = event => {
    const cardEl = event.target.closest('.card');
    if (!cardEl) return;
    const type = cardEl.dataset.type;
    const item = findItem(type, cardEl.dataset.id);
    if (!item) return;
    if (event.target.dataset.fav) {
      toggleFav(type, idOf(type, item), item);
      event.target.textContent = isFav(type, idOf(type, item)) ? '♥' : '♡';
      return;
    }
    openDetails(item, type);
  };
}

function isFav(type, id) {
  return favorites.some(f => f.type === type && String(f.id) === String(id));
}

function toggleFav(type, id, item) {
  const i = favorites.findIndex(f => f.type === type && String(f.id) === String(id));
  if (i >= 0) {
    favorites.splice(i, 1);
    toast('Retiré de Ma liste');
  } else {
    favorites.unshift({ type, id, item });
    favorites = favorites.slice(0, 300);
    toast('Ajouté à Ma liste');
  }
  db.set('favorites', favorites);
  renderFavorites();
}

function findItem(type, id) {
  const list = type === 'live' ? data.live : type === 'movies' ? data.movies : data.series;
  return list.find(item => String(type === 'series' ? item.series_id : item.stream_id) === String(id));
}

function renderHero(item, type) {
  if (!item) return;
  currentItem = { item, type };
  $('#heroTitle').textContent = titleOf(item);
  $('#heroText').textContent = item.plot || item.description || 'Disponible dans votre catalogue.';
  $('#heroSubMeta').textContent = [type === 'live' ? 'Chaîne live' : type === 'movies' ? 'Film' : 'Série', item.genre, item.releaseDate || item.releasedate, item.rating ? '★ ' + item.rating : ''].filter(Boolean).join(' • ');
  $('#heroBadge').textContent = type === 'live' ? 'EN DIRECT' : type === 'movies' ? 'VOD PREMIUM' : 'SÉRIE';
  const img = imageOf(item, type);
  $('#heroBackdrop').style.backgroundImage = img ? `linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.02)), url('${img}')` : 'linear-gradient(135deg,#1e2242,#0d7f88)';
}

function startHeroRotation(items) {
  clearInterval(heroTimer);
  if (!items.length) return;
  let index = 0;
  heroTimer = setInterval(() => {
    index = (index + 1) % items.length;
    renderHero(items[index].item, items[index].type);
  }, 9000);
}

function renderStats() {
  $('#heroCatalogCount').textContent = countAll();
  $('#liveCount').textContent = data.live.length;
  $('#movieCount').textContent = data.movies.length;
  $('#seriesCount').textContent = data.series.length;
}

function renderHome() {
  renderStats();
  const live = data.live.slice(0, 12);
  const movies = data.movies.slice(0, 12);
  const series = data.series.slice(0, 12);

  $('#liveRail').innerHTML = live.map(item => card(item, 'live')).join('') || empty('Aucune chaîne disponible.');
  $('#movieRail').innerHTML = movies.map(item => card(item, 'movies')).join('') || empty('Aucun film disponible.');
  $('#seriesRail').innerHTML = series.map(item => card(item, 'series')).join('') || empty('Aucune série disponible.');

  bindCards($('#liveRail'));
  bindCards($('#movieRail'));
  bindCards($('#seriesRail'));

  const heroItems = [
    ...movies.slice(0, 4).map(item => ({ item, type: 'movies' })),
    ...series.slice(0, 4).map(item => ({ item, type: 'series' })),
    ...live.slice(0, 2).map(item => ({ item, type: 'live' }))
  ];
  if (heroItems.length) renderHero(heroItems[0].item, heroItems[0].type);
  startHeroRotation(heroItems);
  renderContinue();
}

function renderContinue() {
  const items = history.slice(0, 12).map(entry => {
    const key = itemKey(entry.type, entry.item, entry.episode);
    const position = positions[key]?.duration ? Math.min(100, (positions[key].time / positions[key].duration) * 100) : null;
    return { ...entry, progress: position };
  });
  show($('#continueSection'), items.length > 0);
  $('#continueRail').innerHTML = items.map(entry => card(entry.item, entry.type, { progress: entry.progress })).join('');
  bindCards($('#continueRail'));
}

function renderCatalog() {
  const items = catalog.slice(0, visible);
  const target = $('#catalogGrid');
  target.className = 'catalogGrid ' + (currentType === 'live' ? '' : 'posterMode');
  target.innerHTML = items.map(item => card(item, currentType)).join('') || empty('Aucun contenu dans cette catégorie.');
  bindCards(target);
  show($('#loadMore'), visible < catalog.length);
}

function renderFavorites() {
  const grid = $('#favoritesGrid');
  if (!grid) return;
  grid.innerHTML = favorites.map(entry => card(entry.item, entry.type)).join('') || empty('Votre liste est encore vide.');
  bindCards(grid);
}

function go(view) {
  currentView = view;
  currentType = view;
  $$('.view').forEach(v => v.classList.remove('active'));
  $$('.dockItem').forEach(item => item.classList.toggle('active', item.dataset.view === view));

  if (view === 'home') {
    $('#homeView').classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return;
  }
  if (view === 'favorites') {
    $('#favoritesView').classList.add('active');
    renderFavorites();
    return;
  }
  if (view === 'settings') {
    $('#settingsView').classList.add('active');
    renderSavedProfiles();
    return;
  }

  $('#catalogView').classList.add('active');
  const cfg = view === 'live'
    ? ['Chaînes en direct', data.live, data.liveCats]
    : view === 'movies'
      ? ['Films', data.movies, data.movieCats]
      : ['Séries', data.series, data.seriesCats];
  catalog = cfg[1] || [];
  visible = 60;
  $('#catalogTitle').textContent = cfg[0];
  $('#catalogCount').textContent = `${catalog.length} contenu${catalog.length > 1 ? 's' : ''}`;
  $('#categoryChips').innerHTML = `<button class="chip active" data-cat="all">Tout</button>` + (cfg[2] || []).map(cat => `<button class="chip" data-cat="${cat.category_id}">${esc(cat.category_name)}</button>`).join('');
  renderCatalog();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function setProfileLabels() {
  const label = profile?.name || 'Profil';
  const initial = (label[0] || 'S').toUpperCase();
  $('#profileLabel').textContent = label;
  $('#settingsProfile').textContent = label;
  $('#settingsServer').textContent = profile?.server || 'Mode démo';
  $('#accountBtn').textContent = initial;
  $('#settingsAvatar').textContent = initial;
}

function applySettings() {
  $('#autoPlay').checked = !!settings.autoplay;
  $('#resumePlay').checked = !!settings.resume;
  $('#externalPlayer').checked = !!settings.external;
  $('#liveFormat').value = settings.liveFormat || 'm3u8';
}

function showApp() {
  data = profile?.demo ? demo : db.get('catalog', data);
  show($('#login'), false);
  show($('#app'), true);
  setProfileLabels();
  applySettings();
  renderSavedProfiles();
  renderHome();
  renderFavorites();
}

function streamUrl(item, type, episode) {
  if (profile?.demo) {
    if (type === 'movies') return 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
    if (type === 'series') return 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4';
    return 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8';
  }
  if (type === 'live') {
    const ext = settings.liveFormat || 'm3u8';
    return `${profile.server}/live/${encodeURIComponent(profile.username)}/${encodeURIComponent(profile.password)}/${item.stream_id}.${ext}`;
  }
  if (type === 'movies') {
    return `${profile.server}/movie/${encodeURIComponent(profile.username)}/${encodeURIComponent(profile.password)}/${item.stream_id}.${item.container_extension || 'mp4'}`;
  }
  if (episode) {
    return `${profile.server}/series/${encodeURIComponent(profile.username)}/${encodeURIComponent(profile.password)}/${episode.id}.${episode.container_extension || 'mp4'}`;
  }
  return '';
}

async function openDetails(item, type) {
  currentItem = { item, type };
  currentEpisode = null;
  $('#detailsType').textContent = type === 'live' ? 'EN DIRECT' : type === 'movies' ? 'FILM' : 'SÉRIE';
  $('#detailsTitle').textContent = titleOf(item);
  $('#detailsMeta').textContent = [type === 'live' ? 'Chaîne live' : type === 'movies' ? 'Film' : 'Série', item.genre, item.releaseDate || item.releasedate, item.rating ? '★ ' + item.rating : ''].filter(Boolean).join('  •  ');
  $('#detailsPlot').textContent = item.plot || item.description || 'Aucune description disponible.';
  const img = imageOf(item, type);
  $('#detailsBackdrop').style.backgroundImage = img ? `url('${img}')` : 'linear-gradient(135deg,#20264b,#134f63)';
  $('#detailsFav').textContent = (isFav(type, idOf(type, item)) ? '♥' : '♡') + ' Ma liste';
  $('#episodesArea').innerHTML = '';
  show($('#detailsModal'), true);

  if (type === 'series') {
    if (profile?.demo) {
      const eps = [{ id: 1, title: 'Épisode 1', container_extension: 'mp4', info: { duration: '00:02:00', movie_image: img } }];
      renderEpisodes(item, eps, type);
      return;
    }
    $('#episodesArea').innerHTML = '<p class="legalCopy">Chargement des épisodes…</p>';
    try {
      const info = await api('get_series_info', { series_id: item.series_id });
      const episodes = Object.values(info.episodes || {}).flat();
      renderEpisodes(item, episodes, type);
    } catch {
      $('#episodesArea').innerHTML = '<p class="legalCopy">Impossible de charger les épisodes.</p>';
    }
  }
}

function renderEpisodes(item, episodes, type) {
  if (!episodes.length) {
    $('#episodesArea').innerHTML = '<p class="legalCopy">Aucun épisode disponible.</p>';
    return;
  }
  $('#episodesArea').innerHTML = '<h3>Épisodes</h3>' + episodes.map((episode, index) => `
    <div class="episode" data-episode="${index}">
      <div class="epThumb" style="background-image:url('${esc(episode.info?.movie_image || imageOf(item, type))}')"></div>
      <div>
        <h4>${esc(episode.title || 'Épisode ' + (index + 1))}</h4>
        <small>${esc(episode.info?.duration || '')}</small>
      </div>
    </div>
  `).join('');
  $('#episodesArea').onclick = event => {
    const row = event.target.closest('[data-episode]');
    if (!row) return;
    currentEpisode = episodes[Number(row.dataset.episode)] || null;
    play(item, type, currentEpisode);
  };
}

function addToHistory(item, type, episode = null) {
  const key = itemKey(type, item, episode);
  history = [
    { item, type, date: Date.now(), episode, key },
    ...history.filter(entry => entry.key !== key)
  ].slice(0, 40);
  db.set('history', history);
}

function destroyPlayers() {
  if (hls) {
    hls.destroy();
    hls = null;
  }
  if (dash) {
    dash.reset();
    dash = null;
  }
}

function savePosition(force = false) {
  const video = $('#video');
  if (!settings.resume || !currentItem || currentItem.type === 'live') return;
  if (!video.duration || !isFinite(video.duration)) return;
  if (!force && video.currentTime < 3) return;
  const key = itemKey(currentItem.type, currentItem.item, currentEpisode);
  positions[key] = { time: video.currentTime, duration: video.duration, updatedAt: Date.now() };
  db.set('positions', positions);
}

function tryResume(video) {
  const badge = $('#resumeBadge');
  show(badge, false);
  if (!settings.resume || !currentItem || currentItem.type === 'live') return;
  const key = itemKey(currentItem.type, currentItem.item, currentEpisode);
  const memory = positions[key];
  if (!memory || !memory.time || memory.time < 10 || !memory.duration || memory.time > (memory.duration - 10)) return;
  const safeResume = () => {
    try {
      video.currentTime = memory.time;
      badge.textContent = `Reprise appliquée à ${formatTime(memory.time)}`;
      show(badge, true);
      setTimeout(() => show(badge, false), 2500);
    } catch {}
  };
  video.addEventListener('loadedmetadata', safeResume, { once: true });
}

function formatTime(seconds) {
  const s = Math.floor(seconds || 0);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0 ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${m}:${String(sec).padStart(2, '0')}`;
}

function startVideo(url) {
  const video = $('#video');
  destroyPlayers();
  lastUrl = url;
  video.pause();
  video.removeAttribute('src');
  video.load();
  show($('#playerLoader'), true);
  tryResume(video);

  const hideLoaderAndAutoplay = () => {
    show($('#playerLoader'), false);
    if (settings.autoplay) video.play().catch(() => {});
  };

  const extension = (url.split('?')[0].split('.').pop() || '').toLowerCase();

  if ((extension === 'm3u8' || url.includes('.m3u8')) && window.Hls?.isSupported()) {
    hls = new Hls({ enableWorker: true, lowLatencyMode: true, maxBufferLength: 30 });
    hls.loadSource(url);
    hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, hideLoaderAndAutoplay);
    hls.on(Hls.Events.ERROR, (_, dataError) => {
      if (dataError.fatal) {
        show($('#playerLoader'), false);
        toast('Flux HLS inaccessible ou format non compatible.');
      }
    });
  } else if (extension === 'mpd' && window.dashjs) {
    dash = dashjs.MediaPlayer().create();
    dash.initialize(video, url, !!settings.autoplay);
    dash.on('streamInitialized', hideLoaderAndAutoplay);
    dash.on('error', () => {
      show($('#playerLoader'), false);
      toast('Flux DASH inaccessible ou non compatible.');
    });
  } else {
    video.src = url;
    video.oncanplay = hideLoaderAndAutoplay;
    video.onerror = () => {
      show($('#playerLoader'), false);
      toast('Lecture impossible. Essaie le lecteur externe.');
    };
  }
}

async function loadEpg(item) {
  show($('#epgPanel'), true);
  $('#epgList').innerHTML = '<p class="legalCopy">Chargement du programme…</p>';
  if (profile?.demo) {
    $('#epgList').innerHTML = '<div class="epgItem"><small>Maintenant</small><b>Programme de démonstration</b><p>Le guide EPG apparaît ici lorsque le fournisseur le rend disponible.</p></div>';
    return;
  }
  try {
    const result = await api('get_short_epg', { stream_id: item.stream_id, limit: 8 });
    const list = result.epg_listings || [];
    $('#epgList').innerHTML = list.map(entry => `
      <div class="epgItem">
        <small>${fmtEpg(entry.start_timestamp, entry.stop_timestamp)}</small>
        <b>${esc(decode64(entry.title))}</b>
        <p>${esc(decode64(entry.description))}</p>
      </div>
    `).join('') || '<p class="legalCopy">Aucun programme disponible.</p>';
  } catch {
    $('#epgList').innerHTML = '<p class="legalCopy">Guide indisponible.</p>';
  }
}

function decode64(value) {
  try {
    return decodeURIComponent(escape(atob(value || '')));
  } catch {
    return value || '';
  }
}

function fmtEpg(start, end) {
  const f = ts => new Date(Number(ts) * 1000).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  return `${f(start)} – ${f(end)}`;
}

function play(item, type, episode = null) {
  const url = streamUrl(item, type, episode);
  if (!url) {
    toast(type === 'series' ? 'Choisis un épisode.' : 'Aucun flux disponible.');
    return;
  }
  currentItem = { item, type };
  currentEpisode = episode;
  addToHistory(item, type, episode);
  $('#playingTitle').textContent = episode?.title || titleOf(item);
  $('#playingMeta').textContent = [type === 'live' ? 'En direct' : type === 'movies' ? 'Film' : 'Série', item.genre].filter(Boolean).join(' • ');
  $('#favPlayer').textContent = isFav(type, idOf(type, item)) ? '♥' : '♡';
  show($('#detailsModal'), false);
  show($('#playerModal'), true);

  if (settings.external) {
    location.href = url;
    return;
  }
  startVideo(url);
  if (type === 'live') loadEpg(item); else show($('#epgPanel'), false);
}

function closePlayer() {
  savePosition(true);
  destroyPlayers();
  const video = $('#video');
  video.pause();
  video.removeAttribute('src');
  video.load();
  show($('#playerModal'), false);
  renderContinue();
}

function removeProfile(index) {
  profiles.splice(index, 1);
  db.set('profiles', profiles);
  renderSavedProfiles();
  toast('Profil supprimé');
}

function logout() {
  db.del('profile');
  profile = null;
  show($('#app'), false);
  show($('#login'), true);
  show($('#searchOverlay'), false);
  closePlayer();
  toast('Profil déconnecté');
}

function handleNetwork() {
  show($('#networkBanner'), !navigator.onLine);
}

$('#connectBtn').onclick = () => connect();
$('#demoBtn').onclick = () => {
  profile = { name: 'Démo', server: '', username: '', password: '', demo: true };
  db.set('profile', profile);
  showApp();
};
$('#showPassword').onclick = () => {
  const input = $('#password');
  input.type = input.type === 'password' ? 'text' : 'password';
};
$('#clearProfilesBtn').onclick = () => {
  profiles = [];
  db.set('profiles', profiles);
  renderSavedProfiles();
  toast('Profils effacés');
};

document.addEventListener('click', event => {
  const saved = event.target.closest('.savedProfileItem');
  if (!saved) return;
  const index = Number(saved.dataset.index);
  const action = event.target.dataset.action;
  const p = profiles[index];
  if (!p || !action) return;
  if (action === 'fill') fillProfile(p);
  if (action === 'use') connect(p);
  if (action === 'delete') removeProfile(index);
});

$$('.dockItem').forEach(btn => btn.onclick = () => go(btn.dataset.view));
$$('[data-go]').forEach(btn => btn.onclick = () => go(btn.dataset.go));
$('#accountBtn').onclick = () => go('settings');
$('#backCatalog').onclick = () => go('home');
$('#refreshTopBtn').onclick = async () => {
  if (!profile || profile.demo) return toast('Mode démo.');
  try {
    setLoading(true, 'Actualisation des catalogues…');
    await loadAll();
    renderHome();
    if (['live', 'movies', 'series'].includes(currentView)) go(currentView);
    toast('Catalogues actualisés');
  } catch {
    toast('Actualisation impossible');
  } finally {
    setLoading(false);
  }
};

$('#categoryChips').onclick = event => {
  const chip = event.target.closest('.chip');
  if (!chip) return;
  $$('.chip', $('#categoryChips')).forEach(el => el.classList.toggle('active', el === chip));
  const fullList = currentType === 'live' ? data.live : currentType === 'movies' ? data.movies : data.series;
  catalog = chip.dataset.cat === 'all' ? fullList : fullList.filter(item => String(item.category_id) === chip.dataset.cat);
  visible = 60;
  $('#catalogCount').textContent = `${catalog.length} contenu${catalog.length > 1 ? 's' : ''}`;
  renderCatalog();
};

window.addEventListener('scroll', () => {
  if ($('#catalogView').classList.contains('active') && window.innerHeight + window.scrollY > document.body.offsetHeight - 700 && visible < catalog.length) {
    visible += 60;
    renderCatalog();
  }
});

$('#heroPlay').onclick = () => currentItem && play(currentItem.item, currentItem.type);
$('#heroInfo').onclick = () => currentItem && openDetails(currentItem.item, currentItem.type);
$('#closeDetails').onclick = () => show($('#detailsModal'), false);
$('#detailsPlay').onclick = () => currentItem && play(currentItem.item, currentItem.type, currentEpisode);
$('#detailsFav').onclick = () => {
  if (!currentItem) return;
  toggleFav(currentItem.type, idOf(currentItem.type, currentItem.item), currentItem.item);
  $('#detailsFav').textContent = (isFav(currentItem.type, idOf(currentItem.type, currentItem.item)) ? '♥' : '♡') + ' Ma liste';
};

$('#closePlayer').onclick = closePlayer;
$('#favPlayer').onclick = () => {
  if (!currentItem) return;
  toggleFav(currentItem.type, idOf(currentItem.type, currentItem.item), currentItem.item);
  $('#favPlayer').textContent = isFav(currentItem.type, idOf(currentItem.type, currentItem.item)) ? '♥' : '♡';
};
$('#rewindBtn').onclick = () => { $('#video').currentTime = Math.max(0, $('#video').currentTime - 10); };
$('#forwardBtn').onclick = () => { $('#video').currentTime = Math.min(($('#video').duration || 0), $('#video').currentTime + 10); };
$('#playPauseBtn').onclick = () => {
  const video = $('#video');
  if (video.paused) {
    video.play().catch(() => {});
    $('#playPauseBtn').textContent = 'Pause';
  } else {
    video.pause();
    $('#playPauseBtn').textContent = 'Lecture';
  }
};
$('#pipBtn').onclick = async () => {
  const video = $('#video');
  if (!document.pictureInPictureEnabled || !video) return toast('PiP non disponible');
  try { await video.requestPictureInPicture(); } catch { toast('Impossible d’activer le PiP'); }
};
$('#externalOpenBtn').onclick = () => {
  if (!lastUrl) return;
  location.href = lastUrl;
};

$('#searchBtn').onclick = () => {
  show($('#searchOverlay'), true);
  $('#searchInput').focus();
};
$('#closeSearch').onclick = () => show($('#searchOverlay'), false);
$('#clearSearch').onclick = () => {
  $('#searchInput').value = '';
  $('#searchResults').innerHTML = '';
};
$('#searchInput').oninput = event => {
  const query = event.target.value.trim().toLowerCase();
  if (query.length < 2) {
    $('#searchResults').innerHTML = '';
    return;
  }
  const results = [
    ...data.live.map(item => ({ item, type: 'live' })),
    ...data.movies.map(item => ({ item, type: 'movies' })),
    ...data.series.map(item => ({ item, type: 'series' }))
  ].filter(x => titleOf(x.item).toLowerCase().includes(query)).slice(0, 80);
  $('#searchResults').innerHTML = results.map(r => card(r.item, r.type)).join('') || empty('Aucun résultat.');
  bindCards($('#searchResults'));
};

['autoPlay', 'resumePlay', 'externalPlayer'].forEach((id, index) => {
  $('#' + id).onchange = event => {
    settings[['autoplay', 'resume', 'external'][index]] = event.target.checked;
    db.set('settings', settings);
  };
});
$('#liveFormat').onchange = event => {
  settings.liveFormat = event.target.value;
  db.set('settings', settings);
};

$('#refreshBtn').onclick = $('#refreshTopBtn').onclick;
$('#clearCacheBtn').onclick = () => {
  history = [];
  db.set('history', history);
  renderContinue();
  toast('Historique effacé');
};
$('#clearResumeBtn').onclick = () => {
  positions = {};
  db.set('positions', positions);
  toast('Reprises réinitialisées');
};
$('#switchProfile').onclick = () => {
  show($('#app'), false);
  show($('#login'), true);
  window.scrollTo({ top: 0, behavior: 'smooth' });
};
$('#logoutBtn').onclick = () => {
  db.del('profile');
  logout();
};

window.addEventListener('online', handleNetwork);
window.addEventListener('offline', handleNetwork);
handleNetwork();

const video = $('#video');
video.addEventListener('play', () => $('#playPauseBtn').textContent = 'Pause');
video.addEventListener('pause', () => $('#playPauseBtn').textContent = 'Lecture');
video.addEventListener('timeupdate', () => savePosition(false));
video.addEventListener('ended', () => savePosition(true));
video.addEventListener('loadeddata', () => show($('#playerLoader'), false));

renderSavedProfiles();
applySettings();

setTimeout(async () => {
  show($('#splash'), false);
  if (!profile) {
    show($('#login'), true);
    return;
  }

  if (profile.demo) {
    data = demo;
    showApp();
    return;
  }

  try {
    data = db.get('catalog', data);
    showApp();
    if (!data.live.length && !data.movies.length && !data.series.length) {
      setLoading(true, 'Synchronisation des catalogues…');
      await loadAll();
      renderHome();
      setLoading(false);
    }
  } catch {
    toast('Connexion au serveur impossible');
    show($('#login'), true);
    show($('#app'), false);
  }
}, 1100);
