(function () {
  'use strict';

  const $ = selector => document.querySelector(selector);
  const $$ = selector => [...document.querySelectorAll(selector)];
  const ACCOUNT_SECRET_KEY = 'primeiptv.v3.account';
  const ACCOUNT_PROFILE_KEY = 'accountProfileV3';
  const ACCOUNT_FALLBACK_KEY = 'accountFallbackV3';
  const SETTINGS_KEY = 'settingsV3';
  const FAVORITES_KEY = 'favoritesV3';
  const HISTORY_KEY = 'historyV3';
  const POSITIONS_KEY = 'positionsV3';
  const CATALOG_KEY = 'catalogV3';
  const APP_VERSION = '3.0.0';

  const state = {
    account: null,
    auth: null,
    client: null,
    catalog: {
      live: [], movies: [], series: [],
      liveCategories: [], movieCategories: [], seriesCategories: []
    },
    settings: {
      liveFormat: 'm3u8',
      nativeFirst: true,
      resume: true,
      autoPip: true,
      mobileQuality: 'auto',
      nativeSync: true,
      syncHours: 6,
      expiryNotifications: true,
      webFallback: true
    },
    favorites: [],
    history: [],
    positions: {},
    currentPage: 'home',
    catalogType: 'movies',
    activeCategory: 'all',
    visible: 60,
    selection: null,
    currentMedia: null,
    hls: null,
    playToken: 0,
    toastTimer: null,
    nativeCaps: {},
    nativeDiagnostic: {},
    syncNames: [],
    numericZap: '',
    numericTimer: null,
    savePositionTimer: null,
    lastWebPositionSave: 0
  };

  const typeLabels = { live: 'Direct', movies: 'Film', series: 'Série' };

  function hide(element, value = true) {
    element?.classList.toggle('hidden', value);
  }

  function toast(message) {
    const element = $('#toast');
    if (element) {
      element.textContent = message;
      hide(element, false);
      clearTimeout(state.toastTimer);
      state.toastTimer = setTimeout(() => hide(element, true), 2800);
    }
    PrimeNative.toast(message);
  }

  function setMessage(message, error = true) {
    const element = $('#loginMessage');
    if (!element) return;
    element.textContent = message || '';
    element.style.color = error ? '#ff9aa5' : '#9ff0c8';
  }

  function normalizeAccount(raw) {
    if (!raw) return null;
    return {
      name: String(raw.name || 'Maison').trim() || 'Maison',
      server: Xtream.normalizeServer(raw.server),
      username: String(raw.username || '').trim(),
      password: String(raw.password || ''),
      savedAt: Number(raw.savedAt || Date.now()),
      authSnapshot: raw.authSnapshot || null
    };
  }

  function publicAccount(account) {
    if (!account) return null;
    return {
      name: account.name,
      server: account.server,
      username: account.username,
      savedAt: account.savedAt,
      authSnapshot: account.authSnapshot || null
    };
  }

  function validAccount(account) {
    return !!(account?.server && account?.username && account?.password);
  }

  function maskServer(server) {
    try {
      const url = new URL(server);
      return url.host;
    } catch (_) {
      return String(server || '');
    }
  }

  function accountHash(account = state.account) {
    const value = `${account?.username || ''}@${account?.server || ''}`;
    let hash = 5381;
    for (let index = 0; index < value.length; index += 1) {
      hash = ((hash << 5) + hash) ^ value.charCodeAt(index);
    }
    return (hash >>> 0).toString(36);
  }

  function nativeHeaders() {
    return {
      'User-Agent': 'Prime-IPTV-Player/3.0 Android',
      'Referer': state.account?.server || ''
    };
  }

  async function saveAccount(account) {
    state.account = normalizeAccount(account);
    const secretSaved = state.nativeCaps.secureStorage && PrimeNative.secureSet(
      ACCOUNT_SECRET_KEY,
      JSON.stringify(state.account)
    );

    await PrimeDB.set(ACCOUNT_PROFILE_KEY, publicAccount(state.account));
    if (secretSaved) {
      await PrimeDB.del(ACCOUNT_FALLBACK_KEY);
    } else {
      await PrimeDB.set(ACCOUNT_FALLBACK_KEY, state.account);
    }
    return state.account;
  }

  async function loadAccount() {
    state.nativeCaps = PrimeNative.capabilities();
    if (state.nativeCaps.secureStorage) {
      const secured = PrimeNative.secureGet(ACCOUNT_SECRET_KEY, '');
      try {
        const parsed = JSON.parse(secured || 'null');
        if (validAccount(parsed)) return normalizeAccount(parsed);
      } catch (_) {}
    }
    const fallback = await PrimeDB.get(ACCOUNT_FALLBACK_KEY, null);
    if (validAccount(fallback)) return normalizeAccount(fallback);
    return null;
  }

  async function forgetAccount() {
    PrimeNative.secureRemove(ACCOUNT_SECRET_KEY);
    await Promise.all([
      PrimeDB.del(ACCOUNT_PROFILE_KEY),
      PrimeDB.del(ACCOUNT_FALLBACK_KEY),
      PrimeDB.del(CATALOG_KEY)
    ]);
    cancelNativeSync();
    state.account = null;
    state.auth = null;
    state.client = null;
    showLogin(null);
    toast('Compte supprimé de cet appareil');
  }

  function formAccount() {
    return normalizeAccount({
      name: $('#profileName').value,
      server: $('#server').value,
      username: $('#username').value,
      password: $('#password').value
    });
  }

  function fillForm(account) {
    if (!account) return;
    $('#profileName').value = account.name || 'Maison';
    $('#server').value = account.server || '';
    $('#username').value = account.username || '';
    $('#password').value = account.password || '';
  }

  async function saveDraft() {
    const draft = formAccount();
    if (!(draft.server || draft.username || draft.password)) return;
    if (state.nativeCaps.secureStorage) {
      PrimeNative.secureSet('primeiptv.v3.draft', JSON.stringify(draft));
    } else {
      await PrimeDB.set('draftV3', draft);
    }
  }

  async function loadDraft() {
    if (state.nativeCaps.secureStorage) {
      try {
        const value = JSON.parse(PrimeNative.secureGet('primeiptv.v3.draft', '') || 'null');
        if (value) return normalizeAccount(value);
      } catch (_) {}
    }
    return PrimeDB.get('draftV3', null);
  }

  function showSavedCard(account) {
    hide($('#savedAccountCard'), !validAccount(account));
    if (!account) return;
    $('#savedAccountName').textContent = account.name;
    $('#savedAccountServer').textContent = `${maskServer(account.server)} • ${account.username}`;
  }

  function showLogin(account, message = '') {
    hide($('#boot'), true);
    hide($('#appView'), true);
    hide($('#loginView'), false);
    if (account) fillForm(account);
    showSavedCard(account);
    setMessage(message, !!message);
  }

  async function connect(account, { silent = false } = {}) {
    account = normalizeAccount(account);
    if (!validAccount(account)) {
      showLogin(account, 'Serveur, identifiant et mot de passe sont obligatoires.');
      return;
    }

    const button = $('#connectButton');
    button.disabled = true;
    button.textContent = 'Connexion…';
    setMessage(silent ? 'Reconnexion automatique…' : 'Vérification du compte…', false);

    try {
      const client = new Xtream.XtreamClient(account);
      const auth = await client.authenticate();
      const saved = { ...account, savedAt: Date.now(), authSnapshot: auth };
      await saveAccount(saved);
      state.client = client;
      state.auth = auth;
      hide($('#loginView'), true);
      hide($('#appView'), false);
      hide($('#boot'), true);
      renderAccount();
      await loadLocalState();
      await hydrateNativeStores();
      await loadNativeCatalogCache();
      await loadCatalog();
      configureNativeSync(false);
      maybeNotifyExpiry();
      showPage('home');
      setMessage('');
    } catch (error) {
      showLogin(account, `${silent ? 'Reconnexion impossible : ' : 'Connexion impossible : '}${error?.message || 'erreur inconnue'}`);
    } finally {
      button.disabled = false;
      button.textContent = 'Se connecter';
    }
  }

  async function loadLocalState() {
    state.settings = { ...state.settings, ...(await PrimeDB.get(SETTINGS_KEY, {})) };
    state.favorites = await PrimeDB.get(FAVORITES_KEY, []);
    state.history = await PrimeDB.get(HISTORY_KEY, []);
    state.positions = await PrimeDB.get(POSITIONS_KEY, {});

    $('#liveFormat').value = state.settings.liveFormat || 'm3u8';
    $('#nativeFirst').checked = state.settings.nativeFirst !== false;
    $('#resumePlayback').checked = state.settings.resume !== false;
    $('#autoPip').checked = state.settings.autoPip !== false;
    $('#mobileQuality').value = state.settings.mobileQuality || 'auto';
    $('#nativeSync').checked = state.settings.nativeSync !== false;
    $('#syncHours').value = String(state.settings.syncHours || 6);
    $('#expiryNotifications').checked = state.settings.expiryNotifications !== false;
    $('#webFallback').checked = state.settings.webFallback !== false;
  }

  async function saveSettings() {
    await PrimeDB.set(SETTINGS_KEY, state.settings);
  }

  function favoriteKey(reference) {
    return `${reference.kind}:${reference.id}`;
  }

  function normalizeFavorite(reference) {
    return {
      kind: String(reference.kind || reference.type || ''),
      id: String(reference.id || reference.itemId || ''),
      at: Number(reference.at || reference.updatedAt || Date.now())
    };
  }

  function normalizeHistory(entry) {
    const payload = entry.payload || entry;
    return {
      kind: String(payload.kind || ''),
      id: String(payload.id || ''),
      episodeId: String(payload.episodeId || ''),
      title: String(payload.title || ''),
      poster: String(payload.poster || ''),
      at: Number(payload.at || entry.updatedAt || Date.now()),
      positionMs: Number(entry.positionMs || payload.positionMs || 0),
      durationMs: Number(entry.durationMs || payload.durationMs || 0),
      completed: !!(entry.completed || payload.completed)
    };
  }

  async function hydrateNativeStores() {
    if (state.nativeCaps.room) {
      const nativeFavorites = PrimeNative.favorites.list('')
        .map(row => normalizeFavorite(row.payload || row))
        .filter(row => row.kind && row.id);
      const favoriteMap = new Map();
      [...state.favorites, ...nativeFavorites].forEach(item => {
        const normalized = normalizeFavorite(item);
        if (normalized.kind && normalized.id) favoriteMap.set(favoriteKey(normalized), normalized);
      });
      state.favorites = [...favoriteMap.values()].sort((a, b) => b.at - a.at);

      const nativeHistory = PrimeNative.history.list(150)
        .map(normalizeHistory)
        .filter(row => row.kind && row.id);
      const historyMap = new Map();
      [...state.history, ...nativeHistory].forEach(item => {
        const normalized = normalizeHistory(item);
        const key = `${normalized.kind}:${normalized.id}:${normalized.episodeId}`;
        const previous = historyMap.get(key);
        if (!previous || normalized.at >= previous.at) historyMap.set(key, normalized);
      });
      state.history = [...historyMap.values()].sort((a, b) => b.at - a.at).slice(0, 150);
    }

    await Promise.all([
      PrimeDB.set(FAVORITES_KEY, state.favorites),
      PrimeDB.set(HISTORY_KEY, state.history)
    ]);
  }

  function syncDescriptor() {
    if (!state.client || !state.account) return [];
    const tag = accountHash();
    return [
      ['liveCategories', 'get_live_categories'],
      ['movieCategories', 'get_vod_categories'],
      ['seriesCategories', 'get_series_categories'],
      ['live', 'get_live_streams'],
      ['movies', 'get_vod_streams'],
      ['series', 'get_series']
    ].map(([key, action]) => ({
      key,
      name: `prime-v3-${tag}-${key}`,
      url: state.client.apiUrl(action)
    }));
  }

  async function loadNativeCatalogCache() {
    if (!state.nativeCaps.workManager || !state.account || !state.client) return false;
    let loaded = 0;
    for (const descriptor of syncDescriptor()) {
      const raw = PrimeNative.sync.read(descriptor.name);
      if (!raw) continue;
      try {
        const data = JSON.parse(raw);
        if (Array.isArray(data)) {
          state.catalog[descriptor.key] = data;
          loaded += 1;
        }
      } catch (_) {}
    }
    if (loaded) {
      renderAll();
      updateSyncStatus(`${loaded}/6 caches natifs restaurés`);
      return true;
    }
    return false;
  }

  function configureNativeSync(immediate = false) {
    state.syncNames = syncDescriptor().map(item => item.name);
    if (!state.nativeCaps.workManager || !state.settings.nativeSync) {
      updateSyncStatus(state.nativeCaps.workManager ? 'Synchronisation native désactivée' : 'WorkManager indisponible');
      return false;
    }
    const minutes = Math.max(15, Number(state.settings.syncHours || 6) * 60);
    let scheduled = 0;
    for (const descriptor of syncDescriptor()) {
      if (PrimeNative.sync.schedule(descriptor.name, descriptor.url, minutes)) scheduled += 1;
      if (immediate) PrimeNative.sync.now(descriptor.name, descriptor.url);
    }
    updateSyncStatus(`${scheduled}/6 tâches natives planifiées toutes les ${state.settings.syncHours || 6} h`);
    return scheduled > 0;
  }

  function syncNow() {
    if (!state.nativeCaps.workManager) {
      toast('WorkManager n’est pas présent dans cet APK');
      return;
    }
    configureNativeSync(true);
    toast('Synchronisation native lancée en arrière-plan');
  }

  function cancelNativeSync() {
    for (const name of state.syncNames) PrimeNative.sync.cancel(name);
    state.syncNames = [];
  }

  function updateSyncStatus(text) {
    const element = $('#nativeSyncStatus');
    if (element) element.textContent = text;
  }

  async function loadCatalog() {
    const accountId = `${state.account.username}@${state.account.server}`;
    const cache = await PrimeDB.get(CATALOG_KEY, null);
    if (cache?.account === accountId && cache.data) {
      state.catalog = cache.data;
      renderAll();
    }

    $('#refreshButton').classList.add('spinning');
    try {
      state.catalog = await state.client.loadCatalog();
      await PrimeDB.set(CATALOG_KEY, { account: accountId, at: Date.now(), data: state.catalog });
      renderAll();
      toast('Catalogue actualisé');
      if (state.settings.nativeSync) configureNativeSync(true);
    } catch (error) {
      if (!cache?.data && !state.catalog.live.length && !state.catalog.movies.length && !state.catalog.series.length) {
        toast('Catalogue impossible à charger');
      }
    } finally {
      $('#refreshButton').classList.remove('spinning');
    }
  }

  function renderAll() {
    renderCounts();
    renderHome();
    if (['live', 'movies', 'series', 'favorites'].includes(state.currentPage)) renderCatalog();
  }

  function renderCounts() {
    $('#liveCount').textContent = `${state.catalog.live.length} chaîne${state.catalog.live.length > 1 ? 's' : ''}`;
    $('#movieCount').textContent = `${state.catalog.movies.length} film${state.catalog.movies.length > 1 ? 's' : ''}`;
    $('#seriesCount').textContent = `${state.catalog.series.length} série${state.catalog.series.length > 1 ? 's' : ''}`;
    $('#favoriteCount').textContent = `${state.favorites.length} élément${state.favorites.length > 1 ? 's' : ''}`;
  }

  function renderAccount() {
    const userInfo = state.auth?.user_info || state.account?.authSnapshot?.user_info || {};
    const expiry = Xtream.expiryInfo(userInfo);
    const name = state.account?.name || 'Profil';
    $('#accountLabel').textContent = name;
    $('#accountAvatar').textContent = name.slice(0, 1).toUpperCase();
    $('#accountState').textContent = String(userInfo.status || 'Connecté');
    $('#welcomeTitle').textContent = `Bonjour, ${name}`;
    $('#validityText').textContent = expiry.date ? `Valable jusqu’au ${expiry.label}` : expiry.label;
    $('#daysBadge').textContent = expiry.days === null ? '∞' : expiry.expired ? 'Expiré' : `${Math.max(0, expiry.days)} j`;
    $('#infoProfile').textContent = name;
    $('#infoServer').textContent = state.account?.server || '—';
    $('#infoUsername').textContent = state.account?.username || '—';
    $('#infoStatus').textContent = String(userInfo.status || 'Actif');
    $('#infoExpiry').textContent = expiry.label;
    $('#infoRemaining').textContent = expiry.remaining;
    $('#infoConnections').textContent = `${userInfo.active_cons ?? 0} / ${userInfo.max_connections ?? '—'}`;
  }

  function maybeNotifyExpiry() {
    if (!state.settings.expiryNotifications || !state.nativeCaps.notifications) return;
    const userInfo = state.auth?.user_info || {};
    const expiry = Xtream.expiryInfo(userInfo);
    if (expiry.days === null || expiry.days > 7) return;
    const marker = `expiry:${userInfo.exp_date || expiry.label}`;
    if (localStorage.getItem('primeiptv.v3.notification') === marker) return;
    const message = expiry.expired
      ? 'Votre accès IPTV est indiqué comme expiré.'
      : `Votre accès IPTV expire dans ${Math.max(0, expiry.days)} jour${expiry.days > 1 ? 's' : ''}.`;
    if (PrimeNative.notify(3103, 'Prime IPTV — abonnement', message)) {
      localStorage.setItem('primeiptv.v3.notification', marker);
    }
  }

  function itemTitle(item, kind) {
    return String(item?.name || item?.title || item?.channel_name || item?.epg_channel_id || typeLabels[kind] || 'Contenu');
  }

  function itemId(item, kind) {
    return String(kind === 'series'
      ? (item.series_id ?? item.stream_id ?? item.id)
      : (item.stream_id ?? item.id ?? item.series_id));
  }

  function itemImage(item) {
    return String(item?.stream_icon || item?.cover || item?.movie_image || item?.backdrop_path?.[0] || item?.cover_big || '');
  }

  function itemCategory(item) {
    return String(item?.category_id ?? '');
  }

  function itemAdded(item) {
    return Number(item?.added || item?.last_modified || 0);
  }

  function imageStyle(url) {
    return url ? `url("${String(url).replace(/["\\]/g, '')}")` : '';
  }

  function progressFor(kind, id) {
    const entry = state.history.find(item => item.kind === kind && item.id === String(id));
    if (!entry || !entry.durationMs || entry.completed) return 0;
    return Math.max(0, Math.min(100, Math.round((entry.positionMs / entry.durationMs) * 100)));
  }

  function posterCard(item, kind) {
    const button = document.createElement('button');
    button.className = 'poster-card';
    button.dataset.kind = kind;
    button.dataset.id = itemId(item, kind);
    const poster = document.createElement('div');
    poster.className = 'poster';
    const image = itemImage(item);
    if (image) poster.style.backgroundImage = imageStyle(image);
    const progress = progressFor(kind, itemId(item, kind));
    if (progress > 0) {
      const rail = document.createElement('span');
      rail.className = 'watch-progress';
      rail.style.setProperty('--progress', `${progress}%`);
      poster.appendChild(rail);
    }
    const title = document.createElement('strong');
    title.textContent = itemTitle(item, kind);
    const meta = document.createElement('small');
    meta.textContent = kind === 'live' ? 'En direct' : kind === 'movies' ? (item.year || 'Film') : (item.year || 'Série');
    button.append(poster, title, meta);
    return button;
  }

  function appendCards(container, entries) {
    container.replaceChildren();
    entries.forEach(({ item, kind }) => container.appendChild(posterCard(item, kind)));
  }

  function renderHome() {
    const recent = [
      ...state.catalog.movies.map(item => ({ item, kind: 'movies' })),
      ...state.catalog.series.map(item => ({ item, kind: 'series' }))
    ].sort((a, b) => itemAdded(b.item) - itemAdded(a.item)).slice(0, 24);
    appendCards($('#recentRail'), recent);

    const historyEntries = state.history.slice(0, 30).map(entry => {
      const item = findItem(entry.kind, entry.id);
      return item ? { item, kind: entry.kind } : null;
    }).filter(Boolean);
    hide($('#continueSection'), !historyEntries.length);
    if (historyEntries.length) appendCards($('#continueRail'), historyEntries);
  }

  function findItem(kind, id) {
    const list = kind === 'live' ? state.catalog.live : kind === 'movies' ? state.catalog.movies : state.catalog.series;
    return list.find(item => itemId(item, kind) === String(id));
  }

  function categoriesFor(kind) {
    return kind === 'live' ? state.catalog.liveCategories : kind === 'movies' ? state.catalog.movieCategories : state.catalog.seriesCategories;
  }

  function itemsFor(kind) {
    if (kind === 'favorites') {
      return state.favorites.map(reference => {
        const item = findItem(reference.kind, reference.id);
        return item ? { item, kind: reference.kind } : null;
      }).filter(Boolean);
    }
    const source = kind === 'live' ? state.catalog.live : kind === 'movies' ? state.catalog.movies : state.catalog.series;
    return source.map(item => ({ item, kind }));
  }

  function renderCatalog() {
    const kind = state.catalogType;
    const all = itemsFor(kind);
    const filtered = state.activeCategory === 'all' || kind === 'favorites'
      ? all
      : all.filter(entry => itemCategory(entry.item) === state.activeCategory);
    const shown = filtered.slice(0, state.visible);
    const grid = $('#catalogGrid');
    grid.replaceChildren();
    shown.forEach(entry => grid.appendChild(posterCard(entry.item, entry.kind)));
    $('#catalogMeta').textContent = `${filtered.length} contenu${filtered.length > 1 ? 's' : ''}`;
    hide($('#loadMoreButton'), shown.length >= filtered.length);
  }

  function renderCategories(kind) {
    const bar = $('#categoryBar');
    bar.replaceChildren();
    if (kind === 'favorites') {
      hide(bar, true);
      return;
    }
    hide(bar, false);
    const all = document.createElement('button');
    all.className = 'category-chip active';
    all.dataset.category = 'all';
    all.textContent = 'Tout';
    bar.appendChild(all);
    categoriesFor(kind).forEach(category => {
      const button = document.createElement('button');
      button.className = 'category-chip';
      button.dataset.category = String(category.category_id);
      button.textContent = String(category.category_name || 'Catégorie');
      bar.appendChild(button);
    });
  }

  function showPage(page) {
    if (['live', 'movies', 'series', 'favorites'].includes(page)) {
      state.catalogType = page;
      state.activeCategory = 'all';
      state.visible = 60;
      $('#catalogTitle').textContent = page === 'live' ? 'Direct' : page === 'movies' ? 'Films' : page === 'series' ? 'Séries' : 'Favoris';
      $('#catalogEyebrow').textContent = page === 'favorites' ? 'MA LISTE' : 'CATALOGUE';
      renderCategories(page);
      renderCatalog();
      page = 'catalog';
    }
    $$('.page').forEach(element => element.classList.remove('active'));
    const target = page === 'home' ? $('#homePage') : page === 'settings' ? $('#settingsPage') : $('#catalogPage');
    target.classList.add('active');
    state.currentPage = page === 'catalog' ? state.catalogType : page;
    $$('.bottom-nav button').forEach(button => button.classList.toggle('active', button.dataset.page === state.currentPage));
    window.scrollTo(0, 0);
    focusFirstInteractive(target);
  }

  function decodeMaybeBase64(value) {
    if (!value) return '';
    try {
      const decoded = decodeURIComponent(escape(atob(String(value))));
      if (/^[\s\S]{1,1000}$/.test(decoded)) return decoded;
    } catch (_) {}
    return String(value);
  }

  async function openDetail(kind, item) {
    state.selection = { kind, item, info: null, episode: null };
    $('#detailType').textContent = typeLabels[kind]?.toUpperCase() || 'CONTENU';
    $('#detailTitle').textContent = itemTitle(item, kind);
    $('#detailMeta').textContent = [item.year || item.releaseDate, item.rating ? `★ ${item.rating}` : '', item.genre || ''].filter(Boolean).join(' • ');
    $('#detailDescription').textContent = item.plot || item.description || 'Informations non communiquées par le serveur.';
    const image = item.backdrop_path?.[0] || itemImage(item);
    $('#detailBackdropImage').style.backgroundImage = imageStyle(image);
    hide($('#seriesPicker'), kind !== 'series');
    hide($('#liveEpg'), kind !== 'live');
    setFavoriteButton();
    hide($('#detailOverlay'), false);
    focusFirstInteractive($('#detailOverlay'));

    if (kind === 'movies') {
      try {
        const info = await state.client.getVodInfo(item.stream_id);
        if (!state.selection || state.selection.item !== item) return;
        state.selection.info = info;
        const data = info.info || {};
        $('#detailDescription').textContent = data.plot || data.description || $('#detailDescription').textContent;
        $('#detailMeta').textContent = [
          data.releasedate || data.releaseDate || item.year,
          data.duration || formatDuration(data.duration_secs),
          data.rating ? `★ ${data.rating}` : '',
          data.genre
        ].filter(Boolean).join(' • ');
      } catch (_) {}
    }

    if (kind === 'series') await loadSeriesDetails(item);
    if (kind === 'live') await loadLiveEpg(item);
  }

  async function loadLiveEpg(item) {
    const box = $('#liveEpgList');
    box.innerHTML = '<p class="muted">Chargement du programme TV…</p>';
    try {
      const result = await state.client.getShortEpg(item.stream_id, 8);
      const rows = Array.isArray(result?.epg_listings) ? result.epg_listings : [];
      box.replaceChildren();
      if (!rows.length) {
        box.innerHTML = '<p class="muted">Programme TV non communiqué.</p>';
        return;
      }
      rows.forEach((row, index) => {
        const article = document.createElement('article');
        article.className = `epg-item${index === 0 ? ' current' : ''}`;
        const time = document.createElement('time');
        time.textContent = String(row.start || row.start_timestamp ? formatEpgTime(row.start, row.start_timestamp) : '—');
        const content = document.createElement('div');
        const title = document.createElement('strong');
        title.textContent = decodeMaybeBase64(row.title) || 'Programme';
        const description = document.createElement('small');
        description.textContent = decodeMaybeBase64(row.description) || '';
        content.append(title, description);
        article.append(time, content);
        box.appendChild(article);
      });
    } catch (_) {
      box.innerHTML = '<p class="muted">Programme TV indisponible.</p>';
    }
  }

  function formatEpgTime(value, timestamp) {
    let date;
    if (timestamp && Number.isFinite(Number(timestamp))) date = new Date(Number(timestamp) * 1000);
    else date = new Date(String(value).replace(' ', 'T'));
    if (Number.isNaN(date.getTime())) return String(value || '—').slice(11, 16);
    return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  }

  async function loadSeriesDetails(item) {
    const box = $('#episodeList');
    box.innerHTML = '<p class="muted">Chargement des épisodes…</p>';
    try {
      const info = await state.client.getSeriesInfo(item.series_id);
      if (!state.selection || state.selection.item !== item) return;
      state.selection.info = info;
      const data = info.info || {};
      $('#detailDescription').textContent = data.plot || data.description || $('#detailDescription').textContent;
      $('#detailMeta').textContent = [data.releaseDate || data.year, data.rating ? `★ ${data.rating}` : '', data.genre].filter(Boolean).join(' • ');
      const seasons = Object.keys(info.episodes || {}).sort((a, b) => Number(a) - Number(b));
      const select = $('#seasonSelect');
      select.replaceChildren();
      seasons.forEach(season => {
        const option = document.createElement('option');
        option.value = season;
        option.textContent = `Saison ${season}`;
        select.appendChild(option);
      });
      renderEpisodes(seasons[0]);
      select.onchange = () => renderEpisodes(select.value);
    } catch (_) {
      box.innerHTML = '<p class="muted">Épisodes indisponibles.</p>';
    }
  }

  function renderEpisodes(season) {
    const episodes = state.selection?.info?.episodes?.[season] || [];
    const box = $('#episodeList');
    box.replaceChildren();
    episodes.forEach((episode, index) => {
      const button = document.createElement('button');
      button.className = 'episode-item';
      button.dataset.episode = String(index);
      const number = document.createElement('span');
      number.className = 'episode-number';
      number.textContent = String(episode.episode_num || index + 1);
      const content = document.createElement('div');
      const title = document.createElement('strong');
      title.textContent = episode.title || `Épisode ${episode.episode_num || index + 1}`;
      const meta = document.createElement('small');
      meta.textContent = [episode.info?.duration, episode.container_extension?.toUpperCase()].filter(Boolean).join(' • ');
      content.append(title, meta);
      button.append(number, content);
      box.appendChild(button);
    });
    box.dataset.season = season;
  }

  function closeDetail() {
    hide($('#detailOverlay'), true);
    state.selection = null;
  }

  function favoriteRef() {
    const selection = state.selection;
    return selection ? { kind: selection.kind, id: itemId(selection.item, selection.kind), at: Date.now() } : null;
  }

  function isFavorite(reference) {
    return !!reference && state.favorites.some(item => item.kind === reference.kind && item.id === reference.id);
  }

  function setFavoriteButton() {
    const active = isFavorite(favoriteRef());
    $('#favoriteButton').textContent = active ? '♥ Favori' : '♡ Favori';
  }

  async function toggleFavorite() {
    const reference = favoriteRef();
    if (!reference) return;
    const index = state.favorites.findIndex(item => item.kind === reference.kind && item.id === reference.id);
    if (index >= 0) {
      state.favorites.splice(index, 1);
      if (state.nativeCaps.room) PrimeNative.favorites.remove(reference.kind, reference.id);
    } else {
      state.favorites.unshift(reference);
      if (state.nativeCaps.room) {
        PrimeNative.favorites.save(reference.kind, reference.id, {
          ...reference,
          item: state.selection.item,
          title: itemTitle(state.selection.item, reference.kind),
          poster: itemImage(state.selection.item)
        });
      }
    }
    await PrimeDB.set(FAVORITES_KEY, state.favorites);
    setFavoriteButton();
    renderCounts();
    PrimeNative.vibrate(45);
    toast(index >= 0 ? 'Retiré des favoris' : 'Ajouté aux favoris');
  }

  function formatDuration(seconds) {
    const value = Number(seconds);
    if (!Number.isFinite(value)) return '';
    const hours = Math.floor(value / 3600);
    const minutes = Math.floor((value % 3600) / 60);
    return hours ? `${hours} h ${minutes} min` : `${minutes} min`;
  }

  function mimeFor(url) {
    const value = String(url).toLowerCase();
    if (value.includes('.m3u8')) return 'application/x-mpegURL';
    if (value.includes('.mpd')) return 'application/dash+xml';
    if (value.includes('.mp4')) return 'video/mp4';
    if (value.includes('.ts')) return 'video/mp2t';
    if (value.includes('.webm')) return 'video/webm';
    return 'application/octet-stream';
  }

  function mediaFromSelection(episode = null) {
    const selection = state.selection;
    if (!selection) return null;
    let candidates = [];
    let title = itemTitle(selection.item, selection.kind);
    if (selection.kind === 'live') {
      candidates = state.client.liveCandidates(selection.item, state.settings.liveFormat);
    } else if (selection.kind === 'movies') {
      candidates = state.client.movieCandidates(selection.item, selection.info || {});
    } else {
      if (!episode) return null;
      candidates = state.client.episodeCandidates(episode);
      title = episode.title || title;
    }
    return {
      kind: selection.kind,
      id: itemId(selection.item, selection.kind),
      episodeId: episode?.id ? String(episode.id) : '',
      title,
      poster: itemImage(selection.item),
      candidates,
      type: selection.kind === 'live' ? 'live' : 'video'
    };
  }

  function mediaKey(media) {
    return `${media.kind}:${media.id}:${media.episodeId || ''}`;
  }

  async function rememberHistory(media, positionMs = 0, durationMs = 0, completed = false) {
    const key = mediaKey(media);
    state.history = state.history.filter(item => `${item.kind}:${item.id}:${item.episodeId || ''}` !== key);
    const entry = {
      kind: media.kind,
      id: media.id,
      episodeId: media.episodeId || '',
      title: media.title,
      poster: media.poster,
      at: Date.now(),
      positionMs: Math.max(0, Number(positionMs) || 0),
      durationMs: Math.max(0, Number(durationMs) || 0),
      completed: !!completed
    };
    state.history.unshift(entry);
    state.history = state.history.slice(0, 150);
    await PrimeDB.set(HISTORY_KEY, state.history);
    if (state.nativeCaps.room) {
      PrimeNative.history.save(key, entry, entry.positionMs, entry.durationMs, entry.completed);
    }
    renderHome();
  }

  function nativeStartPosition(media) {
    if (!state.settings.resume || media.kind === 'live') return -1;
    const seconds = Number(state.positions[mediaKey(media)] || 0);
    return seconds > 8 ? Math.floor(seconds * 1000) : -1;
  }

  function openNativeMedia(media, castRequested = false) {
    const success = PrimeNative.play({
      url: media.candidates[0],
      title: media.title,
      poster: media.poster,
      headers: nativeHeaders(),
      startPositionMs: nativeStartPosition(media),
      autoplay: true
    });
    if (success) {
      toast(castRequested
        ? 'Lecteur natif ouvert : utilisez l’icône Cast du lecteur'
        : 'Ouverture du lecteur Media3…');
    }
    return success;
  }

  async function startPlayback(episode = null, forceWeb = false) {
    const media = mediaFromSelection(episode);
    if (!media?.candidates.length) {
      toast('Le serveur n’a fourni aucun flux lisible');
      return;
    }
    state.currentMedia = media;
    await rememberHistory(media);
    closeDetail();

    if (!forceWeb && state.settings.nativeFirst && state.nativeCaps.nativePlayer && openNativeMedia(media)) {
      return;
    }
    if (!state.settings.webFallback && !forceWeb) {
      toast('Lecteur natif indisponible et lecteur Web désactivé');
      return;
    }
    openWebPlayer(media);
  }

  function openWebPlayer(media) {
    hide($('#playerOverlay'), false);
    $('#playerTitle').textContent = media.title;
    $('#playerSubtitle').textContent = `${typeLabels[media.kind] || 'Lecture'} • lecteur Web`;
    $('#playerErrorText').textContent = '';
    hide($('#playerError'), true);
    state.playToken += 1;
    setWebMediaSession(media);
    tryCandidate(0, state.playToken);
  }

  function destroyHls() {
    try { state.hls?.destroy(); } catch (_) {}
    state.hls = null;
  }

  function resetVideo() {
    const video = $('#videoPlayer');
    video.pause();
    video.removeAttribute('src');
    video.load();
  }

  function hlsConfiguration(media) {
    const config = {
      enableWorker: true,
      lowLatencyMode: media.kind === 'live',
      backBufferLength: media.kind === 'live' ? 30 : 90,
      maxBufferLength: media.kind === 'live' ? 20 : 45,
      fragLoadingTimeOut: 18000,
      manifestLoadingTimeOut: 18000,
      levelLoadingTimeOut: 18000,
      maxBufferHole: 0.7
    };
    if (state.settings.mobileQuality === '720') config.capLevelToPlayerSize = true;
    if (state.settings.mobileQuality === '480') config.maxHdcpLevel = 'TYPE-0';
    return config;
  }

  function tryCandidate(index, token) {
    if (token !== state.playToken) return;
    const media = state.currentMedia;
    if (!media) return;
    if (index >= media.candidates.length) {
      showPlayerError('Aucun format proposé par le serveur n’a pu être lu. Media3 ou un lecteur externe peut prendre en charge davantage de codecs.');
      return;
    }

    const url = media.candidates[index];
    const video = $('#videoPlayer');
    destroyHls();
    resetVideo();
    hide($('#playerLoading'), false);
    hide($('#playerError'), true);
    let settled = false;

    const success = () => {
      if (settled || token !== state.playToken) return;
      settled = true;
      hide($('#playerLoading'), true);
      const resume = state.settings.resume ? Number(state.positions[mediaKey(media)] || 0) : 0;
      if (resume > 8 && Number.isFinite(resume) && media.kind !== 'live') {
        try { video.currentTime = resume; } catch (_) {}
      }
      video.play().catch(() => {});
    };

    const failure = () => {
      if (settled || token !== state.playToken) return;
      settled = true;
      setTimeout(() => tryCandidate(index + 1, token), 220);
    };

    const isHls = /\.m3u8(?:$|\?)/i.test(url);
    if (isHls && window.Hls?.isSupported?.()) {
      const hls = new Hls(hlsConfiguration(media));
      state.hls = hls;
      hls.attachMedia(video);
      hls.on(Hls.Events.MEDIA_ATTACHED, () => hls.loadSource(url));
      hls.on(Hls.Events.MANIFEST_PARSED, success);
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (!data?.fatal) return;
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
          try { hls.startLoad(); } catch (_) { failure(); }
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          try { hls.recoverMediaError(); } catch (_) { failure(); }
        } else {
          failure();
        }
      });
      return;
    }

    video.addEventListener('canplay', success, { once: true });
    video.addEventListener('loadedmetadata', success, { once: true });
    video.addEventListener('error', failure, { once: true });
    video.src = url;
    video.load();
    setTimeout(() => {
      if (!settled && video.readyState === 0) failure();
    }, 22000);
  }

  function showPlayerError(message) {
    hide($('#playerLoading'), true);
    $('#playerErrorText').textContent = message;
    hide($('#playerError'), false);
  }

  async function savePosition(completed = false) {
    const media = state.currentMedia;
    const video = $('#videoPlayer');
    if (!media || media.kind === 'live' || !Number.isFinite(video.currentTime)) return;
    const current = Math.max(0, Math.floor(video.currentTime));
    const duration = Number.isFinite(video.duration) ? Math.max(0, Math.floor(video.duration)) : 0;
    state.positions[mediaKey(media)] = current;
    await PrimeDB.set(POSITIONS_KEY, state.positions);
    await rememberHistory(media, current * 1000, duration * 1000, completed || (duration > 0 && current / duration > 0.94));
  }

  function closePlayer() {
    savePosition();
    state.playToken += 1;
    destroyHls();
    resetVideo();
    hide($('#playerOverlay'), true);
    state.currentMedia = null;
    clearWebMediaSession();
  }

  async function castCurrent() {
    let media = state.currentMedia;
    if (!media && state.selection) media = mediaFromSelection(state.selection.episode);
    if (!media?.candidates?.length) {
      toast('Choisissez d’abord un film, un épisode ou une chaîne');
      return;
    }
    state.currentMedia = media;
    if (state.nativeCaps.cast && openNativeMedia(media, true)) return;
    const video = $('#videoPlayer');
    try {
      if (video.remote?.prompt) {
        await video.remote.prompt();
        return;
      }
    } catch (_) {}
    toast('Google Cast nécessite le profil IPTV natif de HTMLtoAPK V16');
  }

  function requestPip() {
    const video = $('#videoPlayer');
    try {
      if (PrimeNative.enterPip()) {
        toast('Mode Picture-in-Picture Android');
        return;
      }
      if (document.pictureInPictureEnabled && video && !video.disablePictureInPicture) {
        video.requestPictureInPicture().catch(() => toast('Picture-in-Picture indisponible'));
        return;
      }
      toast('Picture-in-Picture indisponible dans cet APK');
    } catch (_) {
      toast('Impossible d’activer le Picture-in-Picture');
    }
  }

  function openExternalCurrent() {
    const media = state.currentMedia;
    if (!media?.candidates?.length) {
      toast('Aucun flux en cours');
      return;
    }
    if (PrimeNative.external({ url: media.candidates[0], title: media.title })) {
      toast('Ouverture du lecteur externe…');
      return;
    }
    toast('Aucun lecteur externe compatible');
  }

  function zap(delta) {
    if (state.currentMedia?.kind !== 'live') return;
    const list = state.catalog.live;
    const index = list.findIndex(item => itemId(item, 'live') === String(state.currentMedia.id));
    if (index < 0 || !list.length) return;
    const next = list[(index + delta + list.length) % list.length];
    state.selection = { kind: 'live', item: next, info: null, episode: null };
    startPlayback();
  }

  function zapToNumber(number) {
    const index = Number(number) - 1;
    const item = state.catalog.live[index];
    if (!item) {
      toast(`Chaîne ${number} introuvable`);
      return;
    }
    state.selection = { kind: 'live', item, info: null, episode: null };
    startPlayback();
  }

  function showNumericZap(digit) {
    state.numericZap = `${state.numericZap}${digit}`.slice(-4);
    let overlay = $('#numericZap');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'numericZap';
      overlay.className = 'numeric-zap';
      document.body.appendChild(overlay);
    }
    overlay.textContent = state.numericZap;
    clearTimeout(state.numericTimer);
    state.numericTimer = setTimeout(() => {
      const number = state.numericZap;
      state.numericZap = '';
      overlay.remove();
      if (number) zapToNumber(number);
    }, 1200);
  }

  function setWebMediaSession(media) {
    if (!('mediaSession' in navigator)) return;
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: media.title,
        artist: 'Prime IPTV Player',
        album: typeLabels[media.kind] || 'IPTV',
        artwork: media.poster ? [{ src: media.poster }] : []
      });
      const video = $('#videoPlayer');
      navigator.mediaSession.setActionHandler('play', () => video.play());
      navigator.mediaSession.setActionHandler('pause', () => video.pause());
      navigator.mediaSession.setActionHandler('seekbackward', details => video.currentTime = Math.max(0, video.currentTime - (details.seekOffset || 10)));
      navigator.mediaSession.setActionHandler('seekforward', details => video.currentTime = Math.min(video.duration || Infinity, video.currentTime + (details.seekOffset || 10)));
      navigator.mediaSession.setActionHandler('previoustrack', () => zap(-1));
      navigator.mediaSession.setActionHandler('nexttrack', () => zap(1));
    } catch (_) {}
  }

  function clearWebMediaSession() {
    if (!('mediaSession' in navigator)) return;
    try { navigator.mediaSession.metadata = null; } catch (_) {}
  }

  function openSearch() {
    hide($('#searchOverlay'), false);
    $('#searchInput').value = '';
    $('#searchResults').replaceChildren();
    setTimeout(() => $('#searchInput').focus(), 100);
  }

  function doSearch(query) {
    const value = String(query).trim().toLowerCase();
    const box = $('#searchResults');
    box.replaceChildren();
    if (value.length < 2) return;
    const all = [...itemsFor('live'), ...itemsFor('movies'), ...itemsFor('series')]
      .filter(entry => itemTitle(entry.item, entry.kind).toLowerCase().includes(value))
      .slice(0, 150);
    all.forEach(entry => box.appendChild(posterCard(entry.item, entry.kind)));
  }

  function delegatedCard(event) {
    const card = event.target.closest('[data-kind][data-id]');
    if (!card) return;
    const item = findItem(card.dataset.kind, card.dataset.id);
    if (item) openDetail(card.dataset.kind, item);
  }

  function capabilityReport() {
    state.nativeCaps = PrimeNative.capabilities();
    const rows = [
      ['Pont Android V16', state.nativeCaps.bridge],
      ['Media3 / ExoPlayer', state.nativeCaps.nativePlayer],
      ['MediaSession', state.nativeCaps.mediaSession],
      ['Google Cast', state.nativeCaps.cast],
      ['Picture-in-Picture', state.nativeCaps.pip],
      ['Lecteur externe', state.nativeCaps.externalPlayer],
      ['Stockage Android Keystore', state.nativeCaps.secureStorage],
      ['Room favoris / historique', state.nativeCaps.room],
      ['WorkManager synchronisation', state.nativeCaps.workManager],
      ['Notifications Android', state.nativeCaps.notifications],
      ['Android TV / télécommande', state.nativeCaps.androidTv],
      ['Diagnostic natif', state.nativeCaps.diagnostics],
      ['Fichiers / export Android', state.nativeCaps.files]
    ];
    return { capabilities: state.nativeCaps, rows, text: rows.map(([name, enabled]) => `${enabled ? '✅' : '❌'} ${name}`).join('\n') };
  }

  function renderNativeModuleGrid() {
    const report = capabilityReport();
    const grid = $('#nativeModuleGrid');
    if (!grid) return;
    grid.replaceChildren();
    report.rows.forEach(([name, enabled]) => {
      const row = document.createElement('div');
      row.className = `module-status ${enabled ? 'enabled' : 'disabled'}`;
      row.innerHTML = `<span>${enabled ? '✓' : '×'}</span><strong>${name}</strong>`;
      grid.appendChild(row);
    });
    const enabledCount = report.rows.filter(row => row[1]).length;
    $('#capabilitySummary').textContent = `${enabledCount}/${report.rows.length} capacités natives détectées dans cet APK.`;
    document.body.classList.toggle('tv-mode', !!(state.nativeCaps.television || state.nativeCaps.androidTv && matchMedia('(min-width:1000px)').matches));
  }

  function buildDiagnostic() {
    const report = capabilityReport();
    const account = state.account;
    state.nativeDiagnostic = PrimeNative.diagnostics();
    return [
      `Prime IPTV Player V3 — Diagnostic`,
      `Version : ${APP_VERSION}`,
      `Date : ${new Date().toLocaleString('fr-FR')}`,
      `Réseau Web : ${navigator.onLine ? 'connecté' : 'hors connexion'}`,
      `Navigateur : ${navigator.userAgent}`,
      `Serveur : ${account ? maskServer(account.server) : 'non connecté'}`,
      `Compte : ${account?.username || 'non connecté'}`,
      `Catalogue : ${state.catalog.live.length} chaînes / ${state.catalog.movies.length} films / ${state.catalog.series.length} séries`,
      `Favoris : ${state.favorites.length}`,
      `Historique : ${state.history.length}`,
      '',
      report.text,
      '',
      `Format direct : ${state.settings.liveFormat}`,
      `Lecteur Android prioritaire : ${state.settings.nativeFirst ? 'oui' : 'non'}`,
      `Reprise : ${state.settings.resume ? 'oui' : 'non'}`,
      `Synchronisation native : ${state.settings.nativeSync ? `oui, ${state.settings.syncHours} h` : 'non'}`,
      `Stockage des identifiants : ${state.nativeCaps.secureStorage ? 'Android Keystore AES-GCM' : 'repli local IndexedDB'}`,
      '',
      'Diagnostic Android natif :',
      JSON.stringify(state.nativeDiagnostic, null, 2)
    ].join('\n');
  }

  function openDiagnostic() {
    $('#diagnosticOutput').textContent = buildDiagnostic();
    hide($('#diagnosticOverlay'), false);
    focusFirstInteractive($('#diagnosticOverlay'));
  }

  async function copyDiagnostic() {
    const text = buildDiagnostic();
    if (PrimeNative.copyText(text)) {
      toast('Diagnostic copié');
      return;
    }
    try {
      await navigator.clipboard.writeText(text);
      toast('Diagnostic copié');
    } catch (_) {
      toast('Copie impossible');
    }
  }

  function shareDiagnostic() {
    const text = buildDiagnostic();
    if (PrimeNative.share(text)) {
      toast('Menu de partage ouvert');
      return;
    }
    copyDiagnostic();
  }

  function exportDiagnostic() {
    const text = buildDiagnostic();
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    if (PrimeNative.downloadText(`prime-iptv-v3-diagnostic-${stamp}.txt`, text, 'text/plain')) {
      toast('Diagnostic enregistré dans Téléchargements');
      return;
    }
    shareDiagnostic();
  }

  function clearHistory() {
    state.history = [];
    state.positions = {};
    PrimeDB.set(HISTORY_KEY, []);
    PrimeDB.set(POSITIONS_KEY, {});
    if (state.nativeCaps.room) PrimeNative.history.clear();
    renderHome();
    toast('Historique de lecture effacé');
  }

  function setNetworkBadge() {
    let badge = $('#networkBadge');
    if (!navigator.onLine) {
      if (!badge) {
        badge = document.createElement('div');
        badge.id = 'networkBadge';
        badge.className = 'network-badge';
        document.body.appendChild(badge);
      }
      badge.textContent = 'Connexion Internet indisponible';
    } else {
      badge?.remove();
    }
  }

  function focusFirstInteractive(scope) {
    if (!document.body.classList.contains('tv-mode') || !scope) return;
    requestAnimationFrame(() => {
      const element = scope.querySelector('button:not(.overlay-backdrop):not([disabled]), input:not([disabled]), select:not([disabled])');
      element?.focus({ preventScroll: true });
    });
  }

  function handleAndroidTvKey(event) {
    const detail = event.detail || {};
    const key = String(detail.key || '');
    if (/KEYCODE_[0-9]$/.test(key)) {
      showNumericZap(key.slice(-1));
      return;
    }
    if (key === 'KEYCODE_MEDIA_NEXT') zap(1);
    if (key === 'KEYCODE_MEDIA_PREVIOUS') zap(-1);
    if (key === 'KEYCODE_MEDIA_PLAY_PAUSE' && !$('#playerOverlay').classList.contains('hidden')) {
      const video = $('#videoPlayer');
      if (video.paused) video.play(); else video.pause();
    }
  }

  function bindEvents() {
    $('#loginForm').addEventListener('submit', event => {
      event.preventDefault();
      connect(formAccount());
    });

    ['profileName', 'server', 'username', 'password'].forEach(id => {
      $(`#${id}`).addEventListener('input', () => {
        clearTimeout(window.__primeDraftTimer);
        window.__primeDraftTimer = setTimeout(saveDraft, 400);
      });
    });

    $('#togglePassword').onclick = () => {
      const password = $('#password');
      password.type = password.type === 'password' ? 'text' : 'password';
      $('#togglePassword').textContent = password.type === 'password' ? 'Afficher' : 'Masquer';
    };

    $('#quickConnectButton').onclick = () => state.account && connect(state.account);
    $$('.quick-card,.bottom-nav button').forEach(button => button.onclick = () => showPage(button.dataset.page));
    $('#catalogBack').onclick = $('#settingsBack').onclick = () => showPage('home');
    $('#accountButton').onclick = () => showPage('settings');
    $('#refreshButton').onclick = () => loadCatalog();
    $('#searchButton').onclick = $('#catalogSearch').onclick = openSearch;
    $('#closeSearch').onclick = () => hide($('#searchOverlay'), true);
    $('#searchInput').oninput = event => doSearch(event.target.value);
    $('#recentRail').onclick = $('#continueRail').onclick = $('#catalogGrid').onclick = $('#searchResults').onclick = delegatedCard;

    $('#categoryBar').onclick = event => {
      const button = event.target.closest('[data-category]');
      if (!button) return;
      state.activeCategory = button.dataset.category;
      state.visible = 60;
      $$('.category-chip').forEach(element => element.classList.toggle('active', element === button));
      renderCatalog();
    };

    $('#loadMoreButton').onclick = () => {
      state.visible += 60;
      renderCatalog();
    };

    $('#detailBackdrop').onclick = $('#closeDetail').onclick = closeDetail;
    $('#favoriteButton').onclick = toggleFavorite;
    $('#playButton').onclick = () => startPlayback();
    $('#castButton').onclick = castCurrent;

    $('#episodeList').onclick = event => {
      const button = event.target.closest('[data-episode]');
      if (!button) return;
      const season = $('#episodeList').dataset.season;
      const episode = state.selection?.info?.episodes?.[season]?.[Number(button.dataset.episode)];
      if (episode) {
        state.selection.episode = episode;
        startPlayback(episode);
      }
    };

    $('#closePlayer').onclick = closePlayer;
    $('#retryPlayer').onclick = () => state.currentMedia && tryCandidate(0, ++state.playToken);
    $('#openNativePlayer').onclick = () => {
      const media = state.currentMedia;
      if (media && openNativeMedia(media)) return;
      toast('Lecteur Media3 indisponible');
    };
    $('#topCastButton').onclick = $('#playerCastButton').onclick = castCurrent;
    $('#playerPipButton').onclick = requestPip;
    $('#playerExternalButton').onclick = openExternalCurrent;

    const video = $('#videoPlayer');
    video.addEventListener('timeupdate', () => {
      const now = Date.now();
      if (now - state.lastWebPositionSave >= 8000) {
        state.lastWebPositionSave = now;
        savePosition();
      }
    });
    video.addEventListener('ended', () => savePosition(true));

    $('#liveFormat').onchange = async event => {
      state.settings.liveFormat = event.target.value;
      await saveSettings();
    };
    $('#nativeFirst').onchange = async event => {
      state.settings.nativeFirst = event.target.checked;
      await saveSettings();
    };
    $('#resumePlayback').onchange = async event => {
      state.settings.resume = event.target.checked;
      await saveSettings();
    };
    $('#autoPip').onchange = async event => {
      state.settings.autoPip = event.target.checked;
      await saveSettings();
    };
    $('#mobileQuality').onchange = async event => {
      state.settings.mobileQuality = event.target.value;
      await saveSettings();
    };
    $('#nativeSync').onchange = async event => {
      state.settings.nativeSync = event.target.checked;
      await saveSettings();
      if (state.settings.nativeSync) configureNativeSync(true); else cancelNativeSync();
    };
    $('#syncHours').onchange = async event => {
      state.settings.syncHours = Math.max(1, Number(event.target.value) || 6);
      await saveSettings();
      configureNativeSync(false);
    };
    $('#expiryNotifications').onchange = async event => {
      state.settings.expiryNotifications = event.target.checked;
      await saveSettings();
      maybeNotifyExpiry();
    };
    $('#webFallback').onchange = async event => {
      state.settings.webFallback = event.target.checked;
      await saveSettings();
    };

    $('#changeAccountButton').onclick = () => showLogin(state.account);
    $('#forgetAccountButton').onclick = () => {
      if (confirm('Supprimer définitivement les identifiants enregistrés sur cet appareil ?')) forgetAccount();
    };

    $('#diagnosticButton').onclick = openDiagnostic;
    $('#closeDiagnostic').onclick = () => hide($('#diagnosticOverlay'), true);
    $('#diagnosticBackdrop').onclick = () => hide($('#diagnosticOverlay'), true);
    $('#copyDiagnostic').onclick = copyDiagnostic;
    $('#shareDiagnostic').onclick = shareDiagnostic;
    $('#exportDiagnostic').onclick = exportDiagnostic;
    $('#testNativePlayer').onclick = () => toast(state.nativeCaps.nativePlayer ? 'Lecteur Media3 détecté et prêt' : 'Lecteur Media3 absent de cet APK');
    $('#syncNowButton').onclick = syncNow;
    $('#clearHistoryButton').onclick = () => {
      if (confirm('Effacer tout l’historique et les positions de lecture ?')) clearHistory();
    };

    window.addEventListener('online', setNetworkBadge);
    window.addEventListener('offline', setNetworkBadge);
    window.addEventListener('androidtvkey', handleAndroidTvKey);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && state.settings.autoPip && state.currentMedia && !$('#playerOverlay').classList.contains('hidden')) requestPip();
    });
    document.addEventListener('keydown', event => {
      if (!$('#playerOverlay').classList.contains('hidden')) {
        if (event.key === 'ArrowUp' || event.key === 'PageUp') zap(-1);
        if (event.key === 'ArrowDown' || event.key === 'PageDown') zap(1);
      }
      if (/^[0-9]$/.test(event.key) && (state.currentPage === 'live' || state.currentMedia?.kind === 'live')) showNumericZap(event.key);
    });
  }

  async function bootstrap() {
    try {
      await PrimeDB.open();
      state.nativeCaps = PrimeNative.capabilities();
      renderNativeModuleGrid();
      setNetworkBadge();
      bindEvents();
      state.account = await loadAccount();
      const draft = await loadDraft();
      if (state.account) {
        fillForm(state.account);
        showSavedCard(state.account);
        await connect(state.account, { silent: true });
      } else {
        showLogin(draft);
        showSavedCard(null);
      }
      renderNativeModuleGrid();
    } catch (error) {
      showLogin(null, `Démarrage impossible : ${error?.message || error}`);
    }
  }

  setTimeout(() => {
    if (!$('#boot').classList.contains('hidden')) showLogin(state.account);
  }, 6000);

  bootstrap();
})();
