(function(){
  'use strict';
  const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
  const state={account:null,auth:null,client:null,catalog:{live:[],movies:[],series:[],liveCategories:[],movieCategories:[],seriesCategories:[]},settings:{liveFormat:'m3u8',nativeFirst:false,resume:true},favorites:[],history:[],positions:{},currentPage:'home',catalogType:'movies',activeCategory:'all',visible:60,selection:null,currentMedia:null,hls:null,playToken:0,toastTimer:null};
  const typeLabels={live:'Direct',movies:'Film',series:'Série'};
  const accountKey='account';

  function hide(el,value=true){el?.classList.toggle('hidden',value)}
  function toast(message){const el=$('#toast');el.textContent=message;hide(el,false);clearTimeout(state.toastTimer);state.toastTimer=setTimeout(()=>hide(el,true),2600);PrimeNative.toast(message)}
  function setMessage(message,error=true){const el=$('#loginMessage');el.textContent=message||'';el.style.color=error?'#ff9aa5':'#9ff0c8'}
  function normalizeAccount(raw){if(!raw)return null;return {name:String(raw.name||'Maison').trim()||'Maison',server:Xtream.normalizeServer(raw.server),username:String(raw.username||'').trim(),password:String(raw.password||'') ,savedAt:raw.savedAt||Date.now(),authSnapshot:raw.authSnapshot||null}}
  function validAccount(a){return !!(a?.server&&a?.username&&a?.password)}
  function maskServer(s){try{const u=new URL(s);return u.host}catch{return s}}
  function saveNativeAccount(account){try{PrimeNative.saveSecret('primeiptv.account',JSON.stringify(account))}catch{}}
  async function saveAccount(account){state.account=normalizeAccount(account);await PrimeDB.set(accountKey,state.account);try{localStorage.setItem('primeiptv-account-backup',JSON.stringify(state.account))}catch{}saveNativeAccount(state.account);return state.account}
  async function loadAccount(){
    try{const native=PrimeNative.loadSecret('primeiptv.account');if(native){const parsed=JSON.parse(native);if(validAccount(parsed))return normalizeAccount(parsed)}}catch{}
    const db=await PrimeDB.get(accountKey,null);if(validAccount(db))return normalizeAccount(db);
    try{const ls=JSON.parse(localStorage.getItem('primeiptv-account-backup')||'null');if(validAccount(ls))return normalizeAccount(ls)}catch{}
    return null;
  }
  async function forgetAccount(){await PrimeDB.del(accountKey);try{localStorage.removeItem('primeiptv-account-backup')}catch{}PrimeNative.saveSecret('primeiptv.account','');state.account=null;state.auth=null;state.client=null;showLogin(null);toast('Compte supprimé de cet appareil')}
  function formAccount(){return normalizeAccount({name:$('#profileName').value,server:$('#server').value,username:$('#username').value,password:$('#password').value})}
  function fillForm(account){if(!account)return;$('#profileName').value=account.name||'Maison';$('#server').value=account.server||'';$('#username').value=account.username||'';$('#password').value=account.password||''}
  async function saveDraft(){const a=formAccount();if(a.server||a.username||a.password){await PrimeDB.set('draftAccount',a);try{PrimeNative.saveSecret('primeiptv.draft',JSON.stringify(a))}catch{}}}
  function showSavedCard(account){hide($('#savedAccountCard'),!validAccount(account));if(account){$('#savedAccountName').textContent=account.name;$('#savedAccountServer').textContent=`${maskServer(account.server)} • ${account.username}`}}
  function showLogin(account,message=''){hide($('#boot'),true);hide($('#appView'),true);hide($('#loginView'),false);if(account)fillForm(account);showSavedCard(account);setMessage(message,!!message)}

  async function connect(account,{silent=false}={}){
    account=normalizeAccount(account);
    if(!validAccount(account)){showLogin(account,'Serveur, identifiant et mot de passe sont obligatoires.');return}
    const button=$('#connectButton');button.disabled=true;button.textContent='Connexion…';setMessage(silent?'Reconnexion automatique…':'Vérification du compte…',false);
    try{
      const client=new Xtream.XtreamClient(account);const auth=await client.authenticate();
      const saved={...account,savedAt:Date.now(),authSnapshot:auth};await saveAccount(saved);
      state.client=client;state.auth=auth;
      hide($('#loginView'),true);hide($('#appView'),false);hide($('#boot'),true);
      renderAccount();await loadLocalState();await loadCatalog();showPage('home');setMessage('');
    }catch(error){showLogin(account,(silent?'Reconnexion impossible : ':'Connexion impossible : ')+(error?.message||'erreur inconnue'))}
    finally{button.disabled=false;button.textContent='Se connecter'}
  }

  async function loadLocalState(){
    state.settings={...state.settings,...await PrimeDB.get('settings',{})};
    state.favorites=await PrimeDB.get('favorites',[]);state.history=await PrimeDB.get('history',[]);state.positions=await PrimeDB.get('positions',{});
    state.settings.nativeFirst=false;state.settings.autoPip=false;await PrimeDB.set('settings',state.settings);$('#liveFormat').value=state.settings.liveFormat||'m3u8';$('#nativeFirst').checked=false;$('#nativeFirst').disabled=true;$('#resumePlayback').checked=state.settings.resume!==false;if($('#autoPip')){$('#autoPip').checked=false;$('#autoPip').disabled=true}if($('#mobileQuality'))$('#mobileQuality').value=state.settings.mobileQuality||'auto';
  }
  async function loadCatalog(){
    const cache=await PrimeDB.get('catalog',null);if(cache?.account===state.account.username+'@'+state.account.server&&cache.data){state.catalog=cache.data;renderAll()}
    $('#refreshButton').classList.add('spinning');
    try{state.catalog=await state.client.loadCatalog();await PrimeDB.set('catalog',{account:state.account.username+'@'+state.account.server,at:Date.now(),data:state.catalog});renderAll();toast('Catalogue actualisé')}
    catch(error){if(!cache?.data)toast('Catalogue impossible à charger')}
    finally{$('#refreshButton').classList.remove('spinning')}
  }
  function renderAll(){renderCounts();renderHome();if(['live','movies','series','favorites'].includes(state.currentPage))renderCatalog()}
  function renderCounts(){
    $('#liveCount').textContent=`${state.catalog.live.length} chaîne${state.catalog.live.length>1?'s':''}`;
    $('#movieCount').textContent=`${state.catalog.movies.length} film${state.catalog.movies.length>1?'s':''}`;
    $('#seriesCount').textContent=`${state.catalog.series.length} série${state.catalog.series.length>1?'s':''}`;
    $('#favoriteCount').textContent=`${state.favorites.length} élément${state.favorites.length>1?'s':''}`;
  }
  function renderAccount(){
    const ui=state.auth?.user_info||state.account?.authSnapshot?.user_info||{};const exp=Xtream.expiryInfo(ui);const name=state.account?.name||'Profil';
    $('#accountLabel').textContent=name;$('#accountAvatar').textContent=name.slice(0,1).toUpperCase();$('#accountState').textContent=String(ui.status||'Connecté');$('#welcomeTitle').textContent=`Bonjour, ${name}`;
    $('#validityText').textContent=exp.date?`Valable jusqu’au ${exp.label}`:exp.label;$('#daysBadge').textContent=exp.days===null?'∞':exp.expired?'Expiré':`${Math.max(0,exp.days)} j`;
    $('#infoProfile').textContent=name;$('#infoServer').textContent=state.account?.server||'—';$('#infoUsername').textContent=state.account?.username||'—';$('#infoStatus').textContent=String(ui.status||'Actif');$('#infoExpiry').textContent=exp.label;$('#infoRemaining').textContent=exp.remaining;$('#infoConnections').textContent=`${ui.active_cons??0} / ${ui.max_connections??'—'}`;
  }
  function itemTitle(item,kind){return String(item?.name||item?.title||item?.channel_name||item?.epg_channel_id||`${typeLabels[kind]||'Contenu'}`)}
  function itemId(item,kind){return String(kind==='series'?(item.series_id??item.stream_id??item.id):(item.stream_id??item.id??item.series_id))}
  function itemImage(item){return String(item?.stream_icon||item?.cover||item?.movie_image||item?.backdrop_path?.[0]||item?.cover_big||'')}
  function itemCategory(item){return String(item?.category_id??'')}
  function itemAdded(item){return Number(item?.added||item?.last_modified||0)}
  function imageStyle(url){return url?`url("${String(url).replace(/["\\]/g,'')}")`:''}
  function posterCard(item,kind){
    const b=document.createElement('button');b.className='poster-card';b.dataset.kind=kind;b.dataset.id=itemId(item,kind);
    const poster=document.createElement('div');poster.className='poster';const img=itemImage(item);if(img)poster.style.backgroundImage=imageStyle(img);
    const title=document.createElement('strong');title.textContent=itemTitle(item,kind);const meta=document.createElement('small');meta.textContent=kind==='live'?'En direct':kind==='movies'?(item.releaseDate||item.year||item.rating?'Film':'Vidéo'):(item.releaseDate||item.year||'Série');
    b.append(poster,title,meta);return b;
  }
  function appendCards(container,entries){container.replaceChildren();entries.forEach(({item,kind})=>container.appendChild(posterCard(item,kind)))}
  function renderHome(){
    const recent=[...state.catalog.movies.map(item=>({item,kind:'movies'})),...state.catalog.series.map(item=>({item,kind:'series'}))].sort((a,b)=>itemAdded(b.item)-itemAdded(a.item)).slice(0,24);appendCards($('#recentRail'),recent);
    const hist=state.history.slice(0,20).map(h=>{const item=findItem(h.kind,h.id);return item?{item,kind:h.kind}:null}).filter(Boolean);hide($('#continueSection'),!hist.length);if(hist.length)appendCards($('#continueRail'),hist)
  }
  function findItem(kind,id){const list=kind==='live'?state.catalog.live:kind==='movies'?state.catalog.movies:state.catalog.series;return list.find(x=>itemId(x,kind)===String(id))}
  function categoriesFor(kind){return kind==='live'?state.catalog.liveCategories:kind==='movies'?state.catalog.movieCategories:state.catalog.seriesCategories}
  function itemsFor(kind){if(kind==='favorites')return state.favorites.map(f=>{const item=findItem(f.kind,f.id);return item?{item,kind:f.kind}:null}).filter(Boolean);return (kind==='live'?state.catalog.live:kind==='movies'?state.catalog.movies:state.catalog.series).map(item=>({item,kind}))}
  function renderCatalog(){
    const kind=state.catalogType;const all=itemsFor(kind);const filtered=state.activeCategory==='all'||kind==='favorites'?all:all.filter(x=>itemCategory(x.item)===state.activeCategory);const shown=filtered.slice(0,state.visible);
    const grid=$('#catalogGrid');grid.replaceChildren();shown.forEach(x=>grid.appendChild(posterCard(x.item,x.kind)));$('#catalogMeta').textContent=`${filtered.length} contenu${filtered.length>1?'s':''}`;hide($('#loadMoreButton'),shown.length>=filtered.length);
  }
  function renderCategories(kind){const bar=$('#categoryBar');bar.replaceChildren();if(kind==='favorites'){hide(bar,true);return}hide(bar,false);const all=document.createElement('button');all.className='category-chip active';all.dataset.category='all';all.textContent='Tout';bar.appendChild(all);categoriesFor(kind).forEach(c=>{const b=document.createElement('button');b.className='category-chip';b.dataset.category=String(c.category_id);b.textContent=String(c.category_name||'Catégorie');bar.appendChild(b)})}
  function showPage(page){
    if(['live','movies','series','favorites'].includes(page)){state.catalogType=page;state.activeCategory='all';state.visible=60;$('#catalogTitle').textContent=page==='live'?'Direct':page==='movies'?'Films':page==='series'?'Séries':'Favoris';$('#catalogEyebrow').textContent=page==='favorites'?'MA LISTE':'CATALOGUE';renderCategories(page);renderCatalog();page='catalog'}
    $$('.page').forEach(p=>p.classList.remove('active'));const target=page==='home'?$('#homePage'):page==='settings'?$('#settingsPage'):$('#catalogPage');target.classList.add('active');state.currentPage=page==='catalog'?state.catalogType:page;
    $$('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===state.currentPage||(state.currentPage==='favorites'&&false)));window.scrollTo(0,0)
  }
  async function openDetail(kind,item){
    state.selection={kind,item,info:null,episode:null};$('#detailType').textContent=typeLabels[kind]?.toUpperCase()||'CONTENU';$('#detailTitle').textContent=itemTitle(item,kind);$('#detailMeta').textContent=[item.year||item.releaseDate,item.rating?`★ ${item.rating}`:'',item.genre||''].filter(Boolean).join(' • ');$('#detailDescription').textContent=item.plot||item.description||'Informations non communiquées par le serveur.';const image=item.backdrop_path?.[0]||itemImage(item);$('#detailBackdropImage').style.backgroundImage=imageStyle(image);hide($('#seriesPicker'),kind!=='series');setFavoriteButton();hide($('#detailOverlay'),false);
    if(kind==='movies'){
      try{const info=await state.client.getVodInfo(item.stream_id);state.selection.info=info;const data=info.info||{};$('#detailDescription').textContent=data.plot||data.description||$('#detailDescription').textContent;$('#detailMeta').textContent=[data.releasedate||data.releaseDate||item.year,data.duration||formatDuration(data.duration_secs),data.rating?`★ ${data.rating}`:'',data.genre].filter(Boolean).join(' • ')}catch{}
    }
    if(kind==='series')await loadSeriesDetails(item);
  }
  async function loadSeriesDetails(item){
    const box=$('#episodeList');box.innerHTML='<p class="muted">Chargement des épisodes…</p>';
    try{const info=await state.client.getSeriesInfo(item.series_id);state.selection.info=info;const data=info.info||{};$('#detailDescription').textContent=data.plot||data.description||$('#detailDescription').textContent;$('#detailMeta').textContent=[data.releaseDate||data.year,data.rating?`★ ${data.rating}`:'',data.genre].filter(Boolean).join(' • ');const seasons=Object.keys(info.episodes||{}).sort((a,b)=>Number(a)-Number(b));const select=$('#seasonSelect');select.replaceChildren();seasons.forEach(s=>{const o=document.createElement('option');o.value=s;o.textContent=`Saison ${s}`;select.appendChild(o)});renderEpisodes(seasons[0]);select.onchange=()=>renderEpisodes(select.value)}catch(error){box.innerHTML='<p class="muted">Épisodes indisponibles.</p>'}
  }
  function renderEpisodes(season){const episodes=state.selection?.info?.episodes?.[season]||[];const box=$('#episodeList');box.replaceChildren();episodes.forEach((ep,index)=>{const b=document.createElement('button');b.className='episode-item';b.dataset.episode=String(index);const n=document.createElement('span');n.className='episode-number';n.textContent=String(ep.episode_num||index+1);const d=document.createElement('div');const title=document.createElement('strong');title.textContent=ep.title||`Épisode ${ep.episode_num||index+1}`;const meta=document.createElement('small');meta.textContent=[ep.info?.duration,ep.container_extension?.toUpperCase()].filter(Boolean).join(' • ');d.append(title,meta);b.append(n,d);box.appendChild(b)});box.dataset.season=season}
  function closeDetail(){hide($('#detailOverlay'),true);state.selection=null}
  function favoriteRef(){const s=state.selection;return s?{kind:s.kind,id:itemId(s.item,s.kind)}:null}
  function isFavorite(ref){return !!ref&&state.favorites.some(f=>f.kind===ref.kind&&f.id===ref.id)}
  function setFavoriteButton(){const active=isFavorite(favoriteRef());$('#favoriteButton').textContent=active?'♥ Favori':'♡ Favori'}
  async function toggleFavorite(){const ref=favoriteRef();if(!ref)return;const index=state.favorites.findIndex(f=>f.kind===ref.kind&&f.id===ref.id);if(index>=0)state.favorites.splice(index,1);else state.favorites.unshift(ref);await PrimeDB.set('favorites',state.favorites);setFavoriteButton();renderCounts();toast(index>=0?'Retiré des favoris':'Ajouté aux favoris')}
  function formatDuration(seconds){const n=Number(seconds);if(!Number.isFinite(n))return '';const h=Math.floor(n/3600),m=Math.floor(n%3600/60);return h?`${h} h ${m} min`:`${m} min`}
  function mimeFor(url){const x=String(url).toLowerCase();if(x.includes('.m3u8'))return'application/x-mpegURL';if(x.includes('.mpd'))return'application/dash+xml';if(x.includes('.mp4'))return'video/mp4';if(x.includes('.ts'))return'video/mp2t';if(x.includes('.webm'))return'video/webm';return'application/octet-stream'}
  function mediaFromSelection(episode=null){
    const s=state.selection;if(!s)return null;let candidates=[];let title=itemTitle(s.item,s.kind);if(s.kind==='live')candidates=state.client.liveCandidates(s.item,state.settings.liveFormat);else if(s.kind==='movies')candidates=state.client.movieCandidates(s.item,s.info||{});else{if(!episode)return null;candidates=state.client.episodeCandidates(episode);title=episode.title||title}
    return {kind:s.kind,id:itemId(s.item,s.kind),episodeId:episode?.id?String(episode.id):'',title,poster:itemImage(s.item),candidates,type:s.kind==='live'?'live':'video'}
  }
  async function rememberHistory(media){const key=`${media.kind}:${media.id}:${media.episodeId||''}`;state.history=state.history.filter(x=>`${x.kind}:${x.id}:${x.episodeId||''}`!==key);state.history.unshift({kind:media.kind,id:media.id,episodeId:media.episodeId||'',title:media.title,at:Date.now()});state.history=state.history.slice(0,60);await PrimeDB.set('history',state.history);renderHome()}
  function firstSeriesEpisode(){
    const episodes=state.selection?.info?.episodes||{};
    const seasons=Object.keys(episodes).sort((a,b)=>Number(a)-Number(b));
    for(const season of seasons){
      const list=Array.isArray(episodes[season])?episodes[season]:[];
      if(list.length)return list[0];
    }
    return null;
  }
  function orderedCandidates(media){
    const list=[...(media?.candidates||[])].filter(Boolean);
    const score=url=>{const x=String(url).toLowerCase();if(x.includes('.m3u8'))return 0;if(x.includes('.mp4'))return 1;if(x.includes('.ts'))return 2;if(x.includes('.webm'))return 3;if(x.includes('.mkv'))return 5;return 4};
    return [...new Set(list)].sort((a,b)=>score(a)-score(b));
  }
  async function startPlayback(episode=null){
    if(state.selection?.kind==='series'&&!episode)episode=firstSeriesEpisode();
    const media=mediaFromSelection(episode);
    if(!media?.candidates?.length){toast(state.selection?.kind==='series'?'Aucun épisode exploitable trouvé':'Le serveur n’a fourni aucun flux lisible');return}
    media.candidates=orderedCandidates(media);
    state.currentMedia=media;
    await rememberHistory(media);
    closeDetail();
    openWebPlayer(media);
  }
  function openWebPlayer(media){hide($('#playerOverlay'),false);$('#playerTitle').textContent=media.title;$('#playerSubtitle').textContent=(typeLabels[media.kind]||'Lecture')+' • lecteur Web stable';$('#playerErrorText').textContent='';hide($('#playerError'),true);state.playToken++;tryCandidate(0,state.playToken)}
  function destroyHls(){try{state.hls?.destroy()}catch{}state.hls=null}
  function resetVideo(){const v=$('#videoPlayer');try{v.pause()}catch{};v.removeAttribute('src');v.load()}
  function tryCandidate(index,token){
    if(token!==state.playToken)return;
    const media=state.currentMedia;if(!media)return;
    if(index>=media.candidates.length){showPlayerError('Aucun flux compatible avec le lecteur Web. Essaie le lecteur externe depuis le menu ⋮.');return}
    const url=media.candidates[index],v=$('#videoPlayer');destroyHls();resetVideo();hide($('#playerLoading'),false);hide($('#playerError'),true);let settled=false,hlsTried=false;
    const cleanup=()=>{v.oncanplay=v.onloadedmetadata=v.onerror=null};
    const success=()=>{if(settled||token!==state.playToken)return;settled=true;cleanup();hide($('#playerLoading'),true);const key=mediaKey(media);const resume=state.settings.resume?Number(state.positions[key]||0):0;if(resume>8&&Number.isFinite(resume))try{v.currentTime=resume}catch{};v.play().catch(()=>toast('Appuie sur ▶ pour démarrer la lecture'))};
    const next=()=>{if(settled||token!==state.playToken)return;settled=true;cleanup();setTimeout(()=>tryCandidate(index+1,token),150)};
    const tryHlsJs=()=>{if(hlsTried||settled||token!==state.playToken)return;hlsTried=true;resetVideo();if(!window.Hls?.isSupported?.()){next();return}try{const hls=new Hls({enableWorker:true,lowLatencyMode:media.kind==='live',backBufferLength:60,maxBufferLength:40,fragLoadingTimeOut:20000,manifestLoadingTimeOut:20000,levelLoadingTimeOut:20000});state.hls=hls;hls.attachMedia(v);hls.on(Hls.Events.MEDIA_ATTACHED,()=>hls.loadSource(url));hls.on(Hls.Events.MANIFEST_PARSED,success);hls.on(Hls.Events.ERROR,(_,data)=>{if(data?.fatal)next()})}catch{next()}};
    const isHls=/\.m3u8(?:$|\?)/i.test(url);
    v.oncanplay=success;v.onloadedmetadata=success;v.onerror=()=>{if(isHls&&!hlsTried){tryHlsJs()}else next()};
    // Essai direct en premier : il évite les problèmes CORS de hls.js sur certains fournisseurs.
    v.src=url;v.load();
    setTimeout(()=>{if(settled)return;if(v.readyState>0){success();return}if(isHls&&!hlsTried)tryHlsJs();else next()},18000);
  }
  function showPlayerError(message){hide($('#playerLoading'),true);$('#playerErrorText').textContent=message;hide($('#playerError'),false)}
  function mediaKey(m){return `${m.kind}:${m.id}:${m.episodeId||''}`}
  async function savePosition(){const m=state.currentMedia,v=$('#videoPlayer');if(!m||m.kind==='live'||!Number.isFinite(v.currentTime))return;state.positions[mediaKey(m)]=Math.floor(v.currentTime);await PrimeDB.set('positions',state.positions)}
  function closePlayer(){savePosition();state.playToken++;destroyHls();resetVideo();hide($('#playerOverlay'),true);state.currentMedia=null}
  async function castCurrent(){
    let media=state.currentMedia;
    if(!media&&state.selection){let ep=state.selection.episode;if(state.selection.kind==='series'&&!ep)ep=firstSeriesEpisode();media=mediaFromSelection(ep)}
    if(!media?.candidates?.length){toast('Choisissez d’abord un film, un épisode ou une chaîne');return}
    const candidates=orderedCandidates(media).filter(url=>!/\.mkv(?:$|\?)/i.test(url));
    if(!candidates.length){toast('Ce contenu est uniquement disponible en MKV, format rarement compatible avec Chromecast');return}
    const url=candidates[0];
    const payload={url,candidates,title:media.title,poster:media.poster,mime:mimeFor(url),type:media.type};
    if(PrimeNative.cast(payload)){toast('Choisis ton téléviseur : le flux sera envoyé après la connexion');return}
    const video=$('#videoPlayer');
    try{if(video.remote?.prompt){await video.remote.prompt();return}}catch{}
    toast('Le module Google Cast doit être activé dans HTMLtoAPK Stable Cast');
  }
  function openSearch(){hide($('#searchOverlay'),false);$('#searchInput').value='';$('#searchResults').replaceChildren();setTimeout(()=>$('#searchInput').focus(),100)}
  function doSearch(query){const q=String(query).trim().toLowerCase();const box=$('#searchResults');box.replaceChildren();if(q.length<2)return;const all=[...itemsFor('live'),...itemsFor('movies'),...itemsFor('series')].filter(x=>itemTitle(x.item,x.kind).toLowerCase().includes(q)).slice(0,120);all.forEach(x=>box.appendChild(posterCard(x.item,x.kind)))}
  function delegatedCard(event){const card=event.target.closest('[data-kind][data-id]');if(!card)return;const item=findItem(card.dataset.kind,card.dataset.id);if(item)openDetail(card.dataset.kind,item)}

  $('#loginForm').addEventListener('submit',e=>{e.preventDefault();connect(formAccount())});
  ['profileName','server','username','password'].forEach(id=>$('#'+id).addEventListener('input',()=>{clearTimeout(window.__draftTimer);window.__draftTimer=setTimeout(saveDraft,350)}));
  $('#togglePassword').onclick=()=>{const p=$('#password');p.type=p.type==='password'?'text':'password';$('#togglePassword').textContent=p.type==='password'?'Afficher':'Masquer'};
  $('#quickConnectButton').onclick=()=>state.account&&connect(state.account);
  $$('.quick-card,.bottom-nav button').forEach(b=>b.onclick=()=>showPage(b.dataset.page));
  $('#catalogBack').onclick=$('#settingsBack').onclick=()=>showPage('home');$('#accountButton').onclick=()=>showPage('settings');
  $('#refreshButton').onclick=()=>loadCatalog();$('#searchButton').onclick=$('#catalogSearch').onclick=openSearch;$('#closeSearch').onclick=()=>hide($('#searchOverlay'),true);$('#searchInput').oninput=e=>doSearch(e.target.value);
  $('#recentRail').onclick=$('#continueRail').onclick=$('#catalogGrid').onclick=$('#searchResults').onclick=delegatedCard;
  $('#categoryBar').onclick=e=>{const b=e.target.closest('[data-category]');if(!b)return;state.activeCategory=b.dataset.category;state.visible=60;$$('.category-chip').forEach(x=>x.classList.toggle('active',x===b));renderCatalog()};
  $('#loadMoreButton').onclick=()=>{state.visible+=60;renderCatalog()};
  $('#detailBackdrop').onclick=$('#closeDetail').onclick=closeDetail;$('#favoriteButton').onclick=toggleFavorite;$('#playButton').onclick=()=>startPlayback();$('#castButton').onclick=castCurrent;
  $('#episodeList').onclick=e=>{const b=e.target.closest('[data-episode]');if(!b)return;const season=$('#episodeList').dataset.season;const ep=state.selection?.info?.episodes?.[season]?.[Number(b.dataset.episode)];if(ep){state.selection.episode=ep;startPlayback(ep)}};
  $('#closePlayer').onclick=closePlayer;$('#retryPlayer').onclick=()=>state.currentMedia&&tryCandidate(0,++state.playToken);$('#openNativePlayer').onclick=()=>{const m=state.currentMedia;if(m&&PrimeNative.play({url:m.candidates[0],title:m.title,type:m.type,poster:m.poster}))toast('Ouverture du lecteur Android…');else toast('Lecteur Android indisponible')};
  $('#topCastButton').onclick=$('#playerCastButton').onclick=castCurrent;
  $('#videoPlayer').addEventListener('timeupdate',()=>{const v=$('#videoPlayer');if(Math.floor(v.currentTime)%8===0)savePosition()});$('#videoPlayer').addEventListener('ended',savePosition);
  $('#liveFormat').onchange=async e=>{state.settings.liveFormat=e.target.value;await PrimeDB.set('settings',state.settings)};$('#nativeFirst').onchange=()=>{state.settings.nativeFirst=false;$('#nativeFirst').checked=false;toast('Le lecteur Web stable reste prioritaire')};$('#resumePlayback').onchange=async e=>{state.settings.resume=e.target.checked;await PrimeDB.set('settings',state.settings)};
  $('#changeAccountButton').onclick=()=>showLogin(state.account);$('#forgetAccountButton').onclick=()=>{if(confirm('Supprimer définitivement les identifiants enregistrés sur cet appareil ?'))forgetAccount()};

  async function bootstrap(){
    try{await PrimeDB.open();state.account=await loadAccount();const draft=await PrimeDB.get('draftAccount',null);if(state.account){fillForm(state.account);showSavedCard(state.account);await connect(state.account,{silent:true})}else{showLogin(draft);showSavedCard(null)}}catch(error){showLogin(null,'Démarrage impossible : '+(error?.message||error))}
  }
  setTimeout(()=>{if(!$('#boot').classList.contains('hidden'))showLogin(state.account)},5000);
  bootstrap();


  // ----- V2 : priorités lecture, PiP, diagnostic, zapping -----
  function capabilityReport(){
    const c=PrimeNative.capabilities();
    const rows=[['Pont Android',c.bridge],['Media3 / lecteur natif',c.nativePlayer],['Google Cast',c.cast],['Picture-in-Picture',c.pip],['MediaSession',c.mediaSession],['Lecteur externe',c.externalPlayer],['Stockage sécurisé',c.secureStorage],['Android TV',c.androidTv],['Room',c.room],['WorkManager',c.workManager],['Notifications',c.notifications]];
    return {capabilities:c,rows,text:rows.map(([n,v])=>`${v?'✅':'❌'} ${n}`).join('\n')};
  }
  function refreshCapabilitySummary(){const r=capabilityReport();const ok=r.rows.filter(x=>x[1]).length;const el=$('#capabilitySummary');if(el)el.textContent=`${ok}/${r.rows.length} capacités détectées sur cet APK.`}
  function buildDiagnostic(){
    const r=capabilityReport(); const a=state.account;
    return [`Prime IPTV Player V2 — Diagnostic`, `Date : ${new Date().toLocaleString('fr-FR')}`, `Réseau : ${navigator.onLine?'connecté':'hors connexion'}`, `Navigateur : ${navigator.userAgent}`, `Serveur : ${a?maskServer(a.server):'non connecté'}`, `Compte : ${a?.username||'non connecté'}`, `Catalogue : ${state.catalog.live.length} chaînes / ${state.catalog.movies.length} films / ${state.catalog.series.length} séries`, '', r.text, '', `Format direct : ${state.settings.liveFormat}`, `Lecteur Android prioritaire : ${state.settings.nativeFirst?'oui':'non'}`, `Reprise : ${state.settings.resume?'oui':'non'}`].join('\n');
  }
  function openDiagnostic(){const out=$('#diagnosticOutput');if(out)out.textContent=buildDiagnostic();hide($('#diagnosticOverlay'),false)}
  async function requestPip(){const v=$('#videoPlayer');try{if(PrimeNative.enterPip()){toast('Mode Picture-in-Picture Android');return}if(document.pictureInPictureEnabled&&v&&!v.disablePictureInPicture){await v.requestPictureInPicture();return}toast('Picture-in-Picture indisponible dans cet APK')}catch(e){toast('Impossible d’activer le Picture-in-Picture')}}
  function openExternalCurrent(){const m=state.currentMedia;if(!m?.candidates?.length){toast('Aucun flux en cours');return}if(PrimeNative.external({url:m.candidates[0],mime:mimeFor(m.candidates[0]),title:m.title})){toast('Ouverture du lecteur externe…');return}toast('Module lecteur externe absent de HTMLtoAPK')}
  function zap(delta){if(state.currentMedia?.kind!=='live')return;const list=state.catalog.live;const idx=list.findIndex(x=>itemId(x,'live')===String(state.currentMedia.id));if(idx<0||!list.length)return;const next=list[(idx+delta+list.length)%list.length];state.selection={kind:'live',item:next};startPlayback()}
  function setNetworkBadge(){let b=$('#networkBadge');if(!navigator.onLine){if(!b){b=document.createElement('div');b.id='networkBadge';b.className='network-badge';document.body.appendChild(b)}b.textContent='Connexion Internet indisponible'}else b?.remove()}
  window.addEventListener('online',setNetworkBadge);window.addEventListener('offline',setNetworkBadge);setNetworkBadge();
  $('#diagnosticButton')?.addEventListener('click',openDiagnostic);$('#closeDiagnostic')?.addEventListener('click',()=>hide($('#diagnosticOverlay'),true));$('#diagnosticBackdrop')?.addEventListener('click',()=>hide($('#diagnosticOverlay'),true));
  $('#copyDiagnostic')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(buildDiagnostic());toast('Diagnostic copié')}catch{toast('Copie impossible')}});
  $('#testNativePlayer')?.addEventListener('click',()=>toast(PrimeNative.nativePlayerAvailable()?'Lecteur Media3 détecté':'Lecteur Media3 non généré dans cet APK'));
  $('#playerPipButton')?.addEventListener('click',requestPip);$('#playerExternalButton')?.addEventListener('click',openExternalCurrent);
  $('#autoPip')?.addEventListener('change',()=>{$('#autoPip').checked=false;state.settings.autoPip=false});
  $('#mobileQuality')?.addEventListener('change',async e=>{state.settings.mobileQuality=e.target.value;await PrimeDB.set('settings',state.settings)});
  document.addEventListener('keydown',e=>{if($('#playerOverlay')?.classList.contains('hidden'))return;if(e.key==='ArrowUp'||e.key==='PageUp')zap(-1);if(e.key==='ArrowDown'||e.key==='PageDown')zap(1)});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&state.settings.autoPip&&state.currentMedia&&!$('#playerOverlay')?.classList.contains('hidden'))requestPip()});
  setTimeout(refreshCapabilitySummary,600);
})();
