(function(){
  'use strict';
  const api=()=>window.AndroidApp||null;
  const call=(name,...args)=>{try{const a=api();return a&&typeof a[name]==='function'?a[name](...args):undefined}catch(e){console.warn(name,e);return undefined}};
  const parse=(v,f={})=>{try{return typeof v==='string'?JSON.parse(v):v||f}catch{return f}};
  function capabilities(){return parse(call('getNativeCapabilities'),{});}
  function nativePlayerAvailable(){return typeof api()?.openNativePlayerV4==='function'||typeof api()?.openNativePlayer==='function';}
  function play(p={}){
    const candidates=Array.isArray(p.candidates)?p.candidates:[p.url].filter(Boolean);
    if(!candidates.length)return false;
    if(typeof api()?.openNativePlayerV4==='function')return call('openNativePlayerV4',JSON.stringify(candidates),String(p.title||'Lecture'),String(p.poster||''),JSON.stringify(p.headers||{}),Number(p.startPositionMs||0),p.autoplay!==false)===true;
    if(typeof api()?.openNativePlayer==='function')return call('openNativePlayer',candidates[0],String(p.title||'Lecture'),String(p.poster||''),JSON.stringify(p.headers||{}),Number(p.startPositionMs||0),p.autoplay!==false)===true;
    return false;
  }
  function cast(p={}){
    const candidates=Array.isArray(p.candidates)?p.candidates:[p.url].filter(Boolean);
    if(!candidates.length)return false;
    if(typeof api()?.castMediaV4==='function')return call('castMediaV4',JSON.stringify(candidates),String(p.title||'Diffusion'),String(p.poster||''),JSON.stringify(p.headers||{}),Number(p.startPositionMs||0))===true;
    if(typeof api()?.openNativePlayerForCast==='function')return call('openNativePlayerForCast',candidates[0],String(p.title||'Diffusion'),String(p.poster||''),JSON.stringify(p.headers||{}),Number(p.startPositionMs||0),true)===true;
    return false;
  }
  function saveSecret(k,v){return call('secureSet',String(k),String(v??''))===true||call('saveSecret',String(k),String(v??''))===true}
  function loadSecret(k){return String(call('secureGet',String(k),'')??call('loadSecret',String(k))??'')}
  function toast(m){call('showToast',String(m));}
  window.PrimeNative={available:()=>!!api(),capabilities,nativePlayerAvailable,saveSecret,loadSecret,play,cast,toast};
})();
