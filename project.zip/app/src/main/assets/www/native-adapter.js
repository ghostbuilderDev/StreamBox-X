(function(){
  const parse=value=>{try{return typeof value==='string'?JSON.parse(value):value}catch{return value}};
  const android=()=>window.AndroidApp||null;
  const call=(name,...args)=>{try{const a=android();if(a&&typeof a[name]==='function')return a[name](...args)}catch{}return null};
  function capabilities(){
    let native={};
    try{native=parse(call('getIptvCapabilities'))||{}}catch{}
    return {
      bridge:!!android(), nativePlayer:!!(native.nativePlayer||call('supportsNativeIptv')||window.NativeAndroidPlayer?.play),
      cast:!!(native.cast||window.NativeAndroidCast?.cast||window.NativeAndroidCast?.requestSession),
      pip:!!(native.pip||typeof document.pictureInPictureEnabled==='boolean'), mediaSession:!!(native.mediaSession||navigator.mediaSession),
      externalPlayer:!!(native.externalPlayer||call('supportsExternalPlayer')), secureStorage:!!(native.secureStorage||android()?.saveSecret),
      androidTv:!!native.androidTv, room:!!native.room, workManager:!!native.workManager, notifications:!!native.notifications,
      raw:native
    };
  }
  function saveSecret(k,v){return call('saveSecret',String(k),String(v??''))!==null}
  function loadSecret(k){return String(call('loadSecret',String(k))||'')}
  function play(p={}){if(call('playNative',String(p.url),String(p.title||'Lecture'),String(p.type||'video'),String(p.poster||''))!==null)return true;if(window.NativeAndroidPlayer?.play){window.NativeAndroidPlayer.play(JSON.stringify(p));return true}return false}
  function cast(p={}){const list=JSON.stringify(p.candidates||[p.url].filter(Boolean));if(call('castNativeCandidates',list,String(p.title||'Diffusion'),String(p.poster||''),String(p.type||'video'))!==null)return true;if(call('castNative',String(p.url),String(p.title||'Diffusion'),String(p.mime||'application/x-mpegURL'),String(p.poster||''))!==null)return true;if(window.NativeAndroidCast?.cast){window.NativeAndroidCast.cast(JSON.stringify(p));return true}if(window.NativeAndroidCast?.requestSession){window.NativeAndroidCast.requestSession(JSON.stringify(p));return true}return false}
  function external(p={}){if(call('openExternalPlayer',String(p.url),String(p.mime||''),String(p.title||'Lecture'))!==null)return true;return false}
  function enterPip(){return call('enterPictureInPicture')!==null}
  function toast(m){if(call('showToast',String(m))===null)console.log(m)}
  window.PrimeNative={available:()=>!!android(),nativePlayerAvailable:()=>capabilities().nativePlayer,capabilities,saveSecret,loadSecret,play,cast,external,enterPip,toast};
})();