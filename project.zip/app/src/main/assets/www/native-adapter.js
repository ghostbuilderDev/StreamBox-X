(function () {
  'use strict';

  const bridge = () => (typeof window.AndroidApp === 'object' ? window.AndroidApp : null);
  const parseJson = (value, fallback) => {
    try {
      if (value === null || value === undefined || value === '') return fallback;
      return typeof value === 'string' ? JSON.parse(value) : value;
    } catch (_) {
      return fallback;
    }
  };

  function has(name) {
    const api = bridge();
    return !!(api && typeof api[name] === 'function');
  }

  function call(name, ...args) {
    try {
      const api = bridge();
      if (!api || typeof api[name] !== 'function') return undefined;
      return api[name](...args);
    } catch (error) {
      console.warn('[PrimeNative]', name, error);
      return undefined;
    }
  }

  function capabilities() {
    const raw = parseJson(call('getNativeCapabilities'), {}) || {};
    const native = !!bridge();
    return {
      bridge: native,
      native,
      nativePlayer: !!raw.media3 && has('openNativePlayer'),
      media3: !!raw.media3,
      mediaSession: !!raw.mediaSession,
      cast: !!raw.cast,
      pip: !!raw.pip && has('enterPictureInPicture'),
      externalPlayer: has('openExternalPlayer'),
      secureStorage: !!raw.secureStore && has('secureSet') && has('secureGet'),
      room: !!raw.room && has('saveFavorite') && has('saveHistory'),
      workManager: !!raw.workManager && has('schedulePeriodicSync'),
      notifications: !!raw.notifications && has('showLocalNotification'),
      androidTv: !!raw.androidTv,
      diagnostics: !!raw.diagnostics && has('getNetworkDiagnostics'),
      files: !!raw.files,
      sdk: Number(raw.sdk || 0),
      television: !!call('isTelevision'),
      raw
    };
  }

  function play(payload = {}) {
    if (!has('openNativePlayer') || !payload.url) return false;
    const result = call(
      'openNativePlayer',
      String(payload.url),
      String(payload.title || 'Lecture'),
      String(payload.poster || ''),
      JSON.stringify(payload.headers || {}),
      Number.isFinite(Number(payload.startPositionMs)) ? Number(payload.startPositionMs) : -1,
      payload.autoplay !== false
    );
    return result === true;
  }

  // La V16.3 ouvre toujours le lecteur local en premier. Le transfert Cast
  // passe par le sélecteur de sortie de la notification MediaSession Android.
  function cast(payload = {}) {
    const caps = capabilities();
    if (!caps.cast || !caps.nativePlayer || !payload.url) return false;
    if (has('openNativePlayerForCast')) {
      return call(
        'openNativePlayerForCast',
        String(payload.url),
        String(payload.title || 'Lecture'),
        String(payload.poster || ''),
        JSON.stringify(payload.headers || {}),
        Number.isFinite(Number(payload.startPositionMs)) ? Number(payload.startPositionMs) : -1,
        payload.autoplay !== false
      ) === true;
    }
    return play(payload);
  }

  function castLegacy(payload = {}) {
    const p = payload || {};
    if (!p.url) return false;
    try {
      const api = bridge();
      if (api && typeof api.castNative === 'function') {
        const result = api.castNative(String(p.url), String(p.title || 'Diffusion'), String(p.mime || 'application/x-mpegURL'), String(p.poster || ''));
        return result !== false;
      }
      if (window.NativeAndroidCast && typeof window.NativeAndroidCast.cast === 'function') {
        window.NativeAndroidCast.cast(JSON.stringify(p));
        return true;
      }
      if (window.NativeAndroidCast && typeof window.NativeAndroidCast.requestSession === 'function') {
        window.NativeAndroidCast.requestSession(JSON.stringify(p));
        return true;
      }
    } catch (error) {
      console.warn('[PrimeNative] castLegacy', error);
    }
    return false;
  }

  function external(payload = {}) {
    if (!payload.url || !has('openExternalPlayer')) return false;
    return call('openExternalPlayer', String(payload.url), String(payload.title || 'Lecture')) === true;
  }

  function enterPip() {
    return has('enterPictureInPicture') && call('enterPictureInPicture') === true;
  }

  function secureSet(name, value) {
    return has('secureSet') && call('secureSet', String(name), String(value ?? '')) === true;
  }

  function secureGet(name, fallback = '') {
    const value = call('secureGet', String(name), String(fallback));
    return value === undefined || value === null ? String(fallback) : String(value);
  }

  function secureRemove(name) {
    return has('secureRemove') && call('secureRemove', String(name)) === true;
  }

  const favorites = {
    save(type, id, payload) {
      return has('saveFavorite') && call('saveFavorite', String(type), String(id), JSON.stringify(payload || {})) === true;
    },
    remove(type, id) {
      return has('removeFavorite') && call('removeFavorite', String(type), String(id)) === true;
    },
    list(type = '') {
      return parseJson(call('getFavorites', String(type)), []) || [];
    }
  };

  const history = {
    save(id, payload, positionMs = 0, durationMs = 0, completed = false) {
      return has('saveHistory') && call(
        'saveHistory',
        String(id),
        JSON.stringify(payload || {}),
        Math.max(0, Number(positionMs) || 0),
        Math.max(0, Number(durationMs) || 0),
        !!completed
      ) === true;
    },
    list(limit = 100) {
      return parseJson(call('getHistory', Math.max(1, Math.min(1000, Number(limit) || 100))), []) || [];
    },
    remove(id) {
      return has('deleteHistory') && call('deleteHistory', String(id)) === true;
    },
    clear() {
      return has('clearHistory') && call('clearHistory') === true;
    }
  };

  const sync = {
    schedule(name, url, minutes = 360) {
      return has('schedulePeriodicSync') && call(
        'schedulePeriodicSync',
        String(name),
        String(url),
        Math.max(15, Number(minutes) || 360)
      ) === true;
    },
    now(name, url) {
      return has('syncNow') && call('syncNow', String(name), String(url)) === true;
    },
    read(name) {
      const value = call('readSyncCache', String(name));
      return value === undefined || value === null ? '' : String(value);
    },
    cancel(name) {
      return has('cancelSync') && call('cancelSync', String(name)) === true;
    }
  };

  function diagnostics() {
    return parseJson(call('getNetworkDiagnostics'), capabilities()) || capabilities();
  }


  function bytesToBase64(bytes) {
    let binary = '';
    const chunk = 0x8000;
    for (let offset = 0; offset < bytes.length; offset += chunk) {
      binary += String.fromCharCode(...bytes.subarray(offset, Math.min(bytes.length, offset + chunk)));
    }
    return btoa(binary);
  }

  function downloadText(filename, text, mimeType = 'text/plain') {
    if (!has('beginFileDownload') || !has('appendFileChunk') || !has('finishFileDownload')) return false;
    const session = call('beginFileDownload', String(filename || 'prime-iptv.txt'), String(mimeType));
    if (!session) return false;
    try {
      const payload = bytesToBase64(new TextEncoder().encode(String(text || '')));
      if (call('appendFileChunk', String(session), payload) !== true) {
        call('cancelFileDownload', String(session));
        return false;
      }
      return call('finishFileDownload', String(session)) === true;
    } catch (error) {
      call('cancelFileDownload', String(session));
      return false;
    }
  }

  function notify(id, title, message) {
    return has('showLocalNotification') && call(
      'showLocalNotification',
      Number(id) || 3000,
      String(title || 'Prime IPTV'),
      String(message || '')
    ) === true;
  }

  function toast(message) {
    const result = call('showToast', String(message));
    if (result === undefined) console.log('[Prime IPTV]', message);
  }

  function share(text) {
    return call('share', String(text)) !== undefined;
  }

  function copyText(text) {
    return call('copyText', String(text)) !== undefined;
  }

  function vibrate(milliseconds = 50) {
    return call('vibrate', Math.max(0, Number(milliseconds) || 0)) !== undefined;
  }

  window.PrimeNative = Object.freeze({
    available: () => !!bridge(),
    has,
    capabilities,
    nativePlayerAvailable: () => capabilities().nativePlayer,
    play,
    cast,
    castLegacy,
    external,
    enterPip,
    secureSet,
    secureGet,
    secureRemove,
    favorites,
    history,
    sync,
    diagnostics,
    notify,
    downloadText,
    toast,
    share,
    copyText,
    vibrate
  });
})();
