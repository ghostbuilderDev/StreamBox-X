(function () {
  'use strict';

  const api = () => window.AndroidApp || null;

  function call(name, ...args) {
    try {
      const bridge = api();
      return bridge && typeof bridge[name] === 'function'
        ? bridge[name](...args)
        : undefined;
    } catch (error) {
      console.warn(`[PrimeNative] ${name}`, error);
      return undefined;
    }
  }

  function parse(value, fallback = {}) {
    try {
      return typeof value === 'string' ? JSON.parse(value) : value || fallback;
    } catch {
      return fallback;
    }
  }

  function normalizePayload(payload = {}, requestCast = false) {
    const candidates = (Array.isArray(payload.candidates) ? payload.candidates : [payload.url])
      .map(candidate => typeof candidate === 'string' ? { url: candidate } : candidate)
      .filter(candidate => /^https?:\/\//i.test(String(candidate?.url || '')));
    return {
      version: 5,
      title: String(payload.title || 'Lecture'),
      poster: String(payload.poster || ''),
      type: String(payload.type || 'video'),
      startPositionMs: Number(payload.startPositionMs || 0),
      autoplay: payload.autoplay !== false,
      requestCast: !!requestCast,
      candidates
    };
  }

  function capabilities() {
    return parse(call('getNativeCapabilities'), {});
  }

  function nativePlayerAvailable() {
    const bridge = api();
    return !!bridge && (
      typeof bridge.openPlayerV6 === 'function' ||
      typeof bridge.openNativePlayerV4 === 'function' ||
      typeof bridge.openNativePlayer === 'function'
    );
  }

  function play(payload = {}) {
    const normalized = normalizePayload(payload, false);
    if (!normalized.candidates.length) return false;
    if (typeof api()?.openPlayerV6 === 'function') {
      return call('openPlayerV6', JSON.stringify(normalized)) === true;
    }
    const urls = normalized.candidates.map(candidate => candidate.url);
    if (typeof api()?.openNativePlayerV4 === 'function') {
      return call(
        'openNativePlayerV4',
        JSON.stringify(urls),
        normalized.title,
        normalized.poster,
        '{}',
        normalized.startPositionMs,
        normalized.autoplay
      ) === true;
    }
    if (typeof api()?.openNativePlayer === 'function') {
      return call(
        'openNativePlayer',
        urls[0],
        normalized.title,
        normalized.poster,
        '{}',
        normalized.startPositionMs,
        normalized.autoplay
      ) === true;
    }
    return false;
  }

  function cast(payload = {}) {
    const normalized = normalizePayload(payload, true);
    if (!normalized.candidates.length) return false;
    if (typeof api()?.castV6 === 'function') {
      return call('castV6', JSON.stringify(normalized)) === true;
    }
    if (typeof api()?.openPlayerV6 === 'function') {
      return call('openPlayerV6', JSON.stringify(normalized)) === true;
    }
    const urls = normalized.candidates.map(candidate => candidate.url);
    if (typeof api()?.castMediaV4 === 'function') {
      return call(
        'castMediaV4',
        JSON.stringify(urls),
        normalized.title,
        normalized.poster,
        '{}',
        normalized.startPositionMs
      ) === true;
    }
    return false;
  }

  function saveSecret(key, value) {
    return call('secureSet', String(key), String(value ?? '')) === true ||
      call('saveSecret', String(key), String(value ?? '')) === true;
  }

  function loadSecret(key) {
    return String(
      call('secureGet', String(key), '') ??
      call('loadSecret', String(key)) ??
      ''
    );
  }

  function toast(message) {
    call('showToast', String(message));
  }

  window.PrimeNative = {
    available: () => !!api(),
    capabilities,
    nativePlayerAvailable,
    saveSecret,
    loadSecret,
    play,
    cast,
    toast
  };
})();
