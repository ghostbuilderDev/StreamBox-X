STREAMBOX VISION 4.0 — MOBILE FIRST ANDROID

Cette version a été entièrement repensée pour les écrans Android :
- interface optimisée de 360 à 480 px et tablettes ;
- navigation inférieure utilisable au pouce ;
- recherche centrale toujours accessible ;
- fiches contenus sous forme de panneau coulissant ;
- lecteur plein écran optimisé portrait et paysage ;
- bouton Retour Android géré pour fermer les couches ;
- reprise de lecture, favoris, historique, EPG et profils locaux ;
- HLS, DASH, MP4/WebM et format Xtream TS en option.

RÉGLAGES HTMLtoAPK
- Start file : index.html
- JavaScript : ON
- DOM Storage : ON
- Hardware acceleration : ON
- Internet : ON
- Keep screen on : ON
- Cleartext traffic : ON si serveur http://
- Mixed content : ALWAYS_ALLOW
- Media playback requires user gesture : OFF
- Orientation : Auto / Unspecified

L’application ne fournit aucun abonnement ni contenu. Utiliser uniquement des sources autorisées.
