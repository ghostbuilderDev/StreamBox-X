STREAMBOX VISION STABLE 7.0 — CORRECTION COMPLÈTE DU CAST ANDROID

CE QUI A ÉTÉ CORRIGÉ
- Suppression des liens intent:// lancés directement depuis la WebView.
- Suppression des ouvertures directes d’URL provoquant « Impossible d’ouvrir ce lien ».
- Détection claire du module Cast natif réellement présent dans l’APK.
- Désactivation automatique des boutons non compatibles au lieu d’afficher une fausse option.
- Partage Android, lecteur externe et réglages Cast gérés par un pont Kotlin natif.
- Retour d’erreurs détaillées depuis Android vers l’interface HTML.
- Bouton Cast direct uniquement actif si Google Cast, Remote Playback ou le pont Android est réellement disponible.
- Copie propre du lien comme dernier recours, sans tentative d’ouverture invalide.

IMPORTANT — POUR UN VRAI CHROMECAST
Une WebView HTML seule ne peut pas découvrir de manière fiable les Chromecast. Pour obtenir le vrai sélecteur de téléviseurs, le générateur HTMLtoAPK doit intégrer le dossier :

native-cast-addon/

Il contient :
- StreamBoxCastBridge.kt
- StreamBoxCastOptionsProvider.kt
- MainActivity.integration.kt.snippet
- build.gradle.kts.snippet
- AndroidManifest.xml.snippet
- README.md

APRÈS INTÉGRATION DU MODULE NATIF
1. Le bouton « Choisir un téléviseur » ouvre le sélecteur Google Cast officiel.
2. La duplication ouvre les réglages Android sans erreur WebView.
3. « Envoyer vers une application TV » ouvre le partage Android.
4. « Lecteur externe » ouvre VLC ou une autre application vidéo compatible.
5. Les erreurs sont renvoyées proprement dans StreamBox Vision.

RÉGLAGES HTMLtoAPK
- Fichier de départ : index.html
- JavaScript : activé
- DOM Storage : activé
- Hardware acceleration : activée
- INTERNET / ACCESS_NETWORK_STATE / ACCESS_WIFI_STATE : autorisés
- CHANGE_WIFI_MULTICAST_STATE : autorisé pour la découverte Cast
- allowCleartextTraffic : activé pour les serveurs http://
- mixedContentMode : ALWAYS_ALLOW
- orientation : automatique

LIMITES RÉELLES
Le téléviseur doit pouvoir joindre directement l’URL du flux. Un flux peut échouer s’il utilise :
- un certificat non reconnu ;
- un codec non pris en charge par Chromecast ;
- un lien limité au téléphone ou expirant trop vite ;
- des cookies ou en-têtes spéciaux ;
- une adresse locale inaccessible depuis le téléviseur.
