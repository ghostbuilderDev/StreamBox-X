STREAMBOX VISION CAST 5.0 — HTMLtoAPK

NOUVEAUTÉS
- Bouton Cast dans l’en-tête, le lecteur et les réglages
- Google Cast Web Sender lorsque disponible
- API Remote Playback lorsque disponible
- Duplication d’écran via les réglages Android Cast
- Partage du flux vers VLC, BubbleUPnP ou une application TV compatible
- Interface d’état : disponible, connexion, connecté, arrêt de diffusion
- Contrôles lecture/pause et avance/retour compatibles avec une session Google Cast Web
- Dossier native-cast-addon pour intégrer un vrai pont Google Cast à ton générateur HTMLtoAPK

RÉGLAGES HTMLtoAPK
- Fichier de départ : index.html
- JavaScript : activé
- DOM Storage : activé
- Accélération matérielle : activée
- Internet et réseau : activés
- Orientation : automatique
- Cleartext traffic : activé si le serveur utilise http://
- Mixed content : ALWAYS_ALLOW

IMPORTANT
Un APK WebView pur ne garantit pas la découverte Chromecast. La version utilise plusieurs solutions de secours. Pour un bouton Chromecast natif garanti, intégrer le dossier native-cast-addon dans le wrapper Android de HTMLtoAPK.

L’application ne fournit aucun contenu ni abonnement.
