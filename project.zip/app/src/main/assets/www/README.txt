STREAMBOX X 2.0 — PRÊT POUR HTMLtoAPK

1. Importer tout le dossier ou le ZIP dans HTMLtoAPK.
2. Fichier de démarrage : index.html
3. Activer JavaScript, DOM Storage, accélération matérielle et lecture multimédia.
4. Autoriser INTERNET et ACCESS_NETWORK_STATE.
5. Activer le trafic HTTP non sécurisé et le contenu mixte si votre serveur commence par http://.
6. Conserver l'orientation automatique pour passer en paysage pendant la vidéo.

CONNEXION XTREAM
Saisir l'adresse du serveur (avec http:// ou https://), l'identifiant et le mot de passe fournis par un service légalement autorisé. Les identifiants restent dans le stockage local de l'application.

LIMITES POSSIBLES
Certains serveurs bloquent les WebView, imposent un User-Agent particulier, utilisent des codecs non reconnus par Android ou interdisent CORS. Le mode lecteur externe permet alors d'essayer VLC. L'application ne fournit ni chaîne, ni film, ni abonnement.
