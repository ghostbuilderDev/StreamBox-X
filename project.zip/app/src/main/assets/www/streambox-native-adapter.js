(function () {
  const existing = window.NativeAndroid || {};
  const fallback = {
  available: function () { return typeof window.AndroidApp !== "undefined"; },
  toast: function (message) {
    if (this.available()) window.AndroidApp.showToast(String(message));
    else console.log(message);
  },
  share: async function (text) {
    if (this.available()) return window.AndroidApp.share(String(text));
    if (navigator.share) return navigator.share({text:String(text)});
  },
  copy: async function (text) {
    if (this.available()) return window.AndroidApp.copyText(String(text));
    return navigator.clipboard.writeText(String(text));
  },
  vibrate: function (milliseconds) {
    if (this.available()) return window.AndroidApp.vibrate(Number(milliseconds) || 100);
    if (navigator.vibrate) navigator.vibrate(Number(milliseconds) || 100);
  },
  openUrl: function (url) {
    if (this.available()) return window.AndroidApp.openUrl(String(url));
    window.open(String(url), "_blank", "noopener");
  },
  nativeIptvAvailable: function () {
    try {
      if (!this.available()) return false;
      if (typeof window.AndroidApp.supportsNativeIptv === "function") return !!window.AndroidApp.supportsNativeIptv();
      return typeof window.AndroidApp.playNative === "function" ||
             typeof window.AndroidApp.openNativePlayer === "function" ||
             typeof window.AndroidApp.playVideo === "function";
    } catch(e) { return false; }
  },
  nativeCastAvailable: function () {
    try {
      if (!this.available()) return false;
      if (typeof window.AndroidApp.supportsGoogleCast === "function") return !!window.AndroidApp.supportsGoogleCast();
      return typeof window.AndroidApp.castNative === "function" ||
             typeof window.AndroidApp.requestCastSession === "function" ||
             typeof window.AndroidApp.castVideo === "function";
    } catch(e) { return false; }
  },
  playNative: function (url,title,type,poster) {
    if (!this.nativeIptvAvailable()) throw new Error("Mode IPTV natif absent de cet APK");
    const payload = JSON.stringify({url:String(url),title:String(title||"Lecture"),type:String(type||"video"),poster:String(poster||"")});
    if (typeof window.AndroidApp.playNative === "function") return window.AndroidApp.playNative(String(url),String(title||"Lecture"),String(type||"video"),String(poster||""));
    if (typeof window.AndroidApp.openNativePlayer === "function") return window.AndroidApp.openNativePlayer(payload);
    if (typeof window.AndroidApp.playVideo === "function") return window.AndroidApp.playVideo(payload);
    throw new Error("Lecteur Android natif absent");
  },
  castNative: function (url,title,mime,poster) {
    if (!this.nativeCastAvailable()) throw new Error("Google Cast natif absent de cet APK");
    const payload = JSON.stringify({url:String(url),title:String(title||"Cast"),mime:String(mime||"application/x-mpegURL"),poster:String(poster||"")});
    if (typeof window.AndroidApp.castNative === "function") return window.AndroidApp.castNative(String(url),String(title||"Cast"),String(mime||"application/x-mpegURL"),String(poster||""));
    if (typeof window.AndroidApp.requestCastSession === "function") return window.AndroidApp.requestCastSession(payload);
    if (typeof window.AndroidApp.castVideo === "function") return window.AndroidApp.castVideo(payload);
    throw new Error("Google Cast natif absent");
  },
  saveDiagnostic: function (filename,text) {
    if (this.available() && window.AndroidApp.saveDiagnostic) return window.AndroidApp.saveDiagnostic(String(filename),String(text));
    return false;
  },
  saveSecret: function (key,value) {
    if (this.available() && window.AndroidApp.saveSecret) window.AndroidApp.saveSecret(String(key),String(value));
  },
  loadSecret: function (key) {
    if (this.available() && window.AndroidApp.loadSecret) return window.AndroidApp.loadSecret(String(key));
    return "";
  },
  startBackgroundTask: function (title, message) {
    if (this.available() && window.AndroidApp.startBackgroundTask) {
      return window.AndroidApp.startBackgroundTask(String(title),String(message));
    }
  },
  updateBackgroundTask: function (message) {
    if (this.available() && window.AndroidApp.updateBackgroundTask) {
      return window.AndroidApp.updateBackgroundTask(String(message));
    }
  },
  finishBackgroundTask: function (message, success) {
    if (this.available() && window.AndroidApp.finishBackgroundTask) {
      return window.AndroidApp.finishBackgroundTask(String(message),!!success);
    }
  }
  };
  for (const [key, value] of Object.entries(fallback)) {
    if (typeof existing[key] === "undefined") existing[key] = value;
  }
  window.NativeAndroid = existing;
})();

// Adaptateurs utilisés par app.js lorsque l’APK expose l’interface AndroidApp.
window.NativeAndroidPlayer = {
  getCapabilities: function(){ return JSON.stringify({native:true,play:window.NativeAndroid.nativeIptvAvailable()}); },
  play: function(payload){
    try{
      const p=typeof payload==='string'?JSON.parse(payload):payload;
      window.NativeAndroid.playNative(p.url,p.title,p.isLive?'live':'video',p.image||'');
      return JSON.stringify({ok:true});
    }catch(e){return JSON.stringify({ok:false,error:e&&e.message?e.message:String(e)})}
  }
};
window.NativeAndroidCast = {
  getCapabilities: function(){ return JSON.stringify({native:true,cast:window.NativeAndroid.nativeCastAvailable(),settings:!!window.AndroidApp?.openCastSettings,share:!!window.AndroidApp?.shareMedia,external:!!window.AndroidApp?.openExternal}); },
  requestSession: function(payload){
    try{
      const p=typeof payload==='string'?JSON.parse(payload):payload;
      window.NativeAndroid.castNative(p.url,p.title,p.mime,p.image||'');
      return JSON.stringify({ok:true,connecting:true});
    }catch(e){return JSON.stringify({ok:false,error:e&&e.message?e.message:String(e)})}
  },
  cast: function(payload){ return this.requestSession(payload); }
};

window.NativeAndroidAudio = {
  available: function(){
    return !!(window.AndroidApp && (window.AndroidApp.showAudioTracks || window.AndroidApp.openAudioTrackSelector || window.AndroidApp.selectAudioTrack));
  },
  show: function(){
    if(window.AndroidApp?.showAudioTracks) return window.AndroidApp.showAudioTracks();
    if(window.AndroidApp?.openAudioTrackSelector) return window.AndroidApp.openAudioTrackSelector();
    return false;
  }
};
