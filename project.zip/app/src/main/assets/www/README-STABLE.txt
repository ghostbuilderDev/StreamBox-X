Prime IPTV Player 2.5 Stable
- Interface V2 conservée
- Lecteur Web prioritaire
- Séries : premier épisode sélectionné automatiquement
- Cast natif via HTMLtoAPK Stable Cast
