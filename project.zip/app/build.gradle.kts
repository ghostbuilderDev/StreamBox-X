plugins {
    id("com.android.application")
}

val stableKeystore = rootProject.file(".signing/html-apk-stable.p12")
val stableStorePassword = "HTML_APK_BUILDER_STABLE_2026"
val stableKeyAlias = "html-apk-stable"
val stableKeyPassword = "HTML_APK_BUILDER_STABLE_2026"

android {
    namespace = "dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt"
    compileSdk = 36

    defaultConfig {
        applicationId = "dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt"
        minSdk = 24
        targetSdk = 36
        versionCode = 207907792
        versionName = "1.0.8"
        multiDexEnabled = true
    }

    signingConfigs {
        create("stable") {
            if (stableKeystore.exists()) {
                storeFile = stableKeystore
                storePassword = stableStorePassword
                keyAlias = stableKeyAlias
                keyPassword = stableKeyPassword
                storeType = "PKCS12"
            }
        }
    }

    buildFeatures { buildConfig = true }

    buildTypes {
        debug {
            if (stableKeystore.exists()) signingConfig = signingConfigs.getByName("stable")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            if (stableKeystore.exists()) signingConfig = signingConfigs.getByName("stable")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
    }
}

// Compatibilité Android API 36 : Core 1.18 exige API 36.1 et Core 1.19 exige API 37.
// Le verrouillage couvre aussi core-ktx éventuellement demandé transitivement.
configurations.configureEach {
    resolutionStrategy.force(
        "androidx.core:core:1.17.0",
        "androidx.core:core-ktx:1.17.0"
    )
}

dependencies {
    implementation("androidx.webkit:webkit:1.16.0")
    implementation("androidx.fragment:fragment:1.8.9")
    implementation("androidx.media3:media3-exoplayer:1.10.1")
    implementation("androidx.media3:media3-ui:1.10.1")
    implementation("androidx.media3:media3-session:1.10.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.10.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.10.1")
    implementation("androidx.media3:media3-exoplayer-smoothstreaming:1.10.1")
    implementation("androidx.media3:media3-exoplayer-rtsp:1.10.1")
    implementation("androidx.media3:media3-cast:1.10.1")
    implementation("androidx.mediarouter:mediarouter:1.8.1")
    implementation("com.google.android.gms:play-services-cast-framework:22.3.1")
    implementation("androidx.room:room-runtime:2.8.4")
    implementation("androidx.work:work-runtime:2.11.2")
    implementation("androidx.core:core:1.17.0")
    annotationProcessor("androidx.room:room-compiler:2.8.4")
}
