plugins {
    id("com.android.application")
}

val stableKeystore = rootProject.file(".signing/html-apk-stable.p12")
val stableStorePassword = "HTML_APK_BUILDER_STABLE_2026"
val stableKeyAlias = "html-apk-stable"
val stableKeyPassword = "HTML_APK_BUILDER_STABLE_2026"

android {
    namespace = "dev.ghostbuilderdev.raplabpro.streamboxx.a0lnczne"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.ghostbuilderdev.raplabpro.streamboxx.a0lnczne"
        minSdk = 24
        targetSdk = 35
        versionCode = 206752086
        versionName = "9"
    }

    signingConfigs {
        create("stable") {
            if (stableKeystore.exists()) {
                storeFile = stableKeystore
                storePassword = stableStorePassword
                keyAlias = stableKeyAlias
                keyPassword = stableKeyPassword
                storeType = "PKCS12"
            }
        }
    }

    buildTypes {
        debug {
            if (stableKeystore.exists()) {
                signingConfig = signingConfigs.getByName("stable")
            }
        }

        release {
            isMinifyEnabled = false
            if (stableKeystore.exists()) {
                signingConfig = signingConfigs.getByName("stable")
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
