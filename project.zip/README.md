# Prime IPTV Player 5.0

Version reconstruite du cœur de lecture et du Cast.

## Changement d’architecture

La lecture ne démarre plus une seconde activité Android et n’utilise plus un Intent générique. `NativePlayerOverlay` s’affiche directement au-dessus de la WebView principale. Une erreur de codec, de serveur ou de Cast ne doit donc plus fermer l’application.

## Lecture locale

- Media3 / ExoPlayer intégré dans l’écran principal.
- Essai automatique de plusieurs URL Xtream : source directe, extension annoncée, MP4, HLS, MKV et MPEG-TS.
- Prise en charge des épisodes dont l’identifiant est fourni sous `id`, `stream_id` ou `episode_id`.
- Le bouton général d’une série sélectionne le premier épisode disponible au lieu de produire « aucun flux lisible ».
- En-têtes HTTP, redirections et serveurs HTTP autorisés.
- Erreur affichée dans le lecteur, sans fermeture de l’application.

## Chromecast

- Google Cast est chargé uniquement lorsque l’utilisateur touche **Caster**.
- Initialisation asynchrone et erreur isolée de la lecture locale.
- Priorité HLS, puis MP4, MPEG-TS et WebM.
- Relais HTTP local prioritaire sur le Wi-Fi, puis essai direct si le serveur exige des en-têtes ou ne fournit pas CORS.
- Le relais sélectionne l’adresse IPv4 Wi-Fi même lorsqu’un VPN est actif.
- MKV est lu localement lorsque le téléphone possède le codec, mais n’est pas envoyé au récepteur Google standard sans variante compatible.

## Construction

Le workflow `.github/workflows/build-apk.yml` compile :

- package : `dev.ghostbuilderdev.streamboxx.iptvplayer.a15jnnqt`
- version : `5.0.0`
- versionCode : `208005001`
- Android API 36
- Java 17
- Gradle 9.5.0

Le workflow vérifie que l’ancien `PlayerActivity` n’est plus déclaré et produit un APK de test ainsi qu’un rapport de compilation.

## Important

Cette application est un lecteur. Elle ne doit être utilisée qu’avec des listes et contenus que l’utilisateur est autorisé à consulter.

## Procédure recommandée sur téléphone

Ne pas importer les seules sources Web dans HTMLtoAPK V16.x : ces anciennes versions régénéreraient l’ancien lecteur Android. Utiliser le projet Android complet avec `Prime-IPTV-V5-COMPILATEUR-GITHUB.html`.
