# IPTV Player

Application Android hybride générée par **HTML → APK Builder V16.1 IPTV Native**.

## Modules générés

- AndroidX WebKit
- Media3 natif + MediaSession
- Google Cast réel
- Picture-in-Picture
- Room : favoris et historique
- WorkManager IPTV
- Notifications + média
- Android TV
- Diagnostic natif
- Fichiers et partage
- Stockage chiffré Android Keystore

## Architecture

- Interface métier conservée dans `app/src/main/assets/www`.
- Pont JavaScript `AndroidApp` et couche `NativeAndroid`.
- `IptvPlaybackService` : MediaSessionService, ExoPlayer et notification média.
- `PlayerActivity` : lecteur natif, pistes, reprise, PiP et lecteur externe.
- CastPlayer et transfert local/Chromecast via le sélecteur de sortie Media3.
- Room : favoris et historique persistants.
- WorkManager : synchronisation et cache de catalogue/EPG.
- Android Keystore AES-GCM : stockage chiffré des identifiants.
- Android TV : launcher Leanback, bannière et événements D-pad.

## Appels JavaScript principaux

```javascript
const caps = NativeAndroid.capabilities();
NativeAndroid.playNative(streamUrl, title, {
  poster: posterUrl,
  startPositionMs: -1,
  autoplay: true
});
NativeAndroid.enterPiP();
NativeAndroid.openExternalPlayer(streamUrl, title);
NativeAndroid.secureSet("iptv_password", password);
const password = NativeAndroid.secureGet("iptv_password", "");
NativeAndroid.favorites.save("live", channelId, channelObject);
NativeAndroid.history.save(itemId, itemObject, positionMs, durationMs, false);
NativeAndroid.scheduleSync("epg", epgUrl, 60);
const diagnostic = NativeAndroid.diagnostics();
```

## Compilation

Le workflow GitHub utilise Java 17, Gradle 9.5.0, Android SDK 36 et produit un APK signé de façon stable pour les mises à jour suivantes.
